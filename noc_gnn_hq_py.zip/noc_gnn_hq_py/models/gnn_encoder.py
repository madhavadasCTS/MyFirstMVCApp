"""
GNN Encoder for Task Communication Graph  —  v2.0
==================================================

Architecture:
  - 12 rich node features (8 basic + 4 networkx: betweenness, closeness,
    PageRank, clustering coefficient)
  - 4-layer GAT + GraphSAGE dual-path with residual connections
  - BatchNorm on every layer
  - Graph embedding = concat(mean_pool, max_pool)
  - Batched inference via torch_geometric.data.Batch
  - GNNClusteringModule: differentiable soft-clustering with
    communication-aware loss (gradients flow through GNN properly)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, SAGEConv, global_mean_pool, global_max_pool
from torch_geometric.data import Data, Batch
import numpy as np
import networkx as nx
from typing import Tuple, Optional, List

NODE_FEATURE_DIM = 12   # used by trainer to auto-configure GNN input size


# ─── Graph building ───────────────────────────────────────────────────────────

def build_graph_from_comm_matrix(comm_matrix: np.ndarray,
                                  threshold: float = 0.0) -> Data:
    """
    Convert a task communication matrix to a PyG Data object.

    Node features (12 dims):
      0  out-degree          1  in-degree
      2  out-volume          3  in-volume
      4  max-out-edge        5  max-in-edge
      6  betweenness centrality  — bottleneck tasks sit on most paths
      7  closeness centrality    — hub tasks are close to all others
      8  PageRank                — recursively important tasks
      9  clustering coefficient  — tight-cluster members
     10  normalised task index   — positional feature
     11  graph communication density
    """
    num_tasks = comm_matrix.shape[0]

    G = nx.DiGraph()
    G.add_nodes_from(range(num_tasks))
    src_list, dst_list, wt_list = [], [], []

    for i in range(num_tasks):
        for j in range(num_tasks):
            if i != j and comm_matrix[i, j] > threshold:
                G.add_edge(i, j, weight=float(comm_matrix[i, j]))
                src_list.append(i)
                dst_list.append(j)
                wt_list.append(float(comm_matrix[i, j]))

    # Guarantee at least minimal connectivity
    if len(src_list) == 0:
        for i in range(num_tasks - 1):
            G.add_edge(i, i + 1, weight=0.01)
            G.add_edge(i + 1, i, weight=0.01)
            src_list += [i, i + 1]
            dst_list += [i + 1, i]
            wt_list  += [0.01, 0.01]

    # ── networkx centrality features ─────────────────────────────────────────
    Gu          = G.to_undirected()
    betweenness = nx.betweenness_centrality(Gu, normalized=True)
    closeness   = nx.closeness_centrality(Gu)
    pagerank    = nx.pagerank(G, alpha=0.85, max_iter=100,
                              weight='weight', tol=1e-4)
    clustering  = nx.clustering(Gu, weight='weight')

    def _arr(d):
        return np.array([d[i] for i in range(num_tasks)], dtype=np.float32)
    def _norm(a):
        mx = a.max()
        return a / (mx + 1e-6)

    out_deg  = _norm((comm_matrix > threshold).sum(1).astype(np.float32))
    in_deg   = _norm((comm_matrix > threshold).sum(0).astype(np.float32))
    out_vol  = _norm(comm_matrix.sum(1).astype(np.float32))
    in_vol   = _norm(comm_matrix.sum(0).astype(np.float32))
    max_out  = _norm(comm_matrix.max(1).astype(np.float32))
    max_in   = _norm(comm_matrix.max(0).astype(np.float32))
    btwn     = _arr(betweenness)
    clos     = _arr(closeness)
    pr       = _norm(_arr(pagerank))
    clust    = _arr(clustering)
    idx      = np.arange(num_tasks, dtype=np.float32) / num_tasks
    dens     = np.full(num_tasks,
                       len(src_list) / (num_tasks * (num_tasks - 1) + 1e-6),
                       dtype=np.float32)

    x = torch.tensor(
        np.stack([out_deg, in_deg, out_vol, in_vol,
                  max_out, max_in, btwn, clos,
                  pr, clust, idx, dens], axis=1),
        dtype=torch.float32)

    edge_index  = torch.tensor([src_list, dst_list], dtype=torch.long)
    edge_weight = torch.tensor(wt_list, dtype=torch.float32)
    if edge_weight.max() > 0:
        edge_weight = edge_weight / edge_weight.max()
    edge_attr = edge_weight.unsqueeze(-1)

    return Data(x=x, edge_index=edge_index,
                edge_attr=edge_attr, edge_weight=edge_weight)


def build_batched_graphs(comm_matrices: List[np.ndarray]) -> Batch:
    """Build a PyG Batch from multiple comm matrices for parallel inference."""
    return Batch.from_data_list(
        [build_graph_from_comm_matrix(cm) for cm in comm_matrices])


# ─── GNN model ────────────────────────────────────────────────────────────────

class TaskGraphGNN(nn.Module):
    """
    4-layer GAT + GraphSAGE dual-path GNN with residual connections.

    GAT  learns long-range weighted attention between tasks.
    SAGE learns local neighbourhood aggregation.
    Fusion layer combines both paths for richer per-task representations.
    Graph embedding = concat(mean_pool, max_pool) for richer global context.
    """

    def __init__(self,
                 node_feature_dim: int = NODE_FEATURE_DIM,
                 hidden_dim: int = 128,
                 embedding_dim: int = 64,
                 num_layers: int = 4,
                 num_heads: int = 4,
                 dropout: float = 0.1):
        super().__init__()
        self.embedding_dim = embedding_dim
        self.num_layers    = num_layers

        self.input_proj = nn.Sequential(
            nn.Linear(node_feature_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU())

        self.gat_convs  = nn.ModuleList()
        self.gat_norms  = nn.ModuleList()
        self.sage_convs = nn.ModuleList()
        self.sage_norms = nn.ModuleList()

        for _ in range(num_layers):
            self.gat_convs.append(GATConv(
                hidden_dim, hidden_dim // num_heads,
                heads=num_heads, dropout=dropout, edge_dim=1, concat=True))
            self.gat_norms.append(nn.BatchNorm1d(hidden_dim))
            self.sage_convs.append(SAGEConv(hidden_dim, hidden_dim))
            self.sage_norms.append(nn.BatchNorm1d(hidden_dim))

        self.fusion = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.ReLU())

        self.node_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2), nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, embedding_dim))

        self.graph_proj = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, embedding_dim))

        self.dropout_layer = nn.Dropout(dropout)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0.0)

    def forward(self, x: torch.Tensor,
                edge_index: torch.LongTensor,
                edge_attr: Optional[torch.Tensor] = None,
                edge_weight: Optional[torch.Tensor] = None,
                batch: Optional[torch.Tensor] = None
                ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            x           : [N, node_feature_dim]
            edge_index  : [2, E]
            edge_attr   : [E, 1]  communication volumes per edge
            edge_weight : [E]     scalar weights (used by SAGE path)
            batch       : [N]     graph IDs for batched inference

        Returns:
            node_emb  : [N, embedding_dim]
            graph_emb : [G, embedding_dim]  G=1 for single graph
        """
        h = self.input_proj(x)
        h_gat = h_sage = h

        for i in range(self.num_layers):
            g = self.gat_convs[i](h_gat, edge_index, edge_attr=edge_attr)
            g = F.relu(self.gat_norms[i](g))
            g = self.dropout_layer(g)
            h_gat = h_gat + g if i > 0 else g

            s = self.sage_convs[i](h_sage, edge_index)
            s = F.relu(self.sage_norms[i](s))
            s = self.dropout_layer(s)
            h_sage = h_sage + s if i > 0 else s

        h_fused  = self.fusion(torch.cat([h_gat, h_sage], dim=-1))
        node_emb = self.node_proj(h_fused)

        if batch is None:
            g_mean = h_fused.mean(0, keepdim=True)
            g_max  = h_fused.max(0).values.unsqueeze(0)
        else:
            g_mean = global_mean_pool(h_fused, batch)
            g_max  = global_max_pool(h_fused, batch)

        graph_emb = self.graph_proj(torch.cat([g_mean, g_max], dim=-1))
        return node_emb, graph_emb


# ─── Inference helpers ────────────────────────────────────────────────────────

def get_task_embeddings(gnn_model: TaskGraphGNN,
                         comm_matrix: np.ndarray,
                         device: torch.device
                         ) -> Tuple[np.ndarray, np.ndarray]:
    """Single-graph inference. Returns (node_emb [T,D], graph_emb [1,D])."""
    gnn_model.eval()
    with torch.no_grad():
        data = build_graph_from_comm_matrix(comm_matrix)
        node_emb, graph_emb = gnn_model(
            data.x.to(device), data.edge_index.to(device),
            edge_attr=data.edge_attr.to(device),
            edge_weight=data.edge_weight.to(device))
    return node_emb.cpu().numpy(), graph_emb.cpu().numpy()


def get_task_embeddings_batched(gnn_model: TaskGraphGNN,
                                 comm_matrices: List[np.ndarray],
                                 device: torch.device
                                 ) -> Tuple[List[np.ndarray], np.ndarray]:
    """
    Batched inference — all graphs processed in one forward pass.

    Returns:
        node_embs  : list of [num_tasks, embedding_dim] arrays
        graph_embs : [num_graphs, embedding_dim]
    """
    gnn_model.eval()
    with torch.no_grad():
        b = build_batched_graphs(comm_matrices).to(device)
        node_all, graph_all = gnn_model(
            b.x, b.edge_index,
            edge_attr=b.edge_attr,
            edge_weight=b.edge_weight,
            batch=b.batch)

    node_all  = node_all.cpu().numpy()
    graph_all = graph_all.cpu().numpy()
    sizes     = [cm.shape[0] for cm in comm_matrices]
    node_embs, offset = [], 0
    for s in sizes:
        node_embs.append(node_all[offset:offset + s])
        offset += s
    return node_embs, graph_all


# ─── Clustering module ────────────────────────────────────────────────────────

class GNNClusteringModule(nn.Module):
    """
    Differentiable soft-clustering head trained jointly with the RL agent.

    clustering_loss() re-runs the GNN forward pass internally so gradients
    flow through both this module AND the GNN convolutional layers.
    This is the fix for the detached-numpy gradient issue.

    Loss = inter_cluster_comm - intra_cluster_comm - 0.05 * entropy_bonus
    """

    def __init__(self, embedding_dim: int = 64, num_clusters: int = 4,
                 hidden_dim: int = 64):
        super().__init__()
        self.num_clusters = num_clusters
        self.cluster_net  = nn.Sequential(
            nn.Linear(embedding_dim, hidden_dim), nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2), nn.ReLU(),
            nn.Linear(hidden_dim // 2, num_clusters))
        self.log_temperature = nn.Parameter(torch.tensor(0.0))

    def forward(self, node_embeddings: torch.Tensor) -> torch.Tensor:
        """[num_tasks, embedding_dim] → [num_tasks, num_clusters] soft assignments."""
        logits = self.cluster_net(node_embeddings)
        temp   = torch.exp(self.log_temperature).clamp(0.1, 10.0)
        return F.softmax(logits / temp, dim=-1)

    def get_hard_clusters(self, node_embeddings: torch.Tensor) -> np.ndarray:
        with torch.no_grad():
            return self.forward(node_embeddings).argmax(-1).cpu().numpy()

    def clustering_loss(self,
                        gnn_model: TaskGraphGNN,
                        graph_data: Data,
                        comm_matrix: torch.Tensor) -> torch.Tensor:
        """
        Communication-aware clustering loss WITH proper gradient flow.

        Runs GNN forward internally (with grad) so gradients propagate
        through both the clustering head AND the GNN conv layers.

        Args:
            gnn_model    : TaskGraphGNN (must be in train mode)
            graph_data   : PyG Data object for this task graph
            comm_matrix  : [T, T] float tensor of communication volumes
        """
        # Run GNN with gradients enabled (no torch.no_grad here)
        node_emb, _ = gnn_model(
            graph_data.x, graph_data.edge_index,
            edge_attr=graph_data.edge_attr,
            edge_weight=graph_data.edge_weight)

        soft    = self.forward(node_emb)              # [T, K]
        same_cl = torch.mm(soft, soft.t())             # [T, T]

        intra   = (same_cl * comm_matrix).sum() / (same_cl.sum() + 1e-6)
        inter   = ((1 - same_cl) * comm_matrix).sum() / ((1 - same_cl).sum() + 1e-6)
        entropy = -(soft * (soft + 1e-6).log()).sum(-1).mean()

        return inter - intra - 0.05 * entropy
