"""
Hierarchical Q-Learning Agent with GNN-enhanced state representation.

Two-level hierarchy:
  - Coarse level: assigns task clusters to NoC clusters
  - Fine level:   assigns individual tasks to cores within a NoC cluster

Both levels use neural network Q-functions (DQN-style) instead of
flat lookup tables, with GNN embeddings as state features.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from collections import deque, namedtuple
from typing import List, Tuple, Optional, Dict
import random


# ─── Experience replay ────────────────────────────────────────────────────────

Transition = namedtuple('Transition',
                        ('state', 'action', 'reward', 'next_state', 'done'))


class ReplayBuffer:
    """Fixed-size replay buffer for experience replay."""

    def __init__(self, capacity: int = 50_000, seed: int = 42):
        self.buffer = deque(maxlen=capacity)
        self.rng = random.Random(seed)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append(Transition(
            np.array(state, dtype=np.float32),
            int(action),
            float(reward),
            np.array(next_state, dtype=np.float32),
            bool(done)
        ))

    def sample(self, batch_size: int) -> List[Transition]:
        return self.rng.sample(self.buffer, batch_size)

    def __len__(self):
        return len(self.buffer)


# ─── Q-Network ────────────────────────────────────────────────────────────────

class QNetwork(nn.Module):
    """
    Neural network Q-function.
    Takes state vector (GNN embeddings + context features) and outputs
    Q-values for each action.
    """

    def __init__(self,
                 state_dim: int,
                 action_dim: int,
                 hidden_dims: List[int] = [256, 256, 128],
                 dropout: float = 0.1):
        super(QNetwork, self).__init__()

        layers = []
        in_dim = state_dim
        for h in hidden_dims:
            layers.extend([
                nn.Linear(in_dim, h),
                nn.LayerNorm(h),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            in_dim = h

        layers.append(nn.Linear(in_dim, action_dim))
        self.net = nn.Sequential(*layers)

        # Weight initialization (important for RL stability)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.constant_(m.bias, 0.0)
        # Last layer: small init for stable early training
        last_linear = [m for m in self.modules() if isinstance(m, nn.Linear)][-1]
        nn.init.orthogonal_(last_linear.weight, gain=0.01)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class DuelingQNetwork(nn.Module):
    """
    Dueling DQN architecture.
    Separates state value V(s) and advantage A(s,a) streams.
    Q(s,a) = V(s) + A(s,a) - mean(A(s,·))
    This stabilizes learning especially when many actions have similar value.
    """

    def __init__(self,
                 state_dim: int,
                 action_dim: int,
                 hidden_dims: List[int] = [256, 256],
                 dropout: float = 0.1):
        super(DuelingQNetwork, self).__init__()

        # Shared feature extractor
        shared_layers = []
        in_dim = state_dim
        for h in hidden_dims[:-1]:
            shared_layers.extend([
                nn.Linear(in_dim, h),
                nn.LayerNorm(h),
                nn.ReLU(),
                nn.Dropout(dropout)
            ])
            in_dim = h
        self.shared = nn.Sequential(*shared_layers)

        last_h = hidden_dims[-1]

        # Value stream
        self.value_stream = nn.Sequential(
            nn.Linear(in_dim, last_h),
            nn.ReLU(),
            nn.Linear(last_h, 1)
        )

        # Advantage stream
        self.advantage_stream = nn.Sequential(
            nn.Linear(in_dim, last_h),
            nn.ReLU(),
            nn.Linear(last_h, action_dim)
        )

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.constant_(m.bias, 0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.shared(x)
        value = self.value_stream(features)
        advantage = self.advantage_stream(features)
        # Combine: subtract mean advantage for identifiability
        q = value + advantage - advantage.mean(dim=-1, keepdim=True)
        return q


# ─── HQ-Learning Agent ────────────────────────────────────────────────────────

class HQLearningAgent:
    """
    Hierarchical Q-Learning Agent with GNN-enhanced state.

    Coarse level: decides which NoC cluster to assign a task cluster to.
    Fine level:   decides which core within the NoC cluster to assign a task to.

    Both levels use Dueling DQN with experience replay and target networks.
    """

    def __init__(self,
                 # State dimensions
                 embedding_dim: int = 64,
                 num_clusters: int = 4,
                 num_cores_per_cluster: int = 16,
                 # Coarse level
                 coarse_state_extra_dim: int = 8,
                 # Fine level
                 fine_state_extra_dim: int = 8,
                 # Q-learning hyperparameters
                 lr: float = 1e-3,
                 gamma: float = 0.99,
                 epsilon_start: float = 1.0,
                 epsilon_end: float = 0.05,
                 epsilon_decay_steps: int = 50_000,
                 batch_size: int = 64,
                 target_update_freq: int = 500,
                 buffer_capacity: int = 50_000,
                 hidden_dims: List[int] = [256, 256, 128],
                 device: str = 'cpu',
                 seed: int = 42):

        self.num_clusters = num_clusters
        self.num_cores_per_cluster = num_cores_per_cluster
        self.gamma = gamma
        self.epsilon_start = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay_steps = epsilon_decay_steps
        self.batch_size = batch_size
        self.target_update_freq = target_update_freq
        self.device = torch.device(device)
        self.total_steps = 0

        torch.manual_seed(seed)
        np.random.seed(seed)

        # ── Coarse level ──────────────────────────────────────────────────
        # State: [task_cluster_embedding + graph_embedding + cluster_load_features]
        coarse_state_dim = embedding_dim + embedding_dim + coarse_state_extra_dim
        self.coarse_q = DuelingQNetwork(
            coarse_state_dim, num_clusters, hidden_dims
        ).to(self.device)
        self.coarse_q_target = DuelingQNetwork(
            coarse_state_dim, num_clusters, hidden_dims
        ).to(self.device)
        self.coarse_q_target.load_state_dict(self.coarse_q.state_dict())
        self.coarse_optimizer = optim.Adam(self.coarse_q.parameters(), lr=lr)
        self.coarse_buffer = ReplayBuffer(buffer_capacity, seed)

        # ── Fine level ────────────────────────────────────────────────────
        # State: [task_embedding + cluster_context + core_occupancy_features]
        fine_state_dim = embedding_dim + embedding_dim + fine_state_extra_dim
        self.fine_q = DuelingQNetwork(
            fine_state_dim, num_cores_per_cluster, hidden_dims
        ).to(self.device)
        self.fine_q_target = DuelingQNetwork(
            fine_state_dim, num_cores_per_cluster, hidden_dims
        ).to(self.device)
        self.fine_q_target.load_state_dict(self.fine_q.state_dict())
        self.fine_optimizer = optim.Adam(self.fine_q.parameters(), lr=lr)
        self.fine_buffer = ReplayBuffer(buffer_capacity, seed)

        # Loss function: Huber loss (more robust to outliers than MSE)
        self.loss_fn = nn.SmoothL1Loss()

        # Metrics
        self.coarse_losses = []
        self.fine_losses = []
        self.epsilon_history = []

    @property
    def epsilon(self) -> float:
        """Linearly decayed epsilon."""
        fraction = min(self.total_steps / self.epsilon_decay_steps, 1.0)
        return self.epsilon_start - fraction * (self.epsilon_start - self.epsilon_end)

    # ── Coarse level action selection ─────────────────────────────────────────

    def build_coarse_state(self,
                           task_cluster_emb: np.ndarray,
                           graph_emb: np.ndarray,
                           cluster_loads: np.ndarray,
                           fault_rates: np.ndarray) -> np.ndarray:
        """
        Build coarse-level state vector.
        cluster_loads: [num_clusters] normalized load per cluster
        fault_rates: [num_clusters] fault rate per cluster
        """
        extra = np.concatenate([cluster_loads, fault_rates])
        return np.concatenate([task_cluster_emb, graph_emb.squeeze(), extra]).astype(np.float32)

    def select_coarse_action(self, state: np.ndarray,
                              valid_clusters: Optional[List[int]] = None) -> int:
        """Epsilon-greedy action selection at coarse level."""
        if np.random.random() < self.epsilon:
            if valid_clusters:
                return np.random.choice(valid_clusters)
            return np.random.randint(self.num_clusters)

        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q_vals = self.coarse_q(state_t).squeeze(0).cpu().numpy()

        if valid_clusters is not None:
            mask = np.full(self.num_clusters, -np.inf)
            mask[valid_clusters] = q_vals[valid_clusters]
            return int(np.argmax(mask))
        return int(np.argmax(q_vals))

    # ── Fine level action selection ───────────────────────────────────────────

    def build_fine_state(self,
                         task_emb: np.ndarray,
                         cluster_emb: np.ndarray,
                         core_occupancy: np.ndarray,
                         core_fault_mask: np.ndarray) -> np.ndarray:
        """
        Build fine-level state vector.
        core_occupancy: [num_cores_per_cluster] 0/1 occupied
        core_fault_mask: [num_cores_per_cluster] 0/1 faulty
        """
        extra = np.concatenate([core_occupancy, core_fault_mask])
        return np.concatenate([task_emb, cluster_emb.squeeze(), extra]).astype(np.float32)

    def select_fine_action(self, state: np.ndarray,
                            valid_actions: Optional[List[int]] = None) -> int:
        """Epsilon-greedy action selection at fine level."""
        if np.random.random() < self.epsilon:
            if valid_actions:
                return np.random.choice(valid_actions)
            return np.random.randint(self.num_cores_per_cluster)

        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q_vals = self.fine_q(state_t).squeeze(0).cpu().numpy()

        if valid_actions is not None:
            mask = np.full(self.num_cores_per_cluster, -np.inf)
            for a in valid_actions:
                if a < self.num_cores_per_cluster:
                    mask[a] = q_vals[a]
            return int(np.argmax(mask))
        return int(np.argmax(q_vals))

    # ── Learning updates ──────────────────────────────────────────────────────

    def store_coarse(self, state, action, reward, next_state, done):
        self.coarse_buffer.push(state, action, reward, next_state, done)

    def store_fine(self, state, action, reward, next_state, done):
        self.fine_buffer.push(state, action, reward, next_state, done)

    def update_coarse(self) -> Optional[float]:
        """Single gradient update for coarse Q-network."""
        if len(self.coarse_buffer) < self.batch_size:
            return None
        return self._update_network(
            self.coarse_q, self.coarse_q_target,
            self.coarse_optimizer, self.coarse_buffer
        )

    def update_fine(self) -> Optional[float]:
        """Single gradient update for fine Q-network."""
        if len(self.fine_buffer) < self.batch_size:
            return None
        return self._update_network(
            self.fine_q, self.fine_q_target,
            self.fine_optimizer, self.fine_buffer
        )

    def _update_network(self,
                        q_net: nn.Module,
                        target_net: nn.Module,
                        optimizer: optim.Optimizer,
                        buffer: ReplayBuffer) -> float:
        """
        Double DQN update with proper next-state bootstrapping.
        Uses online network to SELECT best next action,
        target network to EVALUATE it — reduces overestimation bias.
        """
        transitions = buffer.sample(self.batch_size)
        batch = Transition(*zip(*transitions))

        states = torch.FloatTensor(np.array(batch.state)).to(self.device)
        actions = torch.LongTensor(batch.action).unsqueeze(1).to(self.device)
        rewards = torch.FloatTensor(batch.reward).to(self.device)
        next_states = torch.FloatTensor(np.array(batch.next_state)).to(self.device)
        dones = torch.FloatTensor(batch.done).to(self.device)

        # Current Q values
        current_q = q_net(states).gather(1, actions).squeeze(1)

        # Double DQN target: select action with online net, evaluate with target net
        with torch.no_grad():
            next_actions = q_net(next_states).argmax(dim=1, keepdim=True)
            next_q = target_net(next_states).gather(1, next_actions).squeeze(1)
            target_q = rewards + self.gamma * next_q * (1.0 - dones)

        loss = self.loss_fn(current_q, target_q)

        optimizer.zero_grad()
        loss.backward()
        # Gradient clipping for stability
        nn.utils.clip_grad_norm_(q_net.parameters(), max_norm=10.0)
        optimizer.step()

        return loss.item()

    def update_target_networks(self):
        """Hard update of target networks."""
        self.coarse_q_target.load_state_dict(self.coarse_q.state_dict())
        self.fine_q_target.load_state_dict(self.fine_q.state_dict())

    def soft_update_targets(self, tau: float = 0.005):
        """Soft update: θ_target = τ·θ_online + (1-τ)·θ_target"""
        for t_param, o_param in zip(self.coarse_q_target.parameters(),
                                    self.coarse_q.parameters()):
            t_param.data.copy_(tau * o_param.data + (1 - tau) * t_param.data)
        for t_param, o_param in zip(self.fine_q_target.parameters(),
                                    self.fine_q.parameters()):
            t_param.data.copy_(tau * o_param.data + (1 - tau) * t_param.data)

    def step_done(self):
        """Call after each environment step."""
        self.total_steps += 1

        # Soft target update every step
        self.soft_update_targets(tau=0.005)

        # Hard update periodically
        if self.total_steps % self.target_update_freq == 0:
            self.update_target_networks()

    def save(self, path: str):
        """Save agent weights."""
        torch.save({
            'coarse_q': self.coarse_q.state_dict(),
            'coarse_q_target': self.coarse_q_target.state_dict(),
            'fine_q': self.fine_q.state_dict(),
            'fine_q_target': self.fine_q_target.state_dict(),
            'total_steps': self.total_steps,
        }, path)
        print(f"Agent saved to {path}")

    def load(self, path: str):
        """Load agent weights."""
        checkpoint = torch.load(path, map_location=self.device)
        self.coarse_q.load_state_dict(checkpoint['coarse_q'])
        self.coarse_q_target.load_state_dict(checkpoint['coarse_q_target'])
        self.fine_q.load_state_dict(checkpoint['fine_q'])
        self.fine_q_target.load_state_dict(checkpoint['fine_q_target'])
        self.total_steps = checkpoint.get('total_steps', 0)
        print(f"Agent loaded from {path}")

    def set_eval_mode(self):
        """Set networks to eval mode (no dropout, greedy actions)."""
        self.coarse_q.eval()
        self.fine_q.eval()

    def set_train_mode(self):
        """Set networks to train mode."""
        self.coarse_q.train()
        self.fine_q.train()
