"""
NoC (Network-on-Chip) Environment for Reinforcement Learning
Implements a Gymnasium-compatible environment for task mapping on mesh NoC.
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces
from typing import Tuple, Dict, Optional, List


class NoCEnvironment(gym.Env):
    """
    Network-on-Chip Task Mapping Environment.

    State:
        - GNN embeddings of tasks (provided externally by GNN encoder)
        - Current mapping status (which cores are occupied)
        - Fault map (which cores are faulty)
        - Current task index being assigned

    Action:
        - Core ID to assign the current task to (within the active cluster)

    Reward:
        - Negative weighted sum of hop cost, energy, fault penalty, thermal imbalance
    """

    metadata = {"render_modes": ["human"]}

    def __init__(self,
                 N: int = 8,
                 num_tasks: int = 32,
                 num_clusters: int = 4,
                 fault_prob: float = 0.05,
                 w_hop: float = 0.5,
                 w_energy: float = 0.2,
                 w_fault: float = 0.2,
                 w_thermal: float = 0.1,
                 embedding_dim: int = 64,
                 seed: Optional[int] = None):

        super().__init__()

        self.N = N
        self.num_tasks = num_tasks
        self.num_clusters = num_clusters
        self.num_cores = N * N
        self.num_cores_per_cluster = self.num_cores // num_clusters
        self.fault_prob = fault_prob
        self.w_hop = w_hop
        self.w_energy = w_energy
        self.w_fault = w_fault
        self.w_thermal = w_thermal
        self.embedding_dim = embedding_dim

        # Cluster grid size
        self.cluster_grid = int(np.sqrt(num_clusters))  # e.g. 2 for 4 clusters

        # Action space: assign to one of the cores in the active cluster
        self.action_space = spaces.Discrete(self.num_cores_per_cluster)

        # Observation space:
        # [task_embedding(64) + cluster_load_features(num_clusters) + fault_features(num_clusters)]
        obs_dim = embedding_dim + num_clusters + num_clusters
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf,
            shape=(obs_dim,), dtype=np.float32
        )

        self.rng = np.random.default_rng(seed)

        # Will be set during reset
        self.comm_matrix = None
        self.fault_map = None
        self.mapping = None
        self.task_clusters = None
        self.task_to_cluster = None
        self.task_embeddings = None
        self.current_cluster_idx = 0
        self.current_task_idx_in_cluster = 0
        self.current_task = 0
        self.step_count = 0

    def set_task_data(self,
                      comm_matrix: np.ndarray,
                      task_clusters: List[List[int]],
                      task_to_cluster: np.ndarray,
                      task_embeddings: np.ndarray,
                      fault_map: Optional[np.ndarray] = None):
        """
        Inject task graph data and GNN embeddings before reset.
        Called by the trainer before each episode batch.
        """
        self.comm_matrix = comm_matrix.astype(np.float32)
        self.task_clusters = task_clusters
        self.task_to_cluster = task_to_cluster
        self.task_embeddings = task_embeddings.astype(np.float32)
        if fault_map is not None:
            self.fault_map = fault_map.astype(bool)

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)

        # Fresh mapping: 0 means unmapped
        self.mapping = np.zeros(self.num_tasks, dtype=np.int32)

        # Generate new fault map each episode (dynamic faults)
        if self.fault_map is None:
            self.fault_map = (self.rng.random(self.num_cores) < self.fault_prob)

        # Reset pointers
        self.current_cluster_idx = 0
        self.current_task_idx_in_cluster = 0
        self.step_count = 0

        # Set first task
        if self.task_clusters and len(self.task_clusters[0]) > 0:
            self.current_task = self.task_clusters[0][0]
        else:
            self.current_task = 0

        obs = self._get_observation()
        info = {"mapping": self.mapping.copy(), "step": self.step_count}
        return obs, info

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """
        Execute one task-to-core assignment.

        Args:
            action: local core index within the active cluster (0 to cores_per_cluster-1)

        Returns:
            observation, reward, terminated, truncated, info
        """
        # Map local action to global core ID
        noc_cluster = self.current_cluster_idx
        core_start = noc_cluster * self.num_cores_per_cluster
        action_clipped = int(np.clip(action, 0, self.num_cores_per_cluster - 1))
        global_core = core_start + action_clipped

        # Fault avoidance: if chosen core is faulty, find nearest healthy core in cluster
        if self.fault_map[global_core]:
            cluster_cores = np.arange(core_start, core_start + self.num_cores_per_cluster)
            healthy = cluster_cores[~self.fault_map[cluster_cores]]
            if len(healthy) > 0:
                # Pick healthy core with least load
                loads = np.array([np.sum(self.mapping == c) for c in healthy])
                global_core = healthy[np.argmin(loads)]
            # else: accept faulty core (no choice)

        # Uniqueness: if core already occupied, find next free core in cluster
        if np.any(self.mapping == global_core) and global_core != 0:
            cluster_cores = np.arange(core_start, core_start + self.num_cores_per_cluster)
            free_cores = [c for c in cluster_cores
                         if not np.any(self.mapping == c) and not self.fault_map[c]]
            if len(free_cores) > 0:
                global_core = free_cores[0]

        # Assign task to core (1-indexed to distinguish from "unmapped" = 0)
        self.mapping[self.current_task] = global_core + 1

        self.step_count += 1

        # Advance to next task
        terminated = self._advance_task_pointer()

        # Compute intermediate reward (incremental hop contribution)
        reward = self._compute_incremental_reward(self.current_task, global_core)

        # Final episode reward when all tasks mapped
        if terminated:
            reward += self._compute_final_reward()

        obs = self._get_observation()
        info = {
            "mapping": self.mapping.copy(),
            "step": self.step_count,
            "task": self.current_task,
            "core": global_core
        }
        return obs, reward, terminated, False, info

    def _advance_task_pointer(self) -> bool:
        """Move to next task. Returns True if all tasks are mapped."""
        cluster = self.task_clusters[self.current_cluster_idx]
        self.current_task_idx_in_cluster += 1

        if self.current_task_idx_in_cluster >= len(cluster):
            # Move to next cluster
            self.current_cluster_idx += 1
            self.current_task_idx_in_cluster = 0

            if self.current_cluster_idx >= self.num_clusters:
                return True  # All tasks mapped

        # Update current task
        cluster = self.task_clusters[self.current_cluster_idx]
        if len(cluster) > 0:
            self.current_task = cluster[self.current_task_idx_in_cluster]
        return False

    def _compute_incremental_reward(self, task: int, core: int) -> float:
        """
        Reward for placing 'task' on 'core' based on communication
        with already-placed tasks.
        """
        reward = 0.0
        core_x = core % self.N
        core_y = core // self.N

        for other_task in range(self.num_tasks):
            if other_task == task:
                continue
            other_core_1idx = self.mapping[other_task]
            if other_core_1idx == 0:
                continue
            other_core = other_core_1idx - 1
            comm = self.comm_matrix[task, other_task] + self.comm_matrix[other_task, task]
            if comm == 0:
                continue
            ox = other_core % self.N
            oy = other_core // self.N
            hops = abs(core_x - ox) + abs(core_y - oy)
            reward -= self.w_hop * comm * hops / (self.N * self.num_tasks)

        # Fault penalty
        if self.fault_map[core]:
            reward -= self.w_fault * 0.5

        return float(reward)

    def _compute_final_reward(self) -> float:
        """Full episode reward computed after all tasks are mapped."""
        mapping_0idx = self.mapping - 1  # Convert back to 0-indexed

        # Total weighted hop count
        total_hops = 0.0
        for i in range(self.num_tasks):
            for j in range(i + 1, self.num_tasks):
                if self.comm_matrix[i, j] > 0:
                    ci = mapping_0idx[i]
                    cj = mapping_0idx[j]
                    xi, yi = ci % self.N, ci // self.N
                    xj, yj = cj % self.N, cj // self.N
                    hops = abs(xi - xj) + abs(yi - yj)
                    total_hops += hops * (self.comm_matrix[i, j] + self.comm_matrix[j, i])

        hop_norm = total_hops / (self.num_tasks ** 2 * self.N)

        # Energy: proportional to hop count with router switching model
        energy_norm = total_hops * 0.5e-3 / self.num_tasks

        # Fault penalty
        fault_count = sum(1 for c in mapping_0idx if self.fault_map[c])
        fault_penalty = fault_count / self.num_tasks

        # Thermal imbalance: std of per-cluster load
        cluster_loads = np.zeros(self.num_clusters)
        for c in mapping_0idx:
            cid = c // self.num_cores_per_cluster
            cid = min(cid, self.num_clusters - 1)
            cluster_loads[cid] += 1
        thermal = np.std(cluster_loads) / (np.mean(cluster_loads) + 1e-6)

        # Load balance bonus
        load_balance_bonus = 0.2 * (1.0 - thermal / (self.num_tasks + 1e-6))

        reward = -(self.w_hop * hop_norm +
                   self.w_energy * energy_norm +
                   self.w_fault * fault_penalty +
                   self.w_thermal * thermal) + load_balance_bonus + 0.5

        return float(reward)

    def _get_observation(self) -> np.ndarray:
        """
        Build observation vector:
        [GNN embedding of current task | cluster loads | cluster fault rates]
        """
        if self.task_embeddings is not None:
            task_emb = self.task_embeddings[self.current_task]
        else:
            task_emb = np.zeros(self.embedding_dim, dtype=np.float32)

        # Cluster load features (normalized)
        cluster_loads = np.zeros(self.num_clusters, dtype=np.float32)
        for i, c_1idx in enumerate(self.mapping):
            if c_1idx > 0:
                c = c_1idx - 1
                cid = min(c // self.num_cores_per_cluster, self.num_clusters - 1)
                cluster_loads[cid] += 1
        cluster_loads /= (self.num_tasks + 1e-6)

        # Cluster fault rate features
        cluster_fault_rates = np.zeros(self.num_clusters, dtype=np.float32)
        for cid in range(self.num_clusters):
            start = cid * self.num_cores_per_cluster
            end = start + self.num_cores_per_cluster
            cluster_fault_rates[cid] = np.mean(self.fault_map[start:end])

        obs = np.concatenate([task_emb, cluster_loads, cluster_fault_rates])
        return obs.astype(np.float32)

    def compute_full_metrics(self, mapping_1idx: np.ndarray) -> Dict:
        """
        Compute all evaluation metrics for a given mapping.
        Used during evaluation, not training.
        """
        mapping_0idx = mapping_1idx - 1

        total_hops = 0.0
        for i in range(self.num_tasks):
            for j in range(i + 1, self.num_tasks):
                comm = self.comm_matrix[i, j] + self.comm_matrix[j, i]
                if comm > 0:
                    ci, cj = mapping_0idx[i], mapping_0idx[j]
                    xi, yi = ci % self.N, ci // self.N
                    xj, yj = cj % self.N, cj // self.N
                    hops = abs(xi - xj) + abs(yi - yj)
                    total_hops += hops * comm

        energy = total_hops * 0.5e-3
        fault_count = sum(1 for c in mapping_0idx if self.fault_map[c])
        reliability = 1.0 - fault_count / self.num_tasks

        cluster_loads = np.zeros(self.num_clusters)
        for c in mapping_0idx:
            cid = min(c // self.num_cores_per_cluster, self.num_clusters - 1)
            cluster_loads[cid] += 1
        thermal_imbalance = float(np.std(cluster_loads))

        # Thermal model: temperature proportional to load + neighbor communication heat
        core_temps = np.zeros(self.num_cores)
        for t, c in enumerate(mapping_0idx):
            core_temps[c] += 1.0
            for t2, c2 in enumerate(mapping_0idx):
                if t != t2 and self.comm_matrix[t, t2] > 0:
                    cx, cy = c % self.N, c // self.N
                    c2x, c2y = c2 % self.N, c2 // self.N
                    dist = abs(cx - c2x) + abs(cy - c2y)
                    if dist <= 2:
                        core_temps[c] += self.comm_matrix[t, t2] * 0.1

        duplicates = len(mapping_0idx) - len(np.unique(mapping_0idx))

        return {
            "hop_count": float(total_hops),
            "energy": float(energy),
            "reliability": float(reliability),
            "thermal_imbalance": float(thermal_imbalance),
            "max_core_temp": float(np.max(core_temps)),
            "avg_core_temp": float(np.mean(core_temps[core_temps > 0])),
            "duplicate_mappings": int(duplicates),
            "fault_count": int(fault_count),
            "cluster_loads": cluster_loads.tolist()
        }

    def get_mapping_grid(self) -> np.ndarray:
        """Return NxN grid showing which task is on each core (for visualization)."""
        grid = np.full((self.N, self.N), -1)
        for task, core_1idx in enumerate(self.mapping):
            if core_1idx > 0:
                core = core_1idx - 1
                x, y = core % self.N, core // self.N
                grid[y, x] = task
        return grid
