"""utils package — NoC utilities and visualisation."""
from .noc_utils import (generate_task_graph, generate_fault_map,
                         cluster_tasks_gnn, cluster_tasks_spectral,
                         cluster_tasks_kmeans, compute_hop_count,
                         compute_energy, compute_thermal_map,
                         compute_communication_graph_stats,
                         evaluate_mapping, baseline_nearest_neighbor,
                         baseline_first_fit, baseline_random)
from .visualization import (plot_training_curves, plot_comparison_bar,
                              plot_reliability_comparison, plot_noc_mapping,
                              plot_thermal_map, plot_scalability,
                              plot_fault_sensitivity, generate_latex_table)
__all__ = [
    "generate_task_graph","generate_fault_map","cluster_tasks_gnn",
    "cluster_tasks_spectral","cluster_tasks_kmeans","compute_hop_count",
    "compute_energy","compute_thermal_map","compute_communication_graph_stats",
    "evaluate_mapping","baseline_nearest_neighbor","baseline_first_fit",
    "baseline_random","plot_training_curves","plot_comparison_bar",
    "plot_reliability_comparison","plot_noc_mapping","plot_thermal_map",
    "plot_scalability","plot_fault_sensitivity","generate_latex_table",
]
