"""
Visualization module for NoC mapping results.
Produces publication-quality plots for the research paper.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import LinearSegmentedColormap
from typing import Dict, List, Optional
import os


# ── Style setup ───────────────────────────────────────────────────────────────

plt.rcParams.update({
    'font.family': 'serif',
    'font.size': 11,
    'axes.titlesize': 12,
    'axes.labelsize': 11,
    'legend.fontsize': 10,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'axes.grid': True,
    'grid.alpha': 0.3,
    'lines.linewidth': 1.8
})

COLORS = {
    'proposed': '#1f77b4',
    'nn': '#ff7f0e',
    'firstfit': '#2ca02c',
    'random': '#d62728',
    'flat_ql': '#9467bd',
    'hq': '#8c564b'
}


def plot_training_curves(metrics: Dict, output_dir: str = 'results'):
    """
    Plot training convergence curves.
    Shows reward, hop count, energy, reliability vs episode.
    """
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    fig.suptitle('GNN + HQ-Learning Training Curves', fontsize=14, fontweight='bold')

    # Smooth helper
    def smooth(x, w=20):
        if len(x) < w:
            return x
        return np.convolve(x, np.ones(w) / w, mode='valid')

    # Reward
    ax = axes[0, 0]
    rewards = metrics.get('rewards', [])
    if rewards:
        ax.plot(smooth(rewards), color=COLORS['proposed'], label='Smoothed')
        ax.plot(rewards, alpha=0.2, color=COLORS['proposed'])
    ax.set_xlabel('Episode')
    ax.set_ylabel('Episode Reward')
    ax.set_title('Training Reward')
    ax.legend()

    # Hop count during eval
    ax = axes[0, 1]
    hops = metrics.get('eval_hop_count', [])
    if hops:
        eval_eps = np.arange(1, len(hops) + 1) * 100
        ax.plot(eval_eps, hops, color=COLORS['proposed'], marker='o', markersize=4)
    ax.set_xlabel('Episode')
    ax.set_ylabel('Weighted Hop Count')
    ax.set_title('Hop Count (Eval)')

    # Energy
    ax = axes[0, 2]
    energy = metrics.get('eval_energy', [])
    if energy:
        ax.plot(eval_eps, energy, color=COLORS['nn'], marker='s', markersize=4)
    ax.set_xlabel('Episode')
    ax.set_ylabel('Energy (pJ)')
    ax.set_title('Energy Consumption (Eval)')

    # Reliability
    ax = axes[1, 0]
    rel = metrics.get('eval_reliability', [])
    if rel:
        ax.plot(eval_eps, [r * 100 for r in rel], color=COLORS['firstfit'], marker='^', markersize=4)
    ax.set_xlabel('Episode')
    ax.set_ylabel('Reliability (%)')
    ax.set_title('Reliability (Eval)')
    ax.set_ylim([0, 105])

    # Epsilon decay
    ax = axes[1, 1]
    eps = metrics.get('epsilon', [])
    if eps:
        ax.plot(eps, color=COLORS['random'], linewidth=1.5)
    ax.set_xlabel('Episode')
    ax.set_ylabel('Epsilon')
    ax.set_title('Exploration Rate')

    # Q-learning losses
    ax = axes[1, 2]
    cl = metrics.get('coarse_loss', [])
    fl = metrics.get('fine_loss', [])
    if cl:
        ax.plot(smooth(cl, 50), label='Coarse Q-loss', color=COLORS['proposed'])
    if fl:
        ax.plot(smooth(fl, 50), label='Fine Q-loss', color=COLORS['nn'])
    ax.set_xlabel('Update Step')
    ax.set_ylabel('Huber Loss')
    ax.set_title('Q-Network Loss')
    ax.legend()

    plt.tight_layout()
    path = os.path.join(output_dir, 'training_curves.png')
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def plot_comparison_bar(results: Dict, output_dir: str = 'results'):
    """
    Bar chart comparing all methods across all metrics.
    Primary figure for the paper's results section.
    """
    methods = list(results.keys())
    metrics_keys = ['hop_count', 'energy_pJ', 'thermal_imbalance', 'load_imbalance']
    metric_labels = ['Hop Count', 'Energy (pJ)', 'Thermal Imbalance', 'Load Imbalance']

    colors_list = [COLORS['proposed'], COLORS['nn'], COLORS['firstfit'], COLORS['random']]
    while len(colors_list) < len(methods):
        colors_list.append('#aaaaaa')

    fig, axes = plt.subplots(1, 4, figsize=(18, 5))
    fig.suptitle('Method Comparison — NoC Task Mapping', fontsize=13, fontweight='bold')

    x = np.arange(len(methods))
    for ax, key, label in zip(axes, metrics_keys, metric_labels):
        vals = [results[m][key] for m in methods]
        bars = ax.bar(x, vals, color=colors_list[:len(methods)], edgecolor='black',
                      linewidth=0.7, width=0.6)

        # Highlight minimum (best)
        best_idx = int(np.argmin(vals))
        bars[best_idx].set_edgecolor('red')
        bars[best_idx].set_linewidth(2.5)

        ax.set_xticks(x)
        ax.set_xticklabels(methods, rotation=30, ha='right', fontsize=9)
        ax.set_ylabel(label)
        ax.set_title(label)

        # Annotate values
        for i, (bar, v) in enumerate(zip(bars, vals)):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() * 1.02,
                    f'{v:.1f}', ha='center', va='bottom', fontsize=8)

    plt.tight_layout()
    path = os.path.join(output_dir, 'comparison_bar.png')
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def plot_reliability_comparison(results: Dict, output_dir: str = 'results'):
    """Reliability bar chart (higher is better — inverted axis logic)."""
    methods = list(results.keys())
    rel_vals = [results[m]['reliability'] * 100 for m in methods]
    colors_list = [COLORS['proposed'], COLORS['nn'], COLORS['firstfit'], COLORS['random']]
    while len(colors_list) < len(methods):
        colors_list.append('#aaaaaa')

    fig, ax = plt.subplots(figsize=(8, 5))
    x = np.arange(len(methods))
    bars = ax.bar(x, rel_vals, color=colors_list[:len(methods)],
                  edgecolor='black', linewidth=0.7, width=0.6)

    best_idx = int(np.argmax(rel_vals))
    bars[best_idx].set_edgecolor('red')
    bars[best_idx].set_linewidth(2.5)

    ax.set_xticks(x)
    ax.set_xticklabels(methods, rotation=25, ha='right')
    ax.set_ylabel('Reliability (%)')
    ax.set_title('Fault Tolerance — Task Reliability on Healthy Cores')
    ax.set_ylim([0, 110])

    for bar, v in zip(bars, rel_vals):
        ax.text(bar.get_x() + bar.get_width() / 2, v + 0.5,
                f'{v:.1f}%', ha='center', va='bottom', fontsize=9)

    plt.tight_layout()
    path = os.path.join(output_dir, 'reliability_comparison.png')
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def plot_noc_mapping(
        mapping: np.ndarray,
        fault_map: np.ndarray,
        task_to_cluster: np.ndarray,
        N: int,
        title: str = "NoC Task Mapping",
        output_dir: str = 'results',
        filename: str = 'noc_mapping.png'
):
    """
    Visualize which task is mapped to which core on the NoC mesh.
    Faulty cores shown in red. Task clusters shown in different colors.
    """
    num_clusters = len(set(task_to_cluster))
    cmap = plt.cm.get_cmap('tab10', num_clusters)

    fig, ax = plt.subplots(figsize=(10, 10))
    ax.set_xlim(-0.5, N - 0.5)
    ax.set_ylim(-0.5, N - 0.5)
    ax.set_aspect('equal')
    ax.set_title(title, fontsize=13, fontweight='bold', pad=15)

    # Draw grid
    for i in range(N + 1):
        ax.axhline(i - 0.5, color='gray', linewidth=0.4, alpha=0.5)
        ax.axvline(i - 0.5, color='gray', linewidth=0.4, alpha=0.5)

    # Build core -> task map
    core_to_task = {}
    for task, core_1idx in enumerate(mapping):
        if core_1idx > 0:
            core_to_task[core_1idx - 1] = task

    for core in range(N * N):
        x = core % N
        y = core // N

        if fault_map[core]:
            color = '#cc0000'
            alpha = 0.85
            label_text = 'F'
            text_color = 'white'
        elif core in core_to_task:
            task = core_to_task[core]
            cluster_id = int(task_to_cluster[task])
            color = cmap(cluster_id)
            alpha = 0.85
            label_text = str(task)
            text_color = 'black'
        else:
            color = '#e0e0e0'
            alpha = 0.5
            label_text = ''
            text_color = 'gray'

        rect = mpatches.FancyBboxPatch(
            (x - 0.42, y - 0.42), 0.84, 0.84,
            boxstyle="round,pad=0.05",
            facecolor=color, edgecolor='white',
            linewidth=1.2, alpha=alpha
        )
        ax.add_patch(rect)

        if label_text:
            ax.text(x, y, label_text, ha='center', va='center',
                    fontsize=8, fontweight='bold', color=text_color)

    # Labels
    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xlabel('Core X coordinate')
    ax.set_ylabel('Core Y coordinate')

    # Legend
    legend_patches = [mpatches.Patch(color=cmap(i), label=f'Cluster {i}')
                      for i in range(num_clusters)]
    legend_patches.append(mpatches.Patch(color='#cc0000', label='Faulty core'))
    legend_patches.append(mpatches.Patch(color='#e0e0e0', label='Idle core'))
    ax.legend(handles=legend_patches, loc='upper right',
              bbox_to_anchor=(1.18, 1.0), fontsize=9)

    plt.tight_layout()
    path = os.path.join(output_dir, filename)
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def plot_thermal_map(
        core_temps: np.ndarray,
        fault_map: np.ndarray,
        N: int,
        title: str = "Core Temperature Map",
        output_dir: str = 'results',
        filename: str = 'thermal_map.png'
):
    """Heatmap of core temperatures across the NoC mesh."""
    temp_grid = core_temps.reshape(N, N)

    fig, ax = plt.subplots(figsize=(8, 7))

    cmap = LinearSegmentedColormap.from_list(
        'thermal', ['#2166ac', '#4dac26', '#f7ef06', '#d7191c']
    )
    im = ax.imshow(temp_grid, cmap=cmap, interpolation='nearest', origin='lower')

    # Mark faulty cores
    for core in range(N * N):
        if fault_map[core]:
            x, y = core % N, core // N
            ax.add_patch(mpatches.Rectangle(
                (x - 0.5, y - 0.5), 1, 1,
                fill=False, edgecolor='black', linewidth=2.5,
                hatch='///'
            ))

    plt.colorbar(im, ax=ax, label='Relative Temperature (AU)')
    ax.set_title(title, fontsize=12, fontweight='bold')
    ax.set_xlabel('Core X')
    ax.set_ylabel('Core Y')

    plt.tight_layout()
    path = os.path.join(output_dir, filename)
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def plot_scalability(scalability_results: Dict, output_dir: str = 'results'):
    """
    Plot scalability: training time vs mesh size for all methods.
    Key figure for the scalability claim in the paper.
    """
    mesh_sizes = sorted(scalability_results.keys())
    methods = list(next(iter(scalability_results.values())).keys())

    colors_list = [COLORS['proposed'], COLORS['nn'], COLORS['firstfit'], COLORS['random']]

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle('Scalability Analysis', fontsize=13, fontweight='bold')

    # Hop count vs mesh size
    ax = axes[0]
    for i, method in enumerate(methods):
        vals = [scalability_results[sz][method]['hop_count'] for sz in mesh_sizes]
        ax.plot(mesh_sizes, vals, marker='o', label=method,
                color=colors_list[i % len(colors_list)])
    ax.set_xlabel('Mesh Size (N×N)')
    ax.set_ylabel('Weighted Hop Count')
    ax.set_title('Communication Cost vs Scale')
    ax.legend()
    ax.set_xticks(mesh_sizes)
    ax.set_xticklabels([f'{n}×{n}' for n in mesh_sizes])

    # Training time vs mesh size
    ax = axes[1]
    for i, method in enumerate(methods):
        if 'training_time' in next(iter(scalability_results.values()))[method]:
            times = [scalability_results[sz][method]['training_time'] for sz in mesh_sizes]
            ax.plot(mesh_sizes, times, marker='s', label=method,
                    color=colors_list[i % len(colors_list)])
    ax.set_xlabel('Mesh Size (N×N)')
    ax.set_ylabel('Training Time (s)')
    ax.set_title('Training Time vs Scale')
    ax.legend()
    ax.set_xticks(mesh_sizes)
    ax.set_xticklabels([f'{n}×{n}' for n in mesh_sizes])

    plt.tight_layout()
    path = os.path.join(output_dir, 'scalability.png')
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def plot_fault_sensitivity(fault_results: Dict, output_dir: str = 'results'):
    """
    Plot performance vs fault rate.
    Supports the fault tolerance claim in the paper.
    """
    fault_rates = sorted(fault_results.keys())
    methods = list(next(iter(fault_results.values())).keys())
    colors_list = [COLORS['proposed'], COLORS['nn'], COLORS['firstfit'], COLORS['random']]

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    fig.suptitle('Fault Sensitivity Analysis', fontsize=13, fontweight='bold')

    for i, method in enumerate(methods):
        hops = [fault_results[fr][method]['hop_count'] for fr in fault_rates]
        rel = [fault_results[fr][method]['reliability'] * 100 for fr in fault_rates]
        c = colors_list[i % len(colors_list)]

        axes[0].plot([fr * 100 for fr in fault_rates], hops,
                     marker='o', label=method, color=c)
        axes[1].plot([fr * 100 for fr in fault_rates], rel,
                     marker='s', label=method, color=c)

    axes[0].set_xlabel('Fault Rate (%)')
    axes[0].set_ylabel('Weighted Hop Count')
    axes[0].set_title('Communication Cost vs Fault Rate')
    axes[0].legend()

    axes[1].set_xlabel('Fault Rate (%)')
    axes[1].set_ylabel('Reliability (%)')
    axes[1].set_title('Reliability vs Fault Rate')
    axes[1].legend()
    axes[1].set_ylim([0, 105])

    plt.tight_layout()
    path = os.path.join(output_dir, 'fault_sensitivity.png')
    plt.savefig(path)
    print(f"Saved: {path}")
    plt.close()


def generate_latex_table(results: Dict) -> str:
    """Generate LaTeX table code for the paper."""
    lines = [
        r'\begin{table}[htbp]',
        r'\centering',
        r'\caption{Comparison of task mapping methods on 8$\times$8 NoC}',
        r'\label{tab:results}',
        r'\begin{tabular}{lrrrrr}',
        r'\hline',
        r'Method & Hop Count & Energy (pJ) & Reliability (\%) & Thermal & Load Imbal. \\',
        r'\hline',
    ]
    for method, m in results.items():
        row = (
            f"{method} & "
            f"{m['hop_count']:.2f} & "
            f"{m['energy_pJ']:.2f} & "
            f"{m['reliability']*100:.1f} & "
            f"{m['thermal_imbalance']:.3f} & "
            f"{m['load_imbalance']:.3f} \\\\"
        )
        lines.append(row)
    lines += [r'\hline', r'\end{tabular}', r'\end{table}']
    return '\n'.join(lines)
