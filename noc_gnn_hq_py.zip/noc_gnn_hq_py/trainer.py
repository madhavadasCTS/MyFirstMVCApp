"""
Trainer  —  GNN + Hierarchical Q-Learning  v2.0
================================================

Key fixes vs previous version:
  1. _update_gnn_with_clustering_loss now passes PyG Data object to
     clustering_loss() so gradients flow through GNN conv layers properly
  2. evaluate() no longer re-imports cluster_tasks_gnn inside the loop
  3. nn import removed (torch.nn.utils used via full path)
  4. cluster_tasks_gnn import hoisted to top level
  5. NoCEnvironment import removed (trainer doesn't use it directly)
  6. run_full_comparison: clear comments on all 6 ablation rows
"""

import torch
import torch.optim as optim
import numpy as np
import time
import json
import os
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

from models.gnn_encoder import (TaskGraphGNN, GNNClusteringModule,
                                 get_task_embeddings, get_task_embeddings_batched,
                                 build_graph_from_comm_matrix, NODE_FEATURE_DIM)
from models.hq_agent import HQLearningAgent
from utils.noc_utils import (
    generate_task_graph, generate_fault_map,
    cluster_tasks_gnn, cluster_tasks_kmeans,
    evaluate_mapping, compute_hop_count,
    baseline_nearest_neighbor, baseline_first_fit, baseline_random,
)


class GNNHQLearningTrainer:

    def __init__(self, config: Dict):
        self.config = config
        self.device = torch.device(
            'cuda' if torch.cuda.is_available() and config.get('use_gpu', True)
            else 'cpu')
        print(f"Device: {self.device}")

        self.N                     = config['N']
        self.num_tasks             = config['num_tasks']
        self.num_clusters          = config['num_clusters']
        self.num_cores             = self.N * self.N
        self.num_cores_per_cluster = self.num_cores // self.num_clusters
        self.fault_prob            = config['fault_prob']
        self.embedding_dim         = config.get('embedding_dim', 64)

        # ── GNN ──────────────────────────────────────────────────────────────
        self.gnn = TaskGraphGNN(
            node_feature_dim=NODE_FEATURE_DIM,
            hidden_dim      =config.get('gnn_hidden_dim', 128),
            embedding_dim   =self.embedding_dim,
            num_layers      =config.get('gnn_layers', 4),
            num_heads       =config.get('gnn_heads', 4),
            dropout         =config.get('gnn_dropout', 0.1),
        ).to(self.device)

        self.cluster_module = GNNClusteringModule(
            embedding_dim=self.embedding_dim,
            num_clusters =self.num_clusters,
        ).to(self.device)

        # Joint GNN + clustering module optimizer
        self.gnn_optimizer = optim.Adam(
            list(self.gnn.parameters()) + list(self.cluster_module.parameters()),
            lr=config.get('gnn_lr', 5e-4), weight_decay=1e-5)

        # ── HQ Agent ─────────────────────────────────────────────────────────
        coarse_extra = self.num_clusters * 2           # cluster_loads + fault_rates
        fine_extra   = self.num_cores_per_cluster * 2  # core_occupancy + fault_mask

        self.agent = HQLearningAgent(
            embedding_dim          =self.embedding_dim,
            num_clusters           =self.num_clusters,
            num_cores_per_cluster  =self.num_cores_per_cluster,
            coarse_state_extra_dim =coarse_extra,
            fine_state_extra_dim   =fine_extra,
            lr                     =config.get('lr', 1e-3),
            gamma                  =config.get('gamma', 0.99),
            epsilon_start          =config.get('epsilon_start', 1.0),
            epsilon_end            =config.get('epsilon_end', 0.05),
            epsilon_decay_steps    =config.get('epsilon_decay_steps', 30_000),
            batch_size             =config.get('batch_size', 64),
            target_update_freq     =config.get('target_update_freq', 500),
            buffer_capacity        =config.get('buffer_capacity', 50_000),
            hidden_dims            =config.get('hidden_dims', [256, 256, 128]),
            device                 =str(self.device),
            seed                   =config.get('seed', 42),
        )

        self.metrics           = defaultdict(list)
        self.best_hop_count    = float('inf')
        self.best_eval_metrics = None
        self.output_dir        = config.get('output_dir', 'results')
        os.makedirs(self.output_dir, exist_ok=True)

    # ── GNN helpers ───────────────────────────────────────────────────────────

    def get_embeddings_and_clusters(self, comm_matrix: np.ndarray
                                     ) -> Tuple[np.ndarray, np.ndarray,
                                                List[List[int]], np.ndarray]:
        """Run GNN (no_grad) and cluster tasks using Spectral Clustering."""
        node_emb, graph_emb = get_task_embeddings(self.gnn, comm_matrix, self.device)
        task_clusters, task_to_cluster = cluster_tasks_gnn(
            node_emb, self.num_clusters, seed=self.config.get('seed', 42))
        return node_emb, graph_emb, task_clusters, task_to_cluster

    def get_cluster_embedding(self, node_emb: np.ndarray,
                               task_cluster: List[int]) -> np.ndarray:
        if not task_cluster:
            return np.zeros(self.embedding_dim, dtype=np.float32)
        return node_emb[task_cluster].mean(axis=0)

    def _update_gnn_with_clustering_loss(self,
                                          comm_matrix: np.ndarray) -> float:
        """
        One gradient step on GNN + clustering module.

        FIXED: passes PyG Data object to clustering_loss() which re-runs
        the GNN forward pass with gradients enabled. This ensures gradients
        flow through the GNN convolutional layers, not just the cluster head.
        """
        self.gnn.train()
        self.cluster_module.train()

        # Build PyG data (CPU tensors; move to device inside clustering_loss)
        data      = build_graph_from_comm_matrix(comm_matrix)
        data.x          = data.x.to(self.device)
        data.edge_index = data.edge_index.to(self.device)
        data.edge_attr  = data.edge_attr.to(self.device)
        data.edge_weight= data.edge_weight.to(self.device)
        comm_t    = torch.tensor(comm_matrix, dtype=torch.float32, device=self.device)

        cl_loss   = self.cluster_module.clustering_loss(self.gnn, data, comm_t)

        self.gnn_optimizer.zero_grad()
        cl_loss.backward()
        torch.nn.utils.clip_grad_norm_(
            list(self.gnn.parameters()) + list(self.cluster_module.parameters()),
            max_norm=5.0)
        self.gnn_optimizer.step()
        return float(cl_loss.item())

    # ── Episode rollout ───────────────────────────────────────────────────────

    def run_episode(self, comm_matrix: np.ndarray, fault_map: np.ndarray,
                    node_emb: np.ndarray, graph_emb: np.ndarray,
                    task_clusters: List[List[int]],
                    training: bool = True) -> Tuple[np.ndarray, float, Dict]:

        mapping           = np.zeros(self.num_tasks, dtype=np.int32)
        total_reward      = 0.0
        coarse_experiences = []
        fine_experiences   = []
        cluster_occupied   = [set() for _ in range(self.num_clusters)]

        for tc_idx, task_list in enumerate(task_clusters):
            if not task_list:
                continue

            cluster_emb = self.get_cluster_embedding(node_emb, task_list)

            cluster_loads = np.array([
                len(cluster_occupied[cid]) / self.num_cores_per_cluster
                for cid in range(self.num_clusters)], dtype=np.float32)

            cluster_fault_rates = np.array([
                fault_map[cid * self.num_cores_per_cluster:
                           (cid + 1) * self.num_cores_per_cluster].mean()
                for cid in range(self.num_clusters)], dtype=np.float32)

            coarse_state = self.agent.build_coarse_state(
                cluster_emb, graph_emb.squeeze(),
                cluster_loads, cluster_fault_rates)

            valid_noc = [cid for cid in range(self.num_clusters)
                          if len(cluster_occupied[cid]) + len(task_list)
                          <= self.num_cores_per_cluster
                         ] or list(range(self.num_clusters))

            noc_cluster = self.agent.select_coarse_action(coarse_state, valid_noc)
            cs = noc_cluster * self.num_cores_per_cluster

            for task in task_list:
                task_emb = node_emb[task]
                occ  = np.array([
                    1.0 if (cs + i) in cluster_occupied[noc_cluster] else 0.0
                    for i in range(self.num_cores_per_cluster)], dtype=np.float32)
                fmsk = fault_map[cs:cs + self.num_cores_per_cluster].astype(np.float32)

                fine_state = self.agent.build_fine_state(
                    task_emb, cluster_emb, occ, fmsk)

                healthy_free = [i for i in range(self.num_cores_per_cluster)
                                 if (cs + i) not in cluster_occupied[noc_cluster]
                                 and not fault_map[cs + i]]
                free_any = [i for i in range(self.num_cores_per_cluster)
                             if (cs + i) not in cluster_occupied[noc_cluster]]
                valid_fine = (healthy_free or free_any
                              or list(range(self.num_cores_per_cluster)))

                local_action = self.agent.select_fine_action(fine_state, valid_fine)
                global_core  = cs + local_action
                mapping[task] = global_core + 1   # 1-indexed
                cluster_occupied[noc_cluster].add(global_core)

                reward = self._incremental_reward(
                    task, global_core, mapping, comm_matrix, fault_map)
                total_reward += reward

                occ[local_action] = 1.0
                next_fine = self.agent.build_fine_state(
                    task_emb, cluster_emb, occ, fmsk)
                fine_experiences.append(
                    (fine_state, local_action, reward, next_fine, False))

            coarse_reward = self._coarse_reward(
                task_list, noc_cluster, mapping, comm_matrix, fault_map)
            total_reward += coarse_reward

            cluster_loads[noc_cluster] = (len(cluster_occupied[noc_cluster])
                                           / self.num_cores_per_cluster)
            next_coarse = self.agent.build_coarse_state(
                cluster_emb, graph_emb.squeeze(),
                cluster_loads, cluster_fault_rates)
            done = (tc_idx == len(task_clusters) - 1)
            coarse_experiences.append(
                (coarse_state, noc_cluster, coarse_reward, next_coarse, done))

        final_reward = self._final_reward(mapping, comm_matrix, fault_map)
        total_reward += final_reward

        if fine_experiences:
            s, a, r, ns, _ = fine_experiences[-1]
            fine_experiences[-1] = (s, a, r + final_reward, ns, True)

        if training:
            for exp in coarse_experiences:
                self.agent.store_coarse(*exp)
            for exp in fine_experiences:
                self.agent.store_fine(*exp)

        return mapping, total_reward, {}

    # ── Reward components ─────────────────────────────────────────────────────

    def _incremental_reward(self, task, core, mapping,
                             comm_matrix, fault_map) -> float:
        N, reward = self.N, 0.0
        cx, cy    = core % N, core // N
        for other in range(self.num_tasks):
            if other == task or mapping[other] == 0:
                continue
            comm = comm_matrix[task, other] + comm_matrix[other, task]
            if comm == 0:
                continue
            oc   = mapping[other] - 1
            hops = abs(cx - oc % N) + abs(cy - oc // N)
            reward -= 0.01 * comm * hops / (N * self.num_tasks)
        if fault_map[core]:
            reward -= 0.1
        return float(reward)

    def _coarse_reward(self, task_list, noc_cluster, mapping,
                        comm_matrix, fault_map) -> float:
        N, cost = self.N, 0.0
        for i in task_list:
            for j in task_list:
                if (i == j or not comm_matrix[i, j]
                        or not mapping[i] or not mapping[j]):
                    continue
                ci, cj = mapping[i] - 1, mapping[j] - 1
                hops   = abs(ci % N - cj % N) + abs(ci // N - cj // N)
                cost  += comm_matrix[i, j] * hops
        cs         = noc_cluster * self.num_cores_per_cluster
        fault_rate = fault_map[cs:cs + self.num_cores_per_cluster].mean()
        return float(-0.05 * cost / (len(task_list) ** 2 + 1e-6)
                     - 0.05 * fault_rate)

    def _final_reward(self, mapping, comm_matrix, fault_map) -> float:
        hop_count = compute_hop_count(mapping, comm_matrix, self.N)
        norm_hop  = hop_count / (self.num_tasks ** 2 * self.N)
        mapped    = mapping[mapping > 0] - 1
        fault_pen = float(fault_map[mapped].sum()) / self.num_tasks
        unique    = len(np.unique(mapped))
        dup_pen   = (self.num_tasks - unique) / self.num_tasks * 0.5
        r = -(self.config['w_hop'] * norm_hop
              + self.config['w_fault'] * fault_pen + dup_pen)
        if fault_pen == 0 and unique == self.num_tasks:
            r += 0.5
        return float(r)

    # ── Training ──────────────────────────────────────────────────────────────

    def train(self, num_episodes: int = 2000, eval_interval: int = 100):
        print(f"\n{'='*70}")
        print(f"GNN + HQ-Learning  v2.0  (Spectral + networkx + joint GNN training)")
        print(f"NoC {self.N}×{self.N} | {self.num_tasks} tasks | "
              f"{self.num_clusters} clusters | device={self.device}")
        print(f"{'='*70}\n")

        t0       = time.time()
        eval_cms = [generate_task_graph(self.num_tasks, seed=i + 1000)
                    for i in range(5)]
        eval_fms = [generate_fault_map(self.num_cores, self.fault_prob,
                                        N=self.N, seed=i + 2000)
                    for i in range(5)]

        for ep in range(1, num_episodes + 1):
            comm_matrix = generate_task_graph(self.num_tasks)
            fault_map   = generate_fault_map(self.num_cores, self.fault_prob,
                                              N=self.N)

            # ── Joint GNN update (gradients flow through conv layers) ─────────
            cl_loss = self._update_gnn_with_clustering_loss(comm_matrix)

            # ── Get embeddings for RL episode (no_grad, fast) ─────────────────
            node_emb, graph_emb, task_clusters, _ = \
                self.get_embeddings_and_clusters(comm_matrix)

            # ── RL episode ────────────────────────────────────────────────────
            self.agent.set_train_mode()
            mapping, total_reward, _ = self.run_episode(
                comm_matrix, fault_map, node_emb, graph_emb,
                task_clusters, training=True)

            coarse_loss = self.agent.update_coarse()
            fine_loss   = self.agent.update_fine()
            self.agent.step_done()

            self.metrics['rewards'].append(total_reward)
            self.metrics['epsilon'].append(self.agent.epsilon)
            self.metrics['clustering_loss'].append(cl_loss)
            if coarse_loss:
                self.metrics['coarse_loss'].append(coarse_loss)
            if fine_loss:
                self.metrics['fine_loss'].append(fine_loss)

            if ep % eval_interval == 0:
                eval_res = self.evaluate(eval_cms, eval_fms)
                self.metrics['eval_hop_count'].append(eval_res['mean_hop_count'])
                self.metrics['eval_energy'].append(eval_res['mean_energy'])
                self.metrics['eval_reliability'].append(eval_res['mean_reliability'])
                self.metrics['eval_thermal'].append(eval_res['mean_thermal_imbalance'])

                print(
                    f"Ep {ep:4d}/{num_episodes} | "
                    f"R={np.mean(self.metrics['rewards'][-eval_interval:]):6.3f} | "
                    f"Hops={eval_res['mean_hop_count']:8.2f} | "
                    f"E={eval_res['mean_energy']:7.1f}pJ | "
                    f"Rel={eval_res['mean_reliability']*100:5.1f}% | "
                    f"Therm={eval_res['mean_thermal_imbalance']:5.2f} | "
                    f"CLoss={cl_loss:.4f} | "
                    f"ε={self.agent.epsilon:.3f} | "
                    f"t={time.time()-t0:.0f}s"
                )

                if eval_res['mean_hop_count'] < self.best_hop_count:
                    self.best_hop_count    = eval_res['mean_hop_count']
                    self.best_eval_metrics = eval_res
                    self._save_best()

        self.metrics['training_time'] = time.time() - t0
        print(f"\nTraining done in {self.metrics['training_time']:.1f}s  "
              f"| best hop count: {self.best_hop_count:.2f}")
        self._save_metrics()
        return self.metrics

    # ── Evaluation ────────────────────────────────────────────────────────────

    def evaluate(self, comm_matrices: List[np.ndarray],
                  fault_maps: List[np.ndarray]) -> Dict:
        """Evaluate on fixed graphs using batched GNN inference."""
        self.agent.set_eval_mode()
        self.gnn.eval()

        # Batched GNN forward (single pass for all eval graphs)
        node_embs, graph_embs = get_task_embeddings_batched(
            self.gnn, comm_matrices, self.device)

        all_metrics = []
        for i, (cm, fm) in enumerate(zip(comm_matrices, fault_maps)):
            ne = node_embs[i]
            ge = graph_embs[i:i + 1]   # shape [1, embedding_dim]
            tc, _ = cluster_tasks_gnn(
                ne, self.num_clusters, seed=self.config.get('seed', 42))
            with torch.no_grad():
                mapping, _, _ = self.run_episode(
                    cm, fm, ne, ge, tc, training=False)
            all_metrics.append(
                evaluate_mapping(mapping, cm, fm, self.N, self.num_clusters))

        self.agent.set_train_mode()
        self.gnn.train()

        return {
            'mean_hop_count':          float(np.mean([m['hop_count']             for m in all_metrics])),
            'mean_energy':             float(np.mean([m['energy_pJ']             for m in all_metrics])),
            'mean_reliability':        float(np.mean([m['reliability']           for m in all_metrics])),
            'mean_thermal_imbalance':  float(np.mean([m['thermal_imbalance']     for m in all_metrics])),
            'mean_load_imbalance':     float(np.mean([m['load_imbalance']        for m in all_metrics])),
            'mean_duplicates':         float(np.mean([m['duplicate_assignments'] for m in all_metrics])),
            'per_graph': all_metrics,
        }

    # ── Full comparison ───────────────────────────────────────────────────────

    def run_full_comparison(self, comm_matrix: Optional[np.ndarray] = None,
                             fault_map: Optional[np.ndarray] = None,
                             seed: int = 999) -> Dict:
        """
        Run all 6 methods on the same task graph. Results table for paper.

        1. GNN+HQ+Spectral  — proposed full system
        2. GNN+HQ+KMeans    — ablation: Spectral → KMeans (isolates Spectral gain)
        3. HQ Only          — ablation: zero GNN embeddings (isolates GNN gain)
        4. Nearest Neighbor — networkx-enhanced heuristic
        5. First Fit        — simple baseline
        6. Random           — lower bound
        """
        if comm_matrix is None:
            comm_matrix = generate_task_graph(self.num_tasks, seed=seed)
        if fault_map is None:
            fault_map = generate_fault_map(
                self.num_cores, self.fault_prob, N=self.N, seed=seed)

        self._load_best()
        self.agent.set_eval_mode()
        self.gnn.eval()
        results = {}

        # 1 — Proposed
        ne, ge, tc, _ = self.get_embeddings_and_clusters(comm_matrix)
        with torch.no_grad():
            m, _, _ = self.run_episode(comm_matrix, fault_map, ne, ge, tc, False)
        results['GNN+HQ+Spectral (Proposed)'] = evaluate_mapping(
            m, comm_matrix, fault_map, self.N, self.num_clusters)

        # 2 — KMeans clustering ablation
        ne2, ge2 = get_task_embeddings(self.gnn, comm_matrix, self.device)
        tc2, _   = cluster_tasks_kmeans(
            comm_matrix, self.num_clusters, seed=self.config.get('seed', 42))
        with torch.no_grad():
            m2, _, _ = self.run_episode(comm_matrix, fault_map, ne2, ge2, tc2, False)
        results['GNN+HQ+KMeans'] = evaluate_mapping(
            m2, comm_matrix, fault_map, self.N, self.num_clusters)

        # 3 — HQ only (zero embeddings = no GNN signal)
        zero_ne = np.zeros_like(ne)
        zero_ge = np.zeros_like(ge)
        with torch.no_grad():
            m3, _, _ = self.run_episode(
                comm_matrix, fault_map, zero_ne, zero_ge, tc, False)
        results['HQ Only (no GNN)'] = evaluate_mapping(
            m3, comm_matrix, fault_map, self.N, self.num_clusters)

        # 4 — Nearest Neighbor
        nn_m = baseline_nearest_neighbor(
            comm_matrix, tc, fault_map, self.N, self.num_clusters)
        results['Nearest Neighbor'] = evaluate_mapping(
            nn_m, comm_matrix, fault_map, self.N, self.num_clusters)

        # 5 — First Fit
        ff_m = baseline_first_fit(comm_matrix, fault_map, self.N)
        results['First Fit'] = evaluate_mapping(
            ff_m, comm_matrix, fault_map, self.N, self.num_clusters)

        # 6 — Random
        rand_m = baseline_random(self.num_tasks, fault_map, seed=seed)
        results['Random'] = evaluate_mapping(
            rand_m, comm_matrix, fault_map, self.N, self.num_clusters)

        return results

    def print_comparison_table(self, results: Dict):
        print(f"\n{'='*90}")
        print("RESULTS COMPARISON TABLE")
        print(f"{'='*90}")
        print(f"{'Method':<32} {'HopCount':>10} {'Energy(pJ)':>12} "
              f"{'Reliability':>12} {'Thermal':>10} {'LoadImbal':>10}")
        print('-' * 90)
        first = True
        for method, m in results.items():
            marker = ' ◀ proposed' if first else ''
            print(f"{method:<32} {m['hop_count']:>10.2f} {m['energy_pJ']:>12.2f} "
                  f"{m['reliability']*100:>11.1f}% {m['thermal_imbalance']:>10.3f} "
                  f"{m['load_imbalance']:>10.3f}{marker}")
            first = False
        print('=' * 90)

        keys = list(results.keys())
        if len(keys) >= 4:
            p  = results[keys[0]]['hop_count']
            nn = results[keys[3]]['hop_count']
            print(f"\n{keys[0]} vs {keys[3]}: "
                  f"{(nn - p)/nn*100:+.1f}% hop count improvement")

    # ── Persistence ───────────────────────────────────────────────────────────

    def _save_best(self):
        self.agent.save(os.path.join(self.output_dir, 'best_agent.pth'))
        torch.save(self.gnn.state_dict(),
                   os.path.join(self.output_dir, 'best_gnn.pth'))
        torch.save(self.cluster_module.state_dict(),
                   os.path.join(self.output_dir, 'best_cluster_module.pth'))

    def _load_best(self):
        for path, target in [
            ('best_agent.pth',          lambda p: self.agent.load(p)),
            ('best_gnn.pth',            lambda p: self.gnn.load_state_dict(
                torch.load(p, map_location=self.device))),
            ('best_cluster_module.pth', lambda p: self.cluster_module.load_state_dict(
                torch.load(p, map_location=self.device))),
        ]:
            full = os.path.join(self.output_dir, path)
            if os.path.exists(full):
                target(full)

    def _save_metrics(self):
        path = os.path.join(self.output_dir, 'training_metrics.json')
        with open(path, 'w') as f:
            json.dump({k: [float(x) for x in v] if isinstance(v, list) else v
                       for k, v in self.metrics.items()}, f, indent=2)
        print(f"Metrics → {path}")
