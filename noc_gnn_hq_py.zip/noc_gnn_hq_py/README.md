# GNN + Hierarchical Q-Learning for NoC Task Mapping

**GNN-HQ-Map** — A novel hybrid approach combining Graph Neural Networks (GNN)
and Hierarchical Q-Learning for intelligent, fault-tolerant task mapping on
Network-on-Chip (NoC) based multicore systems.

---

## Overview

This system optimizes task-to-core assignments on mesh NoC architectures by:

1. **GNN Encoder** — Models the task communication graph using Graph Attention Networks,
   producing rich task embeddings that capture communication neighborhoods
2. **GNN-guided Clustering** — Uses learned embeddings to cluster highly communicating
   tasks together (replaces naive k-means on raw matrix)
3. **Hierarchical Q-Learning** — Two-level decision making:
   - **Coarse level**: assigns task clusters to NoC regions (cluster-to-cluster)
   - **Fine level**: assigns individual tasks to cores within a region (task-to-core)
4. **Double Dueling DQN** — Neural Q-functions with Dueling architecture and Double
   DQN updates for stable, unbiased learning

**Optimizes simultaneously:**
- Communication latency (weighted hop count)
- Energy consumption (router switching model)
- Thermal balance (load + communication heat model)
- Fault tolerance (learned during training, not post-hoc)

---

## Project Structure

```
noc_gnn_hq/
├── main.py                     # Entry point, all experiments
├── trainer.py                  # Main training loop (GNN + HQ-Learning)
├── requirements.txt
├── models/
│   ├── gnn_encoder.py          # Graph Attention Network encoder
│   └── hq_agent.py             # Hierarchical Q-Learning agent (Dueling DQN)
├── environment/
│   └── noc_env.py              # Gymnasium-compatible NoC environment
└── utils/
    ├── noc_utils.py            # Task graph, metrics, baselines
    └── visualization.py        # All plotting (paper-ready figures)
```

---

## Installation

### Step 1 — Python environment
```bash
conda create -n noc_gnn python=3.10
conda activate noc_gnn
```

### Step 2 — PyTorch (choose your CUDA version)
```bash
# CPU only
pip install torch==2.1.0 --index-url https://download.pytorch.org/whl/cpu

# CUDA 11.8
pip install torch==2.1.0 --index-url https://download.pytorch.org/whl/cu118

# CUDA 12.1
pip install torch==2.1.0 --index-url https://download.pytorch.org/whl/cu121
```

### Step 3 — PyTorch Geometric
```bash
pip install torch-geometric
pip install torch-scatter torch-sparse -f https://data.pyg.org/whl/torch-2.1.0+cpu.html
# Replace +cpu with +cu118 or +cu121 for GPU
```

### Step 4 — Remaining dependencies
```bash
pip install -r requirements.txt
```

### Step 5 — Google Colab (alternative)
```python
# Run these in a Colab cell
!pip install torch-geometric
!pip install torch-scatter torch-sparse -f https://data.pyg.org/whl/torch-2.1.0+cu118.html
!pip install gymnasium scikit-learn networkx
```

---

## Quick Start

### Basic training and evaluation
```bash
cd noc_gnn_hq
python main.py
```

### Custom mesh size
```bash
python main.py --N 16 --num_tasks 64 --episodes 3000
```

### Evaluation only (after training)
```bash
python main.py --mode eval
```

### Scalability experiment (for paper)
```bash
python main.py --mode scalability
```

### Fault sensitivity experiment (for paper)
```bash
python main.py --mode fault_sens
```

---

## Configuration

All parameters are in `main.py` under `DEFAULT_CONFIG`:

```python
DEFAULT_CONFIG = {
    # NoC mesh
    'N': 8,                    # Mesh size: N×N cores
    'num_tasks': 32,           # Number of application tasks
    'num_clusters': 4,         # Hierarchical partitions

    # Fault model
    'fault_prob': 0.05,        # 5% core failure rate

    # Reward weights (must be considered together)
    'w_hop': 0.5,              # Latency importance
    'w_energy': 0.2,           # Energy importance
    'w_fault': 0.2,            # Fault tolerance importance
    'w_thermal': 0.1,          # Thermal balance importance

    # GNN
    'embedding_dim': 64,
    'gnn_hidden_dim': 128,
    'gnn_layers': 3,
    'use_attention': True,     # GAT (True) or GCN (False)

    # Q-Learning
    'lr': 1e-3,
    'gamma': 0.99,
    'epsilon_start': 1.0,
    'epsilon_end': 0.05,
    'epsilon_decay_steps': 30000,
    'batch_size': 64,
    'hidden_dims': [256, 256, 128],
}
```

---

## Outputs

After running, the `results/` directory contains:

| File | Description |
|------|-------------|
| `best_agent.pth` | Best trained HQ-Learning weights |
| `best_gnn.pth` | Best trained GNN weights |
| `training_curves.png` | Reward, hop count, energy, loss over training |
| `comparison_bar.png` | Bar chart of all methods across all metrics |
| `reliability_comparison.png` | Fault tolerance comparison |
| `noc_mapping.png` | Visual NoC grid showing task placement |
| `thermal_map.png` | Heatmap of core temperatures |
| `results_table.tex` | LaTeX table ready for paper |
| `training_metrics.json` | Full training data for custom analysis |
| `config.json` | Experiment configuration |

---

## Algorithm Details

### GNN Encoder
- **Architecture**: 3-layer Graph Attention Network (GAT)
- **Node features**: degree, communication volume, max edge weight, task index, density (8 features)
- **Output**: 64-dimensional task embeddings + global graph embedding
- **Why GAT over GCN**: attention weights learn which neighbors matter most for each task

### Hierarchical Q-Learning
- **Coarse Q-network**: input = [cluster_embedding + graph_embedding + load_features]
- **Fine Q-network**: input = [task_embedding + cluster_embedding + occupancy_features]
- **Architecture**: Dueling DQN (separates state value V(s) and advantage A(s,a))
- **Update rule**: Double DQN (online net selects action, target net evaluates it)
- **Replay buffer**: 50,000 transitions, uniform sampling

### Reward Function
```
R = -(w_hop × normalized_hop_count
    + w_energy × normalized_energy
    + w_fault × fault_penalty
    + w_thermal × thermal_imbalance)
  + load_balance_bonus
  + completion_bonus
```

### Fault Tolerance
- Faults injected randomly at the start of each training episode
- Agent learns to prefer healthy cores organically through negative reward
- At inference: healthy core preference enforced via action masking

---

## Research Contributions

This implementation supports the following paper claims:

1. **Novelty**: First combination of GNN-guided hierarchical RL for NoC mapping
   where GNN embeddings replace hand-crafted state features at both hierarchy levels

2. **Scalability**: Hierarchical decomposition scales linearly with mesh size;
   test with `python main.py --mode scalability`

3. **Fault tolerance**: Training-time fault injection produces inherently fault-aware
   policies; test with `python main.py --mode fault_sens`

4. **Multi-objective**: Single reward jointly optimizes latency, energy, and thermal
   balance without post-hoc constraint satisfaction

---

## Citing

If you use this code in your research:
```bibtex
@article{your_name_2025_noc,
  title={GNN-Guided Hierarchical Q-Learning for Fault-Tolerant NoC Task Mapping},
  author={Your Name},
  journal={IEEE Transactions on Computer-Aided Design},
  year={2025}
}
```

---

## Troubleshooting

**`torch_geometric` import error**:
Make sure torch-scatter and torch-sparse versions match your PyTorch version.
See: https://data.pyg.org/whl/

**CUDA out of memory**:
Reduce `batch_size` to 32 or use `--no_gpu` flag.

**Results vary between runs**:
Set `--seed 42` for reproducibility. GNN embeddings use random initialization
so results will differ without a fixed seed.

**Training too slow**:
Reduce `--episodes 500` for a quick test. Full training (2000 episodes) takes
approximately 5-15 minutes depending on hardware.
