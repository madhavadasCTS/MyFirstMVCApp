"""
GNN + Hierarchical Q-Learning for NoC Task Mapping  v2.0
=========================================================
Usage:
    from trainer import GNNHQLearningTrainer
    from utils.noc_utils import generate_task_graph, evaluate_mapping
"""
from trainer import GNNHQLearningTrainer
from utils.noc_utils import (generate_task_graph, generate_fault_map,
                              evaluate_mapping, compute_hop_count,
                              compute_energy, compute_thermal_map,
                              compute_communication_graph_stats)
from models.gnn_encoder import (TaskGraphGNN, GNNClusteringModule,
                                 get_task_embeddings, get_task_embeddings_batched,
                                 NODE_FEATURE_DIM)
from models.hq_agent import HQLearningAgent

__version__ = "2.0.0"
__all__ = [
    "GNNHQLearningTrainer", "TaskGraphGNN", "GNNClusteringModule",
    "HQLearningAgent", "get_task_embeddings", "get_task_embeddings_batched",
    "NODE_FEATURE_DIM", "generate_task_graph", "generate_fault_map",
    "evaluate_mapping", "compute_hop_count", "compute_energy",
    "compute_thermal_map", "compute_communication_graph_stats",
]
