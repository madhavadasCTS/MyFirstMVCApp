"""
Main entry point  —  GNN + HQ-Learning for NoC Task Mapping  v2.0

Modes:
  full          Train + full comparison table + all plots  (default)
  train         Training only
  eval          Evaluation only (requires saved model in output_dir)
  scalability   Mesh-size scaling experiment
  fault_sens    Fault-rate sensitivity experiment
  ablation      Component ablation study
  graph_stats   Print networkx task graph statistics (paper Section III)

Usage:
  python main.py
  python main.py --mode scalability
  python main.py --N 16 --num_tasks 64 --episodes 3000
  python main.py --mode graph_stats
  python main.py --no_gpu
"""

import argparse
import os
import sys
import time
import json
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from trainer import GNNHQLearningTrainer
from utils.noc_utils import (
    generate_task_graph,
    generate_fault_map,
    compute_communication_graph_stats,
    compute_thermal_map,
)
from utils.visualization import (
    plot_training_curves,
    plot_comparison_bar,
    plot_reliability_comparison,
    plot_noc_mapping,
    plot_thermal_map,
    plot_scalability,
    plot_fault_sensitivity,
    generate_latex_table,
)

# ── Default configuration ─────────────────────────────────────────────────────

DEFAULT_CONFIG = {
    # NoC mesh
    'N': 8, 'num_tasks': 32, 'num_clusters': 4, 'fault_prob': 0.05,
    # Reward weights (must sum to 1.0)
    'w_hop': 0.5, 'w_energy': 0.2, 'w_fault': 0.2, 'w_thermal': 0.1,
    # GNN
    'embedding_dim': 64, 'gnn_hidden_dim': 128, 'gnn_layers': 4,
    'gnn_heads': 4, 'gnn_dropout': 0.1, 'gnn_lr': 5e-4,
    # HQ-Learning
    'lr': 1e-3, 'gamma': 0.99, 'epsilon_start': 1.0, 'epsilon_end': 0.05,
    'epsilon_decay_steps': 30_000, 'batch_size': 64,
    'target_update_freq': 500, 'buffer_capacity': 50_000,
    'hidden_dims': [256, 256, 128],
    # Training
    'num_episodes': 2000, 'eval_interval': 100,
    'use_gpu': True, 'seed': 42, 'output_dir': 'results',
}


# ── Helper: safe JSON serialization for results dicts ────────────────────────

def _results_to_json(results: dict) -> dict:
    """
    Convert a results dict to JSON-serialisable form.
    Excludes 'cluster_loads' (list) and 'per_graph' (nested dicts) which
    cannot be serialised via float() conversion.
    """
    EXCLUDE = {'cluster_loads', 'per_graph'}
    out = {}
    for method, metrics in results.items():
        out[method] = {}
        for k, v in metrics.items():
            if k in EXCLUDE:
                continue
            try:
                out[method][k] = float(v)
            except (TypeError, ValueError):
                out[method][k] = str(v)
    return out


# ── Experiments ───────────────────────────────────────────────────────────────

def run_training(config: dict):
    trainer = GNNHQLearningTrainer(config)
    metrics = trainer.train(config['num_episodes'], config['eval_interval'])
    plot_training_curves(metrics, config['output_dir'])
    return trainer, metrics


def run_comparison(trainer: GNNHQLearningTrainer, config: dict, seed: int = 999):
    cm = generate_task_graph(config['num_tasks'], seed=seed)
    fm = generate_fault_map(config['N'] ** 2, config['fault_prob'],
                             N=config['N'], seed=seed)

    results = trainer.run_full_comparison(cm, fm, seed=seed)
    trainer.print_comparison_table(results)

    # Plots
    plot_comparison_bar(results, config['output_dir'])
    plot_reliability_comparison(results, config['output_dir'])

    # LaTeX table
    latex_path = os.path.join(config['output_dir'], 'results_table.tex')
    with open(latex_path, 'w') as f:
        f.write(generate_latex_table(results))
    print(f"LaTeX table saved → {latex_path}")

    # Save results JSON
    json_path = os.path.join(config['output_dir'], 'comparison_results.json')
    with open(json_path, 'w') as f:
        json.dump(_results_to_json(results), f, indent=2)

    # NoC mapping + thermal visualisation
    trainer.agent.set_eval_mode()
    trainer.gnn.eval()
    ne, ge, tc, t2c = trainer.get_embeddings_and_clusters(cm)
    with torch.no_grad():
        best_m, _, _ = trainer.run_episode(cm, fm, ne, ge, tc, training=False)

    core_temps, _, _ = compute_thermal_map(
        best_m, cm, config['N'], config['num_clusters'])

    plot_noc_mapping(
        best_m, fm, t2c, config['N'],
        title=f"GNN+HQ+Spectral  {config['N']}×{config['N']} NoC",
        output_dir=config['output_dir'])
    plot_thermal_map(
        core_temps, fm, config['N'],
        output_dir=config['output_dir'])

    return results


def run_graph_stats(config: dict):
    """Print networkx graph statistics — feeds directly into paper Section III."""
    print(f"\n{'='*65}")
    print("TASK GRAPH STATISTICS  (networkx analysis)")
    print(f"{'='*65}")
    for seed in [42, 100, 200]:
        cm   = generate_task_graph(config['num_tasks'], seed=seed)
        stat = compute_communication_graph_stats(cm)
        print(f"\nGraph seed={seed}:")
        print(f"  Edges:           {stat['num_edges']}")
        print(f"  Density:         {stat['density']:.4f}")
        print(f"  Avg clustering:  {stat['avg_clustering']:.4f}")
        print(f"  Diameter:        {stat['diameter']}")
        top5 = stat['top_bottleneck_tasks']
        print(f"  Top bottleneck tasks (betweenness): {top5}")
        top_pr = sorted(stat['pagerank'],
                        key=stat['pagerank'].get, reverse=True)[:3]
        print(f"  Top PageRank tasks: {top_pr}")


def run_scalability(config: dict):
    """Test performance and training time at different mesh sizes."""
    print(f"\n{'='*65}\nSCALABILITY EXPERIMENT\n{'='*65}")
    mesh_sizes  = [4, 6, 8, 12, 16]
    scale_res   = {}

    for N in mesh_sizes:
        print(f"\nMesh {N}×{N}")
        num_tasks    = max(8, (N * N) // 2)
        num_clusters = min(4, max(2, N * N // 8))
        sub_dir      = os.path.join(config['output_dir'], f'scale_{N}')
        os.makedirs(sub_dir, exist_ok=True)

        cfg = {**config, 'N': N, 'num_tasks': num_tasks,
               'num_clusters': num_clusters, 'num_episodes': 500,
               'output_dir': sub_dir}

        trainer = GNNHQLearningTrainer(cfg)
        t0       = time.time()
        trainer.train(500, 100)
        train_t  = time.time() - t0

        cm  = generate_task_graph(num_tasks, seed=999)
        fm  = generate_fault_map(N * N, config['fault_prob'], N=N, seed=999)
        res = trainer.run_full_comparison(cm, fm)

        # Add training time to every method entry
        for v in res.values():
            v['training_time'] = train_t

        scale_res[N] = res
        proposed = list(res.keys())[0]
        print(f"  {proposed}: hops={res[proposed]['hop_count']:.1f}  "
              f"time={train_t:.1f}s")

    plot_scalability(scale_res, config['output_dir'])

    # Safe JSON serialization (exclude cluster_loads and per_graph)
    json_path = os.path.join(config['output_dir'], 'scalability_results.json')
    with open(json_path, 'w') as f:
        json.dump(
            {str(N): _results_to_json(res) for N, res in scale_res.items()},
            f, indent=2)
    print(f"Scalability results → {json_path}")
    return scale_res


def run_fault_sensitivity(config: dict):
    """Test all methods under different fault rates."""
    print(f"\n{'='*65}\nFAULT SENSITIVITY EXPERIMENT\n{'='*65}")
    fault_rates = [0.01, 0.05, 0.10, 0.15, 0.20, 0.30]

    trainer = GNNHQLearningTrainer(config)
    trainer.train(config['num_episodes'], config['eval_interval'])

    cm        = generate_task_graph(config['num_tasks'], seed=999)
    fault_res = {}

    for fr in fault_rates:
        fm = generate_fault_map(config['N'] ** 2, fr, N=config['N'], seed=999)
        trainer.config = {**config, 'fault_prob': fr}
        res = trainer.run_full_comparison(cm, fm, seed=999)
        fault_res[fr] = res
        proposed = list(res.keys())[0]
        print(f"  fault={fr*100:.0f}%:  hops={res[proposed]['hop_count']:.1f}  "
              f"rel={res[proposed]['reliability']*100:.1f}%")

    plot_fault_sensitivity(fault_res, config['output_dir'])

    # Safe JSON serialization
    json_path = os.path.join(config['output_dir'], 'fault_sensitivity_results.json')
    with open(json_path, 'w') as f:
        json.dump(
            {str(fr): _results_to_json(res) for fr, res in fault_res.items()},
            f, indent=2)
    print(f"Fault sensitivity results → {json_path}")
    return fault_res


def run_ablation(config: dict):
    """
    Component ablation study.

    Row 1: GNN+HQ+Spectral  — full proposed system
    Row 2: GNN+HQ+KMeans    — Spectral replaced by KMeans  (Spectral contribution)
    Row 3: HQ Only          — GNN embeddings zeroed out    (GNN contribution)
    Row 4: Nearest Neighbor — no RL at all                 (RL contribution)
    Row 5: First Fit        — simple heuristic
    Row 6: Random           — lower bound

    All rows use the same trained weights so comparison is fair.
    """
    print(f"\n{'='*65}\nABLATION STUDY\n{'='*65}")

    trainer = GNNHQLearningTrainer(config)
    trainer.train(config['num_episodes'], config['eval_interval'])

    cm = generate_task_graph(config['num_tasks'], seed=999)
    fm = generate_fault_map(config['N'] ** 2, config['fault_prob'],
                             N=config['N'], seed=999)

    results  = trainer.run_full_comparison(cm, fm, seed=999)
    trainer.print_comparison_table(results)

    # Quantify each component's individual contribution
    proposed = list(results.keys())[0]
    p_hops   = results[proposed]['hop_count']
    for label, key in [
        ("GNN contribution",     "HQ Only (no GNN)"),
        ("Spectral contribution","GNN+HQ+KMeans"),
        ("RL  contribution",     "Nearest Neighbor"),
    ]:
        if key in results:
            base_hops = results[key]['hop_count']
            pct = (base_hops - p_hops) / base_hops * 100
            print(f"  {label:28s}: {pct:+.1f}% hop count reduction")

    return results


# ── CLI ───────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description='GNN + HQ-Learning for NoC Task Mapping v2.0')
    p.add_argument('--mode', default='full',
                   choices=['full', 'train', 'eval', 'scalability',
                            'fault_sens', 'ablation', 'graph_stats'])
    p.add_argument('--N',            type=int,   default=8)
    p.add_argument('--num_tasks',    type=int,   default=32)
    p.add_argument('--num_clusters', type=int,   default=4)
    p.add_argument('--fault_prob',   type=float, default=0.05)
    p.add_argument('--episodes',     type=int,   default=2000)
    p.add_argument('--seed',         type=int,   default=42)
    p.add_argument('--output_dir',   type=str,   default='results')
    p.add_argument('--no_gpu',       action='store_true')
    return p.parse_args()


def main():
    args   = parse_args()
    config = {
        **DEFAULT_CONFIG,
        'N':            args.N,
        'num_tasks':    args.num_tasks,
        'num_clusters': args.num_clusters,
        'fault_prob':   args.fault_prob,
        'num_episodes': args.episodes,
        'seed':         args.seed,
        'output_dir':   args.output_dir,
        'use_gpu':      not args.no_gpu,
    }
    os.makedirs(config['output_dir'], exist_ok=True)

    with open(os.path.join(config['output_dir'], 'config.json'), 'w') as f:
        json.dump(config, f, indent=2)

    print(f"\nGNN + HQ-Learning for NoC  v2.0")
    print(f"Mode={args.mode} | N={args.N} | tasks={args.num_tasks} | "
          f"clusters={args.num_clusters} | "
          f"fault={args.fault_prob*100:.0f}% | "
          f"episodes={args.episodes}")

    if   args.mode == 'full':
        trainer, _ = run_training(config)
        run_comparison(trainer, config)
    elif args.mode == 'train':
        run_training(config)
    elif args.mode == 'eval':
        trainer = GNNHQLearningTrainer(config)
        run_comparison(trainer, config)
    elif args.mode == 'scalability':
        run_scalability(config)
    elif args.mode == 'fault_sens':
        run_fault_sensitivity(config)
    elif args.mode == 'ablation':
        run_ablation(config)
    elif args.mode == 'graph_stats':
        run_graph_stats(config)

    print(f"\nAll outputs saved to: {config['output_dir']}/")


if __name__ == '__main__':
    main()
