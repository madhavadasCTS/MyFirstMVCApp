graphics_toolkit("gnuplot");
clear all; close all; clc;

%% ================================================================
%  run_comparison.m
%  Full baseline comparison for HQ-Map vs. prior-art methods.
%
%  Methods compared:
%    1. HQ-Map (ours)        -- Hierarchical TD Q-learning, spectral
%                               clustering, 20-state thermal+load encoder
%    2. Flat Q-learning      -- Same reward/state, but single flat Q-table
%                               (no zone/core hierarchy). Closest to FLEA
%                               [Weber et al., Des. Autom. Embedded Syst. 2025]
%    3. Q-Thermal style      -- Q-learning that only tracks thermal state,
%                               ignores load balance. Closest to Q-Thermal
%                               [Ebrahimi et al., IEEE Trans. VLSI 2020] and
%                               TTQR [Liu et al., Sensors 2022]
%    4. Greedy Nearest-Nbr   -- Place each task on the closest free core
%                               to its already-placed communicating partners.
%                               Standard heuristic baseline in NoC literature.
%    5. Round-Robin          -- Tasks placed in order across cores 1..64.
%                               Lower bound baseline.
%
%  Safety metric (novel, not in prior work):
%    Per-mode safety constraint satisfaction rate (SCSR):
%    fraction of critical-task communicating pairs placed within 3 hops.
%
%  Output:
%    - comparison_results.png   (6-panel figure)
%    - comparison_table.png     (paper-ready results table)
%    - comparison_results.mat   (raw data)
%% ================================================================

%% -- CONFIG (shared across all methods) --------------------------
N            = 8;
num_cores    = N * N;
num_tasks    = 32;
num_clusters = 4;
total_steps  = 1000;

alpha        = 0.1;
gamma        = 0.9;
epsilon_init = 0.5;
epsilon_decay= 0.9935;
epsilon_min  = 0.05;

ambient_temp    = 45;
max_safe_temp   = 85;
heat_dissipation= 0.25;
heat_by_type    = [6.0, 3.0, 1.5];

num_states_coarse = 20;
num_states_fine   = 20;
num_cpc           = num_cores / num_clusters;  % cores per cluster = 16

methods = {'HQ-Map (Ours)', 'Flat Q (FLEA-style)', ...
           'Q-Thermal style', 'Greedy NN', 'Round-Robin'};
num_methods = length(methods);

%% -- STORAGE ------------------------------------------------------
for m = 1:num_methods
    R(m).temps    = zeros(total_steps, 1);
    R(m).latency  = zeros(total_steps, 1);
    R(m).rewards  = zeros(total_steps, 1);
    R(m).lb       = zeros(total_steps, 1);
    R(m).scsr     = zeros(total_steps, 1);  % safety constraint satisfaction rate
    R(m).modes    = zeros(total_steps, 1);
end

%% -- RUN ALL METHODS ----------------------------------------------
fprintf('Running comparison across %d methods x %d steps...\n\n', ...
        num_methods, total_steps);

for m = 1:num_methods
    fprintf('[%d/%d] Running: %s\n', m, num_methods, methods{m});

    % Reset per-method state
    core_temps = ones(num_cores, 1) * ambient_temp;
    epsilon    = epsilon_init;
    clusters   = [];

    % Q-tables (only used by RL methods)
    coarse_Q  = zeros(num_states_coarse, num_clusters);
    fine_Q    = zeros(num_states_fine, num_cpc);
    flat_Q    = zeros(num_states_coarse, num_cores);      % Flat Q
    thermal_Q = zeros(4, num_cores);                      % Q-Thermal (4 thermal states)

    for step = 1:total_steps
        mode = 1 + (step > 300) + (step > 700);
        [comm_matrix, task_types] = get_vehicle_workload(mode, num_tasks);

        % Recluster on mode change (HQ-Map and Flat Q use this)
        if step == 1 || step == 301 || step == 701
            clusters = cluster_tasks(comm_matrix, num_clusters, task_types);
        end

        % -- DISPATCH TO METHOD ------------------------------------
        switch m
            case 1   % HQ-Map (ours)
                [coarse_Q, fine_Q, mapping, reward, hc] = run_online_episode( ...
                    comm_matrix, clusters, task_types, core_temps, N, ...
                    num_clusters, coarse_Q, fine_Q, alpha, gamma, epsilon, max_safe_temp);

            case 2   % Flat Q-learning (FLEA-style)
                [flat_Q, mapping, reward, hc] = run_flat_q( ...
                    comm_matrix, task_types, core_temps, N, flat_Q, ...
                    alpha, gamma, epsilon, max_safe_temp);

            case 3   % Q-Thermal style (thermal state only, no load)
                [thermal_Q, mapping, reward, hc] = run_qthermal( ...
                    comm_matrix, task_types, core_temps, N, thermal_Q, ...
                    alpha, gamma, epsilon, max_safe_temp);

            case 4   % Greedy nearest-neighbour
                [mapping, reward, hc] = run_greedy_nn( ...
                    comm_matrix, task_types, core_temps, N, max_safe_temp);

            case 5   % Round-robin
                [mapping, reward, hc] = run_round_robin( ...
                    comm_matrix, task_types, core_temps, N, max_safe_temp);
        end

        % -- THERMAL UPDATE (identical for all methods) ------------
        core_temps = core_temps - (core_temps - ambient_temp) * heat_dissipation;
        for t = 1:num_tasks
            c = mapping(t);
            if c > 0
                tt = task_types(t);
                if tt < 1 || tt > 3, tt = 3; end
                core_temps(c) = core_temps(c) + heat_by_type(tt);
            end
        end
        core_temps = max(core_temps, ambient_temp);

        epsilon = max(epsilon_min, epsilon * epsilon_decay);

        % -- METRICS ----------------------------------------------
        cluster_loads = zeros(num_clusters, 1);
        for c = 1:num_clusters
            cs = (c-1)*num_cpc + 1;
            ce = c * num_cpc;
            cluster_loads(c) = sum(mapping >= cs & mapping <= ce);
        end

        scsr = compute_scsr(mapping, comm_matrix, task_types, N);

        R(m).temps(step)   = max(core_temps);
        R(m).latency(step) = hc;
        R(m).rewards(step) = reward;
        R(m).lb(step)      = std(cluster_loads);
        R(m).scsr(step)    = scsr;
        R(m).modes(step)   = mode;
    end
    fprintf('   Done. AvgReward=%.3f  AvgTemp=%.1fC  AvgSCSR=%.1f%%\n\n', ...
            mean(R(m).rewards), mean(R(m).temps), mean(R(m).scsr)*100);
end

%% -- PLOTS --------------------------------------------------------
plot_comparison(R, methods, total_steps);
plot_results_table(R, methods);

%% -- SAVE --------------------------------------------------------
if ~exist('results', 'dir'), mkdir('results'); end
save('results/comparison_results.mat', 'R', 'methods');
fprintf('\nAll results saved to results/\n');
fprintf('Figures: comparison_results.png  |  comparison_table.png\n');
input('\nPress Enter to exit...', 's');
