function [reward, hop_cost] = compute_reward_p2(mapping, comm_matrix, task_types, core_temps, N, max_temp)
% COMPUTE_REWARD_P2  Multi-objective reward for one mapping episode.
%
%  Reward weights are calibrated so a GOOD mapping always yields positive
%  reward and a bad mapping yields negative reward -- essential for stable
%  Q-learning convergence.
%
%  Sanity check (best possible per mode):
%    City    ~+1.96,  Highway ~+1.81,  Parked ~+1.96
%
%  Components (all normalised to [0,1]):
%    hop_cost_norm  : weighted Manhattan hop cost / max possible
%    thermal_penalty: 0 below 75C, linear 75-85C, quadratic above 85C
%    safety_penalty : fraction of critical pairs placed >3 hops apart
%
%  Weights: w_hop=0.5, w_thermal=1.0, w_safety=2.0
%  Safety > Thermal > Latency -- reflects automotive priority ordering.
%  Completion bonus = +2.0 ensures positive reward for complete mappings.

    num_tasks = size(comm_matrix, 1);

    %% Hop cost
    hop_cost  = compute_hop_count(mapping, comm_matrix, N);
    total_bw  = sum(sum(comm_matrix));
    if total_bw > 0
        hop_cost_norm = hop_cost / (2 * (N-1) * total_bw);
    else
        hop_cost_norm = 0;
    end

    %% Thermal penalty
    active_cores = mapping(mapping > 0);
    if isempty(active_cores)
        cur_max = 45;
    else
        cur_max = max(core_temps(active_cores));
    end
    if cur_max > max_temp
        thermal_penalty = 2.0 + (cur_max - max_temp)^2 / 100;
    elseif cur_max > max_temp - 10
        thermal_penalty = (cur_max - (max_temp-10)) / 10;
    else
        thermal_penalty = 0;
    end

    %% Safety penalty (normalised by number of critical pairs)
    violations = 0;
    num_pairs  = 0;
    for i = 1:num_tasks
        for j = 1:num_tasks
            if comm_matrix(i,j) > 0 && task_types(i) == 1
                num_pairs = num_pairs + 1;
                ci = mapping(i); cj = mapping(j);
                if ci > 0 && cj > 0
                    xi = mod(ci-1,N); yi = floor((ci-1)/N);
                    xj = mod(cj-1,N); yj = floor((cj-1)/N);
                    if abs(xi-xj)+abs(yi-yj) > 3
                        violations = violations + 1;
                    end
                end
            end
        end
    end
    safety_penalty = violations / max(1, num_pairs);

    %% Combined reward
    reward = -(0.5 * hop_cost_norm) ...
             -(1.0 * thermal_penalty) ...
             -(2.0 * safety_penalty);

    % Completion bonus: ensures positive reward for well-placed mappings
    if sum(mapping == 0) == 0
        reward = reward + 2.0;
    end
end
