function cost = compute_hop_count(mapping, comm_matrix, N)
% COMPUTE_HOP_COUNT  Weighted Manhattan-distance communication cost.
%
%  For every communicating task pair (i,j), adds  dist(i,j) * bw(i,j)
%  to the total cost.  Uses the standard 2-D mesh coordinate system
%  where core k maps to grid position (col, row) = (mod(k-1,N), floor((k-1)/N)).

    num_tasks = size(mapping, 1);
    cost = 0;
    for i = 1:num_tasks
        for j = 1:num_tasks
            if comm_matrix(i, j) > 0
                c1 = mapping(i);
                c2 = mapping(j);
                if c1 > 0 && c2 > 0
                    x1 = mod(c1 - 1, N);  y1 = floor((c1 - 1) / N);
                    x2 = mod(c2 - 1, N);  y2 = floor((c2 - 1) / N);
                    dist = abs(x1 - x2) + abs(y1 - y2);
                    cost = cost + dist * comm_matrix(i, j);
                end
            end
        end
    end
end
