function scsr = compute_scsr(mapping, comm_matrix, task_types, N)
% COMPUTE_SCSR  Safety Constraint Satisfaction Rate (SCSR).
%
%  Novel evaluation metric for automotive NoC schedulers.
%  Not present in Q-Thermal, TTQR, or FLEA.
%
%  Definition:
%    For all communicating pairs (i, j) where task i is safety-critical
%    (type 1), SCSR = fraction of such pairs placed within 3 Manhattan
%    hops of each other.
%
%    SCSR = 1.0 = all critical pairs satisfy the proximity constraint (ideal)
%    SCSR = 0.0 = no critical pairs satisfy it (worst case)
%
%  The 3-hop threshold reflects a 2-cycle latency budget for ISO 26262
%  ASIL-D safety functions in automotive SoCs.
%
%  Returns 1.0 if no critical communicating pairs exist (e.g. Parked mode
%  with only background tasks).

    num_tasks  = length(mapping);
    satisfied  = 0;
    total      = 0;

    for i = 1:num_tasks
        if task_types(i) ~= 1, continue; end
        for j = 1:num_tasks
            if comm_matrix(i, j) > 0
                total = total + 1;
                ci = mapping(i);
                cj = mapping(j);
                if ci > 0 && cj > 0
                    xi = mod(ci-1, N);  yi = floor((ci-1)/N);
                    xj = mod(cj-1, N);  yj = floor((cj-1)/N);
                    dist = abs(xi-xj) + abs(yi-yj);
                    if dist <= 3
                        satisfied = satisfied + 1;
                    end
                end
            end
        end
    end

    if total == 0
        scsr = 1.0;
    else
        scsr = satisfied / total;
    end
end
