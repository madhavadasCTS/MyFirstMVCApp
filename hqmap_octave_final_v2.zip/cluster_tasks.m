function [task_clusters, task_to_cluster] = cluster_tasks(comm_matrix, num_clusters, task_types)
% CLUSTER_TASKS  Spectral graph partitioning -- fully Octave compatible.
%
%  Uses normalised Laplacian eigenvectors (spectral clustering).
%  Does NOT call kmeans() -- uses built-in greedy_assign instead,
%  so no statistics toolbox needed in either MATLAB or Octave.
%
%  Critical-task co-location bias: edges between type-1 tasks are
%  weighted 5x so spectral embedding naturally groups them together.

    num_tasks = size(comm_matrix, 1);
    if nargin < 3 || isempty(task_types)
        task_types = ones(num_tasks, 1) * 2;
    end

    W = comm_matrix + comm_matrix';

    % Critical-task co-location bias
    for i = 1:num_tasks
        for j = 1:num_tasks
            if task_types(i) == 1 && task_types(j) == 1
                W(i,j) = W(i,j) * 5.0;
            end
        end
    end

    %% Spectral clustering on normalised Laplacian
    try
        d          = max(sum(W, 2), 1e-10);
        D_inv_sqrt = diag(1 ./ sqrt(d));
        L_norm     = eye(num_tasks) - D_inv_sqrt * W * D_inv_sqrt;
        [V, ~]     = eig(L_norm);
        embedding  = V(:, 1:num_clusters);

        % Row-normalise
        row_norms = max(sqrt(sum(embedding.^2, 2)), 1e-10);
        for i = 1:num_tasks
            embedding(i,:) = embedding(i,:) / row_norms(i);
        end

        % Greedy k-means (no toolbox needed -- works in Octave and MATLAB)
        task_to_cluster = greedy_assign(embedding, num_clusters);

    catch err
        fprintf('Spectral clustering failed (%s), using BFS fallback.\n', err.message);
        task_to_cluster = bfs_partition(W, num_tasks, num_clusters);
    end

    %% Balance clusters (prefer moving non-critical tasks)
    target = floor(num_tasks / num_clusters);
    for c = 1:num_clusters
        for iter = 1:50
            if sum(task_to_cluster == c) >= target, break; end
            counts  = histc(task_to_cluster, 1:num_clusters); %#ok
            [~, bg] = max(counts);
            if counts(bg) <= target + 1, break; end
            cands   = find(task_to_cluster == bg);
            nc      = cands(task_types(cands) ~= 1);
            if ~isempty(nc)
                task_to_cluster(nc(end)) = c;
            else
                task_to_cluster(cands(end)) = c;
            end
        end
    end

    %% Ensure no empty cluster
    for c = 1:num_clusters
        if sum(task_to_cluster == c) == 0
            counts = histc(task_to_cluster, 1:num_clusters); %#ok
            [~, bg] = max(counts);
            cands   = find(task_to_cluster == bg);
            task_to_cluster(cands(end)) = c;
        end
    end

    %% Build cell output
    task_clusters = cell(num_clusters, 1);
    for i = 1:num_clusters
        task_clusters{i} = find(task_to_cluster == i);
    end
end

function labels = greedy_assign(X, k)
% Simple k-means without any toolbox -- works in Octave and MATLAB.
    n       = size(X, 1);
    idx     = round(linspace(1, n, k));
    centers = X(idx, :);
    labels  = ones(n, 1);
    for iter = 1:100
        dists = zeros(k, n);
        for c = 1:k
            diff        = bsxfun(@minus, X, centers(c,:));
            dists(c,:)  = sum(diff.^2, 2)';
        end
        [~, new_labels] = min(dists, [], 1);
        new_labels = new_labels(:);
        if all(new_labels == labels), break; end
        labels = new_labels;
        for c = 1:k
            m = X(labels == c, :);
            if ~isempty(m), centers(c,:) = mean(m, 1); end
        end
    end
end

function labels = bfs_partition(W, num_tasks, k)
% BFS fallback partition when eig fails.
    labels    = zeros(num_tasks, 1);
    visited   = false(num_tasks, 1);
    cluster   = 1;
    target_sz = ceil(num_tasks / k);
    [~, seeds] = sort(sum(W, 2), 'descend');
    for s = 1:num_tasks
        seed = seeds(s);
        if visited(seed), continue; end
        if cluster > k, break; end
        queue = seed; count = 0;
        while ~isempty(queue) && count < target_sz
            node = queue(1); queue = queue(2:end);
            if visited(node), continue; end
            visited(node) = true; labels(node) = cluster; count = count + 1;
            [~, nbrs] = sort(W(node,:), 'descend');
            for nb = nbrs
                if W(node,nb) > 0 && ~visited(nb)
                    queue(end+1) = nb; %#ok
                end
            end
        end
        cluster = cluster + 1;
    end
    unvisited = find(labels == 0);
    for i = 1:length(unvisited)
        labels(unvisited(i)) = mod(i-1, k) + 1;
    end
end
