function plot_phase2_results(history, N, total_steps)
% PLOT_PHASE2_RESULTS  5-panel performance plot -- fully Octave compatible.
% Replaces yline() with plot(), removes sgtitle.

    if ~exist('results', 'dir'), mkdir('results'); end

    steps = (1:length(history.temps))';
    sw    = 20;
    sm    = @(x) filter(ones(1,sw)/sw, 1, x(:)');

    figure('Position', [100, 100, 1100, 820]);

    %% 1. Temperature
    subplot(5,1,1);
    hold on;
    plot(steps, history.temps, 'Color', [0.8 0.2 0.2], 'LineWidth', 0.8, 'LineStyle', '-');
    plot(steps, sm(history.temps), 'Color', [0.8 0.2 0.2], 'LineWidth', 2.0);
    plot([1 total_steps], [85 85], 'k--', 'LineWidth', 1.5);
    plot([1 total_steps], [75 75], 'Color', [0.9 0.6 0.0], 'LineWidth', 1.0, 'LineStyle', '--');
    hold off;
    ylabel('Max Temp (C)'); title('Thermal Stability');
    legend('Raw', 'Smoothed', 'Hard limit (85C)', 'Warning (75C)', 'Location', 'northwest');
    ylim([40, max(95, max(history.temps) + 5)]); grid on;

    %% 2. Latency
    subplot(5,1,2);
    hold on;
    plot(steps, history.latency, 'Color', [0.6 0.6 0.6], 'LineWidth', 0.6);
    plot(steps, sm(history.latency), 'b', 'LineWidth', 1.8);
    hold off;
    ylabel('Comm cost'); title('Communication Latency (weighted hop count)');
    legend('Raw', 'Smoothed', 'Location', 'northeast'); grid on;

    %% 3. Reward
    subplot(5,1,3);
    hold on;
    plot(steps, history.rewards, 'Color', [0.7 0.7 0.7], 'LineWidth', 0.6);
    plot(steps, sm(history.rewards), 'Color', [0.1 0.6 0.3], 'LineWidth', 1.8);
    plot([1 total_steps], [0 0], 'Color', [0.5 0.5 0.5], 'LineWidth', 0.8, 'LineStyle', ':');
    hold off;
    ylabel('Reward'); title('Episode Reward (higher = better)');
    legend('Raw', 'Smoothed', 'Location', 'southeast'); grid on;

    %% 4. Load Balance
    subplot(5,1,4);
    hold on;
    plot(steps, history.load_balance, 'Color', [0.4 0.2 0.7], 'LineWidth', 1.0);
    plot(steps, sm(history.load_balance), 'Color', [0.6 0.3 0.9], 'LineWidth', 1.8);
    hold off;
    ylabel('Load Std-Dev'); title('Cluster Load Balance (lower = better)');
    legend('Raw', 'Smoothed', 'Location', 'northeast'); grid on;

    %% 5. Mode
    subplot(5,1,5);
    plot(steps, history.modes, 'k', 'LineWidth', 2);
    ylabel('Mode'); xlabel('Simulation Step');
    ylim([0.5, 3.5]);
    set(gca, 'YTick', [1, 2, 3]);
    set(gca, 'YTickLabel', {'City', 'Highway', 'Parked'});
    title('Driving Context'); grid on;

    %% Mode boundary lines on all panels
    for sub = 1:5
        subplot(5,1,sub);
        yl = ylim();
        hold on;
        for b = [300, 700]
            plot([b b], yl, 'Color', [0.5 0.5 0.5], 'LineWidth', 0.8, 'LineStyle', ':');
        end
        hold off;
    end

    print('-dpng', 'results/phase2_performance_plot.png');
    fprintf('Saved: results/phase2_performance_plot.png\n');
end
