function plot_comparison(R, methods, total_steps)
% PLOT_COMPARISON  6-panel comparison -- fully Octave compatible.
% Replaces: sgtitle->text, yline->plot, xline->plot

    if ~exist('results', 'dir'), mkdir('results'); end

    colors = {[0.1  0.6  0.9];
              [0.9  0.4  0.1];
              [0.2  0.75 0.3];
              [0.75 0.2  0.75];
              [0.5  0.5  0.5]};
    lwidths = [2.5, 1.8, 1.8, 1.5, 1.2];
    lstyles = {'-', '--', '-.', ':', '-'};

    steps = (1:total_steps)';
    sw    = 25;
    sm    = @(x) filter(ones(1,sw)/sw, 1, x(:)');

    fig = figure('Position', [50, 50, 1200, 950]);

    %% 1. Temperature
    subplot(3,2,1);
    hold on;
    for m = 1:length(methods)
        plot(steps, sm(R(m).temps), 'Color', colors{m}, ...
             'LineWidth', lwidths(m), 'LineStyle', lstyles{m});
    end
    % Octave-compatible horizontal lines (replaces yline)
    plot([1 total_steps], [85 85], 'k--', 'LineWidth', 1.5);
    plot([1 total_steps], [75 75], 'Color', [0.9 0.6 0], 'LineWidth', 1.0, 'LineStyle', '--');
    hold off;
    ylabel('Max Temp (deg C)'); title('(a) Thermal Performance');
    ylim([42, 100]); grid on;
    legend([methods, {'Limit 85C', 'Warn 75C'}], 'Location', 'northeast', 'FontSize', 7);
    add_mode_lines(total_steps);

    %% 2. Latency
    subplot(3,2,2);
    hold on;
    for m = 1:length(methods)
        plot(steps, sm(R(m).latency), 'Color', colors{m}, ...
             'LineWidth', lwidths(m), 'LineStyle', lstyles{m});
    end
    hold off;
    ylabel('Weighted Hop Cost'); title('(b) Communication Latency');
    grid on; legend(methods, 'Location', 'northeast', 'FontSize', 7);
    add_mode_lines(total_steps);

    %% 3. Reward
    subplot(3,2,3);
    hold on;
    for m = 1:length(methods)
        plot(steps, sm(R(m).rewards), 'Color', colors{m}, ...
             'LineWidth', lwidths(m), 'LineStyle', lstyles{m});
    end
    plot([1 total_steps], [0 0], 'Color', [0.6 0.6 0.6], 'LineWidth', 0.8, 'LineStyle', ':');
    hold off;
    ylabel('Reward'); title('(c) Episode Reward (higher = better)');
    grid on; legend(methods, 'Location', 'southeast', 'FontSize', 7);
    add_mode_lines(total_steps);

    %% 4. SCSR
    subplot(3,2,4);
    hold on;
    for m = 1:length(methods)
        plot(steps, sm(R(m).scsr * 100), 'Color', colors{m}, ...
             'LineWidth', lwidths(m), 'LineStyle', lstyles{m});
    end
    plot([1 total_steps], [100 100], 'k:', 'LineWidth', 0.8);
    hold off;
    ylabel('SCSR (%)'); title('(d) Safety Constraint Satisfaction Rate');
    ylim([0, 110]); grid on;
    legend(methods, 'Location', 'southeast', 'FontSize', 7);
    add_mode_lines(total_steps);

    %% 5. Load Balance
    subplot(3,2,5);
    hold on;
    for m = 1:length(methods)
        plot(steps, sm(R(m).lb), 'Color', colors{m}, ...
             'LineWidth', lwidths(m), 'LineStyle', lstyles{m});
    end
    hold off;
    ylabel('Load Std-Dev'); title('(e) Cluster Load Balance (lower = better)');
    xlabel('Simulation Step'); grid on;
    legend(methods, 'Location', 'northeast', 'FontSize', 7);
    add_mode_lines(total_steps);

    %% 6. Per-mode SCSR bar chart
    subplot(3,2,6);
    mode_ranges = {1:300, 301:700, 701:1000};
    bar_data = zeros(length(methods), 3);
    for m = 1:length(methods)
        for k = 1:3
            bar_data(m, k) = mean(R(m).scsr(mode_ranges{k})) * 100;
        end
    end
    bar(bar_data);
    set(gca, 'XTickLabel', methods, 'XTickLabelRotation', 20, 'FontSize', 7);
    ylabel('SCSR (%)'); title('(f) Safety Rate per Mode');
    legend({'City','Highway','Parked'}, 'Location', 'southwest', 'FontSize', 7);
    ylim([0, 115]); grid on;

    % Super-title using text (sgtitle not available in Octave)
    axes('Position', [0 0 1 1], 'Visible', 'off');
    text(0.5, 0.995, 'HQ-Map vs. Prior Art: Full Comparative Evaluation', ...
         'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', ...
         'FontSize', 13, 'FontWeight', 'bold', 'Units', 'normalized');

    print('-dpng', 'results/comparison_results.png');
    fprintf('Saved: results/comparison_results.png\n');
end

function add_mode_lines(total_steps)
    yl = ylim();
    hold on;
    for b = [300, 700]
        plot([b b], yl, 'Color', [0.5 0.5 0.5], 'LineWidth', 0.8, 'LineStyle', ':');
    end
    text(150,  yl(2)*0.96, 'City',    'FontSize', 7, 'HorizontalAlignment', 'center', 'Color', [0.4 0.4 0.4]);
    text(500,  yl(2)*0.96, 'Highway', 'FontSize', 7, 'HorizontalAlignment', 'center', 'Color', [0.4 0.4 0.4]);
    text(850,  yl(2)*0.96, 'Parked',  'FontSize', 7, 'HorizontalAlignment', 'center', 'Color', [0.4 0.4 0.4]);
    hold off;
end
