% hq_map_phase2_main.m  -- Octave compatible
graphics_toolkit('gnuplot');
clear all; close all; clc;

%% ==================== CONFIGURATION =======================
N            = 8;
num_cores    = N * N;
num_tasks    = 32;
num_clusters = 4;

alpha         = 0.1;
gamma         = 0.9;
epsilon       = 0.5;
epsilon_decay = 0.9935;
epsilon_min   = 0.05;

ambient_temp     = 45;
max_safe_temp    = 85;
core_temps       = ones(num_cores, 1) * ambient_temp;
heat_dissipation = 0.25;
heat_by_type     = [6.0, 3.0, 1.5];

total_steps   = 1000;
eval_interval = 50;

num_states_coarse    = 20;
num_states_fine      = 20;
num_cores_per_cluster = num_cores / num_clusters;

coarse_Q = zeros(num_states_coarse, num_clusters);
fine_Q   = zeros(num_states_fine, num_cores_per_cluster);

history.temps        = [];
history.latency      = [];
history.rewards      = [];
history.modes        = [];
history.load_balance = [];
history.hotspot_count= [];

fprintf('=======================================================\n');
fprintf('  HQ-Map Phase 2 -- Smart Vehicle SoC RL (Octave)\n');
fprintf('=======================================================\n');
fprintf('Config: %dx%d NoC | %d tasks | %d clusters | %d steps\n', ...
        N, N, num_tasks, num_clusters, total_steps);
fprintf('RL: alpha=%.2f  gamma=%.2f  eps=%.2f->%.2f\n\n', ...
        alpha, gamma, epsilon, epsilon_min);

%% ==================== MAIN LOOP ==========================
for step = 1:total_steps

    if step <= 300
        mode = 1; mode_name = 'City';
    elseif step <= 700
        mode = 2; mode_name = 'Highway';
    else
        mode = 3; mode_name = 'Parked';
    end

    [comm_matrix, task_types] = get_vehicle_workload(mode, num_tasks);

    if step == 1 || step == 301 || step == 701
        [task_clusters, ~] = cluster_tasks(comm_matrix, num_clusters, task_types);
        fprintf('[Step %4d] Mode -> %-8s  reclustered.\n', step, mode_name);
    end

    [coarse_Q, fine_Q, mapping, reward, step_cost] = run_online_episode( ...
        comm_matrix, task_clusters, task_types, core_temps, N, num_clusters, ...
        coarse_Q, fine_Q, alpha, gamma, epsilon, max_safe_temp);

    core_temps = core_temps - (core_temps - ambient_temp) * heat_dissipation;
    for t = 1:num_tasks
        c = mapping(t);
        if c > 0
            tt = task_types(t);
            if tt < 1 || tt > 3, tt = 3; end
            core_temps(c) = core_temps(c) + heat_by_type(tt);
        end
    end
    core_temps = max(core_temps, ambient_temp);

    epsilon = max(epsilon_min, epsilon * epsilon_decay);

    cluster_loads = zeros(num_clusters, 1);
    for c = 1:num_clusters
        cs = (c-1)*num_cores_per_cluster + 1;
        ce = c*num_cores_per_cluster;
        cluster_loads(c) = sum(mapping >= cs & mapping <= ce);
    end

    history.temps         = [history.temps;         max(core_temps)];
    history.latency       = [history.latency;        step_cost];
    history.rewards       = [history.rewards;        reward];
    history.modes         = [history.modes;          mode];
    history.load_balance  = [history.load_balance;   std(cluster_loads)];
    history.hotspot_count = [history.hotspot_count;  sum(core_temps > (max_safe_temp-10))];

    if mod(step, eval_interval) == 0
        fprintf('Step %4d [%-8s] | MaxTemp:%5.1fC | Lat:%5.0f | Rew:%6.2f | LB:%.1f | Eps:%.3f\n', ...
            step, mode_name, max(core_temps), step_cost, reward, std(cluster_loads), epsilon);
    end

    if step == 300,  city_mapping=mapping;   city_temps=core_temps;   end
    if step == 700,  hwy_mapping=mapping;    hwy_temps=core_temps;    end
    if step == 1000, park_mapping=mapping;   park_temps=core_temps;   end
end

%% ==================== PLOTS ==============================
plot_phase2_results(history, N, total_steps);
plot_noc_mapping(city_mapping,  city_temps,  N, 'City');
plot_noc_mapping(hwy_mapping,   hwy_temps,   N, 'Highway');
plot_noc_mapping(park_mapping,  park_temps,  N, 'Parked');

%% ==================== SAVE ===============================
if ~exist('results', 'dir'), mkdir('results'); end
save('results/hq_map_phase2_results.mat', 'coarse_Q', 'fine_Q', 'history', 'core_temps');
fprintf('\nSimulation complete. Results saved.\n');
fprintf('Press Enter to exit...\n');
input('', 's');
