function [new_Q, mapping, reward, hop_cost] = run_qthermal( ...
    comm_matrix, task_types, core_temps, N, Q, ...
    alpha, gamma, epsilon, max_safe_temp)
% RUN_QTHERMAL  Q-learning baseline using thermal state only.
%
%  Models the spirit of Q-Thermal [Ebrahimi et al., IEEE Trans. VLSI 2020]
%  and TTQR [Liu et al., Sensors 2022]:
%    - State = 4-level thermal bucket ONLY (no load-balance dimension)
%    - Single Q-table: [4 states x 64 cores]
%    - No spectral clustering, no zone hierarchy
%
%  Uses the SAME unified reward function as HQ-Map for fair score comparison.
%  The key difference from HQ-Map is WHAT INFORMATION drives the decision
%  (thermal only, vs thermal+load in HQ-Map), not the reward definition.
%
%  Any reward gap vs HQ-Map shows the value of:
%    (a) including load-balance in the state
%    (b) the two-level hierarchy
%    (c) spectral task pre-clustering with safety bias

    new_Q     = Q;
    num_tasks = size(comm_matrix, 1);
    num_cores = N * N;
    mapping   = zeros(num_tasks, 1);
    history   = zeros(0, 3);

    for t_idx = 1:num_tasks
        avg_temp  = mean(core_temps);
        norm_temp = max(0, min(1, (avg_temp - 45) / 40));
        s         = min(4, floor(norm_temp * 4) + 1);

        if rand() < epsilon
            action = randi(num_cores);
        else
            q_row             = new_Q(s, :);
            occupied          = mapping(mapping > 0);
            q_row(occupied)   = -inf;
            [~, action]       = max(q_row);
        end

        if any(mapping == action)
            free = setdiff(1:num_cores, mapping(mapping > 0));
            if ~isempty(free)
                action = free(randi(length(free)));
            end
        end

        mapping(t_idx) = action;

        avg_temp_next = mean(core_temps);
        norm_next     = max(0, min(1, (avg_temp_next - 45) / 40));
        s_next        = min(4, floor(norm_next * 4) + 1);
        history(end+1, :) = [s, action, s_next]; %#ok<AGROW>
    end

    % SAME reward function as HQ-Map -- fair comparison
    [reward, hop_cost] = compute_reward_p2( ...
        mapping, comm_matrix, task_types, core_temps, N, max_safe_temp);

    for i = 1:size(history, 1)
        s = history(i,1); a = history(i,2); sn = history(i,3);
        a = min(a, size(new_Q, 2));
        td = reward + gamma * max(new_Q(sn, :));
        new_Q(s, a) = new_Q(s, a) + alpha * (td - new_Q(s, a));
    end
end
