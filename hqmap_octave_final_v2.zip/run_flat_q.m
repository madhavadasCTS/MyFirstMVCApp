function [new_flat_Q, mapping, reward, hop_cost] = run_flat_q( ...
    comm_matrix, task_types, core_temps, N, flat_Q, ...
    alpha, gamma, epsilon, max_safe_temp)
% RUN_FLAT_Q  Flat (non-hierarchical) Q-learning task mapper.
%
%  Baseline representing the FLEA approach [Weber et al. 2025]:
%    - Single Q-table: [num_states x num_cores]
%    - State = same 20-state thermal+load encoder as HQ-Map (fair comparison)
%    - Action = direct core selection from all 64 cores
%    - No zone-level decomposition, no spectral clustering
%    - Same TD(0) Bellman update as HQ-Map
%
%  This isolates the contribution of the hierarchical decomposition:
%  any improvement of HQ-Map over this baseline is due to the two-level
%  zone->core hierarchy and spectral task pre-clustering.

    new_flat_Q = flat_Q;
    num_tasks  = size(comm_matrix, 1);
    num_cores  = N * N;

    mapping    = zeros(num_tasks, 1);
    history    = zeros(0, 3);   % [s, a, s_next]

    % Simple sequential placement (no clustering)
    task_order = 1:num_tasks;

    for t_idx = 1:length(task_order)
        task_id = task_order(t_idx);

        s = get_state_p2(mapping, core_temps, N, 4);

        % epsilon-greedy over all cores
        if rand() < epsilon
            action = randi(num_cores);
        else
            q_row  = new_flat_Q(s, :);
            % Mask already-occupied cores
            occupied = mapping(mapping > 0);
            q_row(occupied) = -inf;
            [~, action] = max(q_row);
        end

        % Collision fallback
        if any(mapping == action)
            free = setdiff(1:num_cores, mapping(mapping > 0));
            if ~isempty(free)
                action = free(randi(length(free)));
            end
        end

        mapping(task_id) = action;

        s_next = get_state_p2(mapping, core_temps, N, 4);
        history(end+1, :) = [s, action, s_next]; %#ok<AGROW>
    end

    [reward, hop_cost] = compute_reward_p2( ...
        mapping, comm_matrix, task_types, core_temps, N, max_safe_temp);

    % TD(0) update
    for i = 1:size(history, 1)
        s      = history(i, 1);
        a      = history(i, 2);
        s_next = history(i, 3);

        a = min(a, size(new_flat_Q, 2));
        td_target = reward + gamma * max(new_flat_Q(s_next, :));
        new_flat_Q(s, a) = new_flat_Q(s, a) + ...
            alpha * (td_target - new_flat_Q(s, a));
    end
end
