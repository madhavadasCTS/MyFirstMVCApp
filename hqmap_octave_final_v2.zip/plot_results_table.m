function plot_results_table(R, methods)
% PLOT_RESULTS_TABLE  Paper-ready results table -- fully Octave compatible.
% Replaces annotation() with patch/text, removes sscanf with degree symbol.

    if ~exist('results', 'dir'), mkdir('results'); end

    num_methods = length(methods);
    mode_ranges = {1:300, 301:700, 701:1000, 1:1000};

    %% Compute stats
    for m = 1:num_methods
        for k = 1:4
            idx = mode_ranges{k};
            S(m,k).avg_reward  = mean(R(m).rewards(idx));
            S(m,k).max_temp    = max(R(m).temps(idx));
            S(m,k).violations  = sum(R(m).temps(idx) > 85);
            S(m,k).avg_latency = mean(R(m).latency(idx));
            S(m,k).avg_scsr    = mean(R(m).scsr(idx)) * 100;
            S(m,k).avg_lb      = mean(R(m).lb(idx));
        end
    end

    %% Print console table (always works in Octave)
    rr_r = S(num_methods, 4).avg_reward;
    fprintf('\n');
    fprintf('+%s+\n', repmat('-',1,90));
    fprintf('| TABLE I: HQ-Map vs Prior Art -- Overall Performance (1000 Steps)%s|\n', repmat(' ',1,24));
    fprintf('+%s+\n', repmat('-',1,90));
    fprintf('| %-24s | %7s | %8s | %6s | %7s | %6s | %6s | %7s |\n', ...
        'Method','Reward','MaxTemp','Viol.','Latency','SCSR%','LBstd','vs RR%');
    fprintf('+%s+\n', repmat('-',1,90));
    for m = 1:num_methods
        s   = S(m,4);
        impr = (s.avg_reward - rr_r) / max(abs(rr_r), 0.001) * 100;
        mk  = '  '; if m==1, mk='>>'; end
        fprintf('| %s %-22s | %+7.3f | %6.1fC  | %6d | %7.0f | %5.1f%% | %6.2f | %+6.1f%% |\n', ...
            mk, methods{m}(1:min(end,22)), s.avg_reward, s.max_temp, ...
            s.violations, s.avg_latency, s.avg_scsr, s.avg_lb, impr);
    end
    fprintf('+%s+\n\n', repmat('-',1,90));

    fprintf('  Per-Mode SCSR:\n');
    fprintf('  %-28s  %7s  %9s  %8s\n', 'Method', 'City', 'Highway', 'Parked');
    fprintf('  %s\n', repmat('-',1,58));
    for m = 1:num_methods
        fprintf('  %-28s  %6.1f%%   %7.1f%%   %7.1f%%\n', methods{m}, ...
            S(m,1).avg_scsr, S(m,2).avg_scsr, S(m,3).avg_scsr);
    end
    fprintf('\n');

    %% Graphical table using imagesc + text (Octave-safe, no annotation needed)
    figure('Position', [100, 100, 1300, 380]);

    col_labels = {'Method','Avg Reward','Max Temp(C)','Violations','Avg Latency','SCSR(%)','Load Std','Delta vs RR'};
    ncols = length(col_labels);
    nrows = num_methods;

    % Build data matrix (numeric for colour mapping, text for display)
    cell_text  = cell(nrows+1, ncols);
    cell_text(1,:) = col_labels;
    rr_r = S(num_methods, 4).avg_reward;
    for m = 1:num_methods
        s    = S(m,4);
        impr = s.avg_reward - rr_r;
        cell_text{m+1,1} = methods{m};
        cell_text{m+1,2} = sprintf('%+.3f', s.avg_reward);
        cell_text{m+1,3} = sprintf('%.1fC',  s.max_temp);
        cell_text{m+1,4} = sprintf('%d',      s.violations);
        cell_text{m+1,5} = sprintf('%.0f',    s.avg_latency);
        cell_text{m+1,6} = sprintf('%.1f%%',  s.avg_scsr);
        cell_text{m+1,7} = sprintf('%.2f',    s.avg_lb);
        cell_text{m+1,8} = sprintf('%+.3f',   impr);
    end

    % Determine best values (for green highlight)
    % FIX: arrayfun with struct array indexing is unreliable in Octave.
    % Use explicit for loops instead.
    rewards   = zeros(1, num_methods);
    scsrs     = zeros(1, num_methods);
    latencies = zeros(1, num_methods);
    temps     = zeros(1, num_methods);
    for m = 1:num_methods
        rewards(m)   = S(m,4).avg_reward;
        scsrs(m)     = S(m,4).avg_scsr;
        latencies(m) = S(m,4).avg_latency;
        temps(m)     = S(m,4).max_temp;
    end
    [~, best_r] = max(rewards); [~, best_s] = max(scsrs);
    [~, best_l] = min(latencies); [~, best_t] = min(temps);

    % Draw background patches then text
    ax = axes('Position', [0.01 0.12 0.98 0.80]);
    axis off; hold on;

    total_rows = nrows + 1;
    col_w = ones(1, ncols) / ncols;
    col_x = [0, cumsum(col_w)];
    row_h = 1 / total_rows;

    for r = 0:total_rows-1
        for c = 1:ncols
            x0 = col_x(c); y0 = 1 - (r+1)*row_h;
            w  = col_w(c); h  = row_h;

            if r == 0
                fc = [0.1 0.23 0.42];  % header -- dark blue
            elseif r == 1
                fc = [0.87 0.93 1.0];  % HQ-Map row -- light blue
            elseif mod(r,2)==0
                fc = [0.94 0.96 0.99];
            else
                fc = [1 1 1];
            end

            % Green highlight for best values
            if r > 0
                m_idx = r;
                if (c==2 && m_idx==best_r) || (c==6 && m_idx==best_s) || ...
                   (c==5 && m_idx==best_l) || (c==3 && m_idx==best_t)
                    fc = [0.7 0.95 0.7];
                end
                % Red for violations > 0
                if c==4 && S(m_idx,4).violations > 0
                    fc = [0.95 0.7 0.7];
                end
            end

            patch([x0 x0+w x0+w x0], [y0 y0 y0+h y0+h], fc, ...
                  'EdgeColor', [0.8 0.8 0.8], 'LineWidth', 0.5);

            txt = cell_text{r+1, c};
            tc  = [0.1 0.1 0.1];
            fw  = 'normal';
            if r == 0, tc = [1 1 1]; fw = 'bold'; end
            if r == 1 && c == 1, fw = 'bold'; end
            if r > 0 && ((c==2 && r==best_r)||(c==6 && r==best_s)||...
                         (c==5 && r==best_l)||(c==3 && r==best_t))
                tc = [0 0.35 0]; fw = 'bold';
            end

            text(x0 + w/2, y0 + h/2, txt, ...
                 'HorizontalAlignment', 'center', 'VerticalAlignment', 'middle', ...
                 'FontSize', 8.5, 'FontWeight', fw, 'Color', tc);
        end
    end
    hold off;

    title('Table I: HQ-Map vs. Prior-Art Methods -- Performance Comparison (1000 Steps)', ...
          'FontSize', 11, 'FontWeight', 'bold');

    axes('Position', [0 0 1 0.1], 'Visible', 'off');
    text(0.5, 0.5, ['Green = best in column | Blue row = HQ-Map | ' ...
         'Red = thermal violation | SCSR = Safety Constraint Satisfaction Rate'], ...
         'HorizontalAlignment', 'center', 'FontSize', 7.5, 'Color', [0.4 0.4 0.4]);

    print('-dpng', 'results/comparison_table.png');
    fprintf('Saved: results/comparison_table.png\n');
end
