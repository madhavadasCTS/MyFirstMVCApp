function state_idx = get_state_p2(mapping, core_temps, N, num_clusters)
% GET_STATE_P2  Encode system state as a discrete index in 1..20.
%
%  Phase 2 (original) used only 10 states by collapsing load and thermal
%  into a single dimension, which meant many distinct situations mapped to
%  the same index and the Q-table could not distinguish them.
%
%  This version uses a 2-D grid:
%
%    Load dimension  (1-5): based on std-dev of per-cluster task counts
%    Thermal dimension (1-4): based on normalised mean cluster-peak temp
%
%  Combined index = (thermal_level - 1) * 5 + load_level   --> 1..20
%
%  This gives the Q-table 2x the resolution to discriminate situations
%  that differ thermally but have similar load (and vice versa).

    num_cores_per_cluster = (N * N) / num_clusters;

    cluster_loads     = zeros(num_clusters, 1);
    cluster_max_temps = zeros(num_clusters, 1);

    for c = 1:num_clusters
        s_node = (c - 1) * num_cores_per_cluster + 1;
        e_node = c       * num_cores_per_cluster;

        cluster_loads(c)     = sum(mapping >= s_node & mapping <= e_node);
        cluster_max_temps(c) = max(core_temps(s_node:e_node));
    end

    %% -- Load level (1-5) ------------------------------------------
    % 0 std-dev = perfectly balanced = level 1
    % std-dev >= 4 = heavily imbalanced = level 5
    load_std   = std(cluster_loads);
    load_level = min(5, floor(load_std) + 1);   % 1..5

    %% -- Thermal level (1-4) --------------------------------------
    % Normalise mean-of-cluster-peaks to [0, 1] over [45C, 85C]
    avg_peak_norm = (mean(cluster_max_temps) - 45) / (85 - 45);
    avg_peak_norm = max(0, min(1, avg_peak_norm));

    % 4 buckets: [0,0.25) [0.25,0.5) [0.5,0.75) [0.75,1]
    thermal_level = min(4, floor(avg_peak_norm * 4) + 1);  % 1..4

    %% -- Combined index --------------------------------------------
    state_idx = (thermal_level - 1) * 5 + load_level;      % 1..20
    state_idx = max(1, min(20, state_idx));
end
