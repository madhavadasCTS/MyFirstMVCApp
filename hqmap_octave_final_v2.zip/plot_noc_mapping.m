function plot_noc_mapping(mapping, core_temps, N, mode_name)
% PLOT_NOC_MAPPING  NoC heatmap -- fully Octave compatible.
% Removes colorbar label via ylabel (not supported in Octave),
% uses plain text labels instead of degree symbol.

    num_tasks = length(mapping);

    figure('Position', [300, 200, 680, 600]);

    %% Temperature grid
    temp_grid = zeros(N, N);
    for i = 1:(N*N)
        r = floor((i-1)/N) + 1;
        c = mod(i-1, N) + 1;
        temp_grid(r, c) = core_temps(i);
    end

    imagesc(temp_grid);
    colormap('hot');
    colorbar();
    caxis([45, max(100, max(core_temps))]);

    title(sprintf('NoC Task Map -- %s Mode  (Peak: %.1fC)', mode_name, max(core_temps)), ...
          'FontSize', 12, 'FontWeight', 'bold');

    hold on;

    %% Fine grid lines
    for i = 0.5:1:N+0.5
        plot([0.5, N+0.5], [i, i], 'k-', 'LineWidth', 0.4);
        plot([i, i], [0.5, N+0.5], 'k-', 'LineWidth', 0.4);
    end

    %% Cluster boundary lines (thick white)
    cluster_size = N / 2;
    for b = cluster_size+0.5 : cluster_size : N-0.5
        plot([0.5, N+0.5], [b, b], 'w-', 'LineWidth', 2.5);
        plot([b, b], [0.5, N+0.5], 'w-', 'LineWidth', 2.5);
    end

    %% Cluster labels
    quad_labels = {'Q1','Q2','Q3','Q4'};
    quad_pos    = [1,1; 1,5; 5,1; 5,5];
    for q = 1:4
        text(quad_pos(q,2)-0.3, quad_pos(q,1)+0.3, quad_labels{q}, ...
             'Color', 'white', 'FontSize', 9, 'FontWeight', 'bold');
    end

    %% Task labels
    for t = 1:num_tasks
        core = mapping(t);
        if core <= 0, continue; end
        r = floor((core-1)/N) + 1;
        c = mod(core-1, N) + 1;
        if temp_grid(r, c) > 80
            txt_color = [1 1 1];
        else
            txt_color = [0 1 1];
        end
        text(c, r, sprintf('T%d', t), ...
             'HorizontalAlignment', 'center', ...
             'FontSize', 7, 'FontWeight', 'bold', 'Color', txt_color);
    end

    hold off;
    set(gca, 'XTick', 1:N, 'YTick', 1:N);
    xlabel('NoC Columns'); ylabel('NoC Rows');
    axis square;

    fname = sprintf('NoC_Map_%s.png', mode_name);
    print('-dpng', fname);
    fprintf('Saved: %s\n', fname);
end
