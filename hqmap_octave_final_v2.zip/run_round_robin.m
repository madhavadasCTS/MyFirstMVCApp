function [mapping, reward, hop_cost] = run_round_robin( ...
    comm_matrix, task_types, core_temps, N, max_safe_temp)
% RUN_ROUND_ROBIN  Round-robin task mapper (naive lower-bound baseline).
%
%  Tasks are randomly permuted then assigned in round-robin rotation
%  across the 4 clusters. The random permutation is essential to prevent
%  coincidental advantages from task-numbering order (e.g. sequential
%  tasks 0,1,2,3 being adjacent in the DAG AND in core numbering).
%
%  This is a true naive baseline: no communication, thermal, or safety
%  awareness. Any intelligent method should clearly outperform this.

    num_tasks    = size(comm_matrix, 1);
    num_clusters = 4;
    num_cpc      = (N * N) / num_clusters;

    mapping  = zeros(num_tasks, 1);
    slot     = zeros(num_clusters, 1);

    % Random permutation removes coincidental ordering benefits
    task_order = randperm(num_tasks);

    for idx = 1:num_tasks
        t          = task_order(idx);
        cluster_id = mod(idx-1, num_clusters) + 1;
        core       = (cluster_id-1)*num_cpc + slot(cluster_id) + 1;
        mapping(t) = core;
        slot(cluster_id) = slot(cluster_id) + 1;
    end

    [reward, hop_cost] = compute_reward_p2( ...
        mapping, comm_matrix, task_types, core_temps, N, max_safe_temp);
end
