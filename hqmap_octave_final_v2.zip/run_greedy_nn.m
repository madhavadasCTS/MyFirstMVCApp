function [mapping, reward, hop_cost] = run_greedy_nn( ...
    comm_matrix, task_types, core_temps, N, max_safe_temp)
% RUN_GREEDY_NN  Greedy nearest-neighbour task mapper.
%
%  Standard heuristic baseline used in NoC mapping literature
%  [Srinivasan et al. 2007; Asadzadeh et al. 2024]:
%    - Sort tasks by total communication weight (descending)
%    - Place the first task at the thermal-coolest available core
%    - For each subsequent task, choose the free core that minimises
%      the weighted hop distance to its already-placed neighbours
%    - Tie-break: prefer cooler cores
%
%  This represents the best non-learning heuristic. Any improvement
%  of HQ-Map over this is due to the learned, adaptive policy.

    num_tasks = size(comm_matrix, 1);
    num_cores = N * N;
    mapping   = zeros(num_tasks, 1);

    % Sort tasks by total communication weight (heaviest first)
    comm_weight = sum(comm_matrix, 2) + sum(comm_matrix, 1)';
    [~, task_order] = sort(comm_weight, 'descend');

    for t_idx = 1:length(task_order)
        task_id  = task_order(t_idx);
        occupied = mapping(mapping > 0);
        free     = setdiff(1:num_cores, occupied);

        if isempty(free), break; end

        if t_idx == 1
            % First task: place on coolest core
            [~, best] = min(core_temps(free));
            mapping(task_id) = free(best);
        else
            % Subsequent: minimise weighted hop cost to placed neighbours
            best_core = free(1);
            best_cost = inf;

            for ci = 1:length(free)
                c     = free(ci);
                cx    = mod(c-1, N);  cy = floor((c-1)/N);
                cost  = 0;
                for t2 = 1:num_tasks
                    if mapping(t2) > 0 && comm_matrix(task_id, t2) > 0
                        c2   = mapping(t2);
                        cx2  = mod(c2-1, N);  cy2 = floor((c2-1)/N);
                        cost = cost + (abs(cx-cx2)+abs(cy-cy2)) * comm_matrix(task_id, t2);
                    end
                end
                % Add thermal tiebreak (small weight)
                cost = cost + 0.1 * core_temps(c);

                if cost < best_cost
                    best_cost = cost;
                    best_core = c;
                end
            end
            mapping(task_id) = best_core;
        end
    end

    [reward, hop_cost] = compute_reward_p2( ...
        mapping, comm_matrix, task_types, core_temps, N, max_safe_temp);
end
