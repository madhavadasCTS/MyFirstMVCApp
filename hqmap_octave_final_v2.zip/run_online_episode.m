function [new_coarse_Q, new_fine_Q, mapping, total_reward, total_cost] = run_online_episode( ...
    comm_matrix, task_clusters, task_types, core_temps, N, num_clusters, ...
    coarse_Q, fine_Q, alpha, gamma, epsilon, max_safe_temp)
% RUN_ONLINE_EPISODE  One step of hierarchical TD Q-learning.
%
%   Performs coarse (zone selection) then fine (core selection) placement
%   for all tasks, records (s, a, s') for every decision, computes the
%   episode reward, then applies the correct Bellman TD(0) update:
%
%       Q(s,a) <- Q(s,a) + alpha * [ r + gamma * max_a' Q(s',a') - Q(s,a) ]
%
%   gamma IS NOW USED -- the update bootstraps off the next state so the
%   agent learns to plan ahead, not just average immediate rewards.

    new_coarse_Q = coarse_Q;
    new_fine_Q   = fine_Q;

    num_tasks             = size(comm_matrix, 1);
    num_cores             = N * N;
    num_cores_per_cluster = num_cores / num_clusters;

    mapping = zeros(num_tasks, 1);

    % History columns: [s, a, s_next]
    coarse_history = zeros(0, 3);
    fine_history   = zeros(0, 3);

    %% -- HIERARCHICAL PLACEMENT ----------------------------------
    for tc = 1:num_clusters
        task_list = task_clusters{tc};
        if isempty(task_list), continue; end

        % --- COARSE: choose NoC zone ---
        s_coarse = get_state_p2(mapping, core_temps, N, num_clusters);

        if rand() < epsilon
            noc_zone = randi(num_clusters);
        else
            [~, noc_zone] = max(new_coarse_Q(s_coarse, :));
        end

        core_start      = (noc_zone - 1) * num_cores_per_cluster + 1;
        core_end        =  noc_zone      * num_cores_per_cluster;
        available_cores = core_start:core_end;

        % --- FINE: place each task within chosen zone ---
        for t_idx = 1:length(task_list)
            task_id = task_list(t_idx);

            % Fine state = how full is this zone right now (0-19)
            local_used = sum(mapping(mapping >= core_start & mapping <= core_end) > 0);
            s_fine     = mod(local_used, 20) + 1;   % 1-20

            % epsilon-greedy fine action (index into available_cores)
            n_avail = length(available_cores);
            if rand() < epsilon
                local_action = randi(n_avail);
            else
                % Only look at the columns that exist for this zone size
                q_row        = new_fine_Q(s_fine, :);
                q_row        = q_row(1:min(end, n_avail));
                [~, local_action] = max(q_row);
                local_action = min(local_action, n_avail);
            end

            chosen_core = available_cores(local_action);

            % Collision handling: never double-map to same core
            if any(mapping == chosen_core)
                free_local = setdiff(available_cores, mapping(mapping > 0));
                if ~isempty(free_local)
                    chosen_core = free_local(1);
                    % Remap local_action to match actual placement
                    local_action = find(available_cores == chosen_core, 1);
                    if isempty(local_action), local_action = 1; end
                else
                    global_free = setdiff(1:num_cores, mapping(mapping > 0));
                    if ~isempty(global_free)
                        chosen_core  = global_free(randi(length(global_free)));
                        local_action = 1;   % fallback; outside normal zone
                    end
                end
            end

            mapping(task_id) = chosen_core;

            % Next fine state after this placement
            s_fine_next = mod(local_used + 1, 20) + 1;
            fine_history(end+1, :) = [s_fine, local_action, s_fine_next]; %#ok<AGROW>
        end

        % Coarse next-state after the full cluster is placed
        s_coarse_next = get_state_p2(mapping, core_temps, N, num_clusters);
        coarse_history(end+1, :) = [s_coarse, noc_zone, s_coarse_next]; %#ok<AGROW>
    end

    %% -- REWARD --------------------------------------------------
    [total_reward, total_cost] = compute_reward_p2( ...
        mapping, comm_matrix, task_types, core_temps, N, max_safe_temp);

    %% -- CORRECT TD(0) Q-TABLE UPDATE ----------------------------
    %
    %  TD target  = r  +  gamma * max_a'( Q(s', a') )
    %  TD error   = TD_target - Q(s, a)
    %  Update     = Q(s,a) + alpha * TD_error
    %
    %  Using total_reward as r for every sub-decision in this episode
    %  (single-reward episodic formulation -- reward is revealed at end).

    for i = 1:size(coarse_history, 1)
        s      = coarse_history(i, 1);
        a      = coarse_history(i, 2);
        s_next = coarse_history(i, 3);

        td_target = total_reward + gamma * max(new_coarse_Q(s_next, :));
        new_coarse_Q(s, a) = new_coarse_Q(s, a) + ...
            alpha * (td_target - new_coarse_Q(s, a));
    end

    for i = 1:size(fine_history, 1)
        s      = fine_history(i, 1);
        a      = fine_history(i, 2);
        s_next = fine_history(i, 3);

        % Guard: action index must be within table width
        a = min(a, size(new_fine_Q, 2));

        td_target = total_reward + gamma * max(new_fine_Q(s_next, :));
        new_fine_Q(s, a) = new_fine_Q(s, a) + ...
            alpha * (td_target - new_fine_Q(s, a));
    end

end
