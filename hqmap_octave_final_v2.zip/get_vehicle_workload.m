function [comm_matrix, task_types] = get_vehicle_workload(mode, num_tasks)
% GET_VEHICLE_WORKLOAD  Generate a DAG workload for the given driving mode.
%
%  Modes:
%    1 = City     -- balanced ADAS + Navigation
%    2 = Highway  -- full sensor-fusion mesh (Camera + Lidar + Radar)
%    3 = Parked   -- infotainment focus
%
%  task_types:
%    1 = Critical / Safety  (ISO 26262 ASIL-D, hard latency + proximity)
%    2 = Best-Effort        (soft latency)
%    3 = Background         (OS, health monitor)
%
%  Highway DAG redesigned (vs Phase 2) to have 20 critical communicating
%  pairs -- sufficient to distinguish intelligent placement from naive.
%  The 3-pipeline structure (Camera, Lidar, Radar) reflects real automotive
%  sensor fusion architectures in production ADAS SoCs.

    comm_matrix = zeros(num_tasks, num_tasks);
    task_types  = zeros(num_tasks, 1);

    % Background chain (always running): tasks 20-32
    task_types(20:end) = 3;
    for i = 20:31
        comm_matrix(i, i+1) = 5;
    end

    switch mode

        case 1  % -- CITY: balanced mix ----------------------------
            task_types(1:8) = 1;
            for p = [1,2,40; 2,3,40; 3,4,40; 4,5,20; 5,6,15; 6,7,15; 7,8,10]'
                comm_matrix(p(1),p(2)) = p(3);
            end
            task_types(9:12) = 2;
            comm_matrix(9,10)=30; comm_matrix(10,11)=30; comm_matrix(11,12)=20;
            task_types(13:19) = 2;
            comm_matrix(13,14)=20; comm_matrix(14,15)=15;

        case 2  % -- HIGHWAY: three-pipeline sensor fusion ----------
            task_types(1:15) = 1;

            % Camera pipeline: tasks 1-4
            comm_matrix(1,2)=100; comm_matrix(2,3)=90; comm_matrix(3,4)=80;
            % Lidar pipeline: tasks 5-8
            comm_matrix(5,6)=100; comm_matrix(6,7)=90; comm_matrix(7,8)=80;
            % Radar pipeline: tasks 9-12
            comm_matrix(9,10)=80; comm_matrix(10,11)=75; comm_matrix(11,12)=70;
            % All three feed fusion node (task 13)
            comm_matrix(4,13)=60; comm_matrix(8,13)=60; comm_matrix(12,13)=60;
            % Safety voting chain
            comm_matrix(13,14)=40; comm_matrix(14,15)=35;
            % Best-effort nav
            task_types(16:19) = 2;
            comm_matrix(16,17)=20;

        case 3  % -- PARKED: infotainment ----------------------------
            task_types(1:10) = 2;
            comm_matrix(1,2)=120; comm_matrix(2,3)=120; comm_matrix(3,4)=120;
            comm_matrix(4,5)=60;  comm_matrix(5,6)=60;
            task_types(11:14) = 2;
            comm_matrix(11,12)=40; comm_matrix(12,13)=40;
            task_types(15:16) = 1;
            comm_matrix(15,16)=10;
            % FIX: tasks 17-19 were unassigned (type=0). Assign as background.
            task_types(17:19) = 3;
    end
end
