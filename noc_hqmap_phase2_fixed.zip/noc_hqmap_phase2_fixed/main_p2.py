"""
HQ-Map Phase 2 — Main Simulation Runner.
Smart Vehicle SoC Task Mapping with Hierarchical Q-Learning.

Usage
-----
  python main_p2.py                      # standard 1000-step run
  python main_p2.py --mode comparison    # full 5-method comparison
  python main_p2.py --steps 500          # shorter run
  python main_p2.py --seed 42            # reproducible run
  python main_p2.py --no_plots           # headless / CI
"""

import argparse
import os
import json
import time
import numpy as np

from environment import get_vehicle_workload, VehicleNoCEnv, mode_name
from models import (
    cluster_tasks,
    HQMapAgent, FlatQAgent, QThermalAgent,
    run_greedy_nn, run_round_robin,
)
from utils import (
    plot_phase2_results,
    plot_noc_mapping,
    plot_comparison,
    print_results_table,
    plot_results_table,
)

# ── Default configuration ─────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "N":             8,
    "num_tasks":     32,
    "num_clusters":  4,
    "total_steps":   1000,

    # RL hyper-parameters (matches Octave exactly)
    "alpha":          0.10,
    "gamma":          0.90,
    "epsilon":        0.50,
    "epsilon_decay":  0.9935,
    "epsilon_min":    0.05,

    # Thermal
    "ambient_temp":   45.0,
    "max_safe_temp":  85.0,
    "heat_dissipation": 0.25,

    # Driving mode transition steps
    "city_end":    300,
    "highway_end": 700,

    # Logging
    "eval_interval": 50,
}

METHOD_NAMES = [
    "HQ-Map (Ours)",
    "Flat Q (FLEA-style)",
    "Q-Thermal style",
    "Greedy NN",
    "Round-Robin",
]


# ─────────────────────────────────────────────────────────────────────────────
# Core simulation loop
# ─────────────────────────────────────────────────────────────────────────────

def run_hqmap_simulation(cfg: dict, plots: bool = True) -> dict:
    """
    Run the full HQ-Map Phase 2 simulation.
    Returns the history dict.
    """
    N             = cfg["N"]
    num_tasks     = cfg["num_tasks"]
    num_clusters  = cfg["num_clusters"]
    num_cores     = N * N
    num_cpc       = num_cores // num_clusters
    total_steps   = cfg["total_steps"]
    eval_interval = cfg["eval_interval"]

    print("=" * 60)
    print("  HQ-Map Phase 2 — Smart Vehicle SoC RL (Python)")
    print("=" * 60)
    print(f"  Config: {N}×{N} NoC | {num_tasks} tasks | {num_clusters} clusters | {total_steps} steps")
    print(f"  RL: α={cfg['alpha']}  γ={cfg['gamma']}  ε={cfg['epsilon']}→{cfg['epsilon_min']}")
    print()

    # ── Environment + Agent ───────────────────────────────────────────────────
    env = VehicleNoCEnv(
        N=N,
        num_tasks=num_tasks,
        num_clusters=num_clusters,
        ambient_temp=cfg["ambient_temp"],
        max_safe_temp=cfg["max_safe_temp"],
        heat_dissipation=cfg["heat_dissipation"],
    )

    agent = HQMapAgent(
        num_clusters=num_clusters,
        num_cpc=num_cpc,
        alpha=cfg["alpha"],
        gamma=cfg["gamma"],
        epsilon=cfg["epsilon"],
        epsilon_decay=cfg["epsilon_decay"],
        epsilon_min=cfg["epsilon_min"],
    )

    # ── History ───────────────────────────────────────────────────────────────
    history = {
        "temps":        [],
        "latency":      [],
        "rewards":      [],
        "modes":        [],
        "load_balance": [],
        "hotspot_count":[],
        "scsr":         [],
    }

    # Snapshots for NoC mapping plots
    snapshots = {}
    task_clusters = None
    comm_matrix   = None
    task_types    = None

    t0 = time.time()

    for step in range(1, total_steps + 1):

        # ── Driving mode ──────────────────────────────────────────────────────
        if step <= cfg["city_end"]:
            mode = 1
        elif step <= cfg["highway_end"]:
            mode = 2
        else:
            mode = 3

        mode_str = mode_name(mode)

        # ── Update workload on mode transition or first step ──────────────────
        if step == 1 or step == cfg["city_end"] + 1 or step == cfg["highway_end"] + 1:
            comm_matrix, task_types = get_vehicle_workload(mode, num_tasks)
            task_clusters, _        = cluster_tasks(comm_matrix, num_clusters, task_types)
            env.set_workload(comm_matrix, task_types)
            print(f"[Step {step:4d}] Mode → {mode_str:<8}  reclustered.")

        # ── HQ-Map episode ────────────────────────────────────────────────────
        mapping, reward, hop_cost = agent.run_episode(
            env, comm_matrix, task_clusters, task_types
        )

        # ── Thermal dynamics ──────────────────────────────────────────────────
        env.update_temps(mapping, task_types)

        # ── Metrics ───────────────────────────────────────────────────────────
        scsr = env.compute_scsr(mapping, comm_matrix, task_types)

        cluster_loads = np.array([
            np.sum((mapping >= c * num_cpc + 1) & (mapping <= (c + 1) * num_cpc))
            for c in range(num_clusters)
        ], dtype=float)

        max_temp      = float(np.max(env.core_temps))
        hotspot_count = int(np.sum(env.core_temps > (cfg["max_safe_temp"] - 10)))

        history["temps"].append(max_temp)
        history["latency"].append(hop_cost)
        history["rewards"].append(reward)
        history["modes"].append(mode)
        history["load_balance"].append(float(np.std(cluster_loads)))
        history["hotspot_count"].append(hotspot_count)
        history["scsr"].append(scsr)

        # ── Snapshots for mapping plots ───────────────────────────────────────
        if step == cfg["city_end"]:
            snapshots["City"] = (mapping.copy(), env.core_temps.copy(), task_types.copy())
        if step == cfg["highway_end"]:
            snapshots["Highway"] = (mapping.copy(), env.core_temps.copy(), task_types.copy())
        if step == total_steps:
            # Use the actual mode name at the final step, not a hardcoded label
            final_label = mode_name(mode)
            if final_label not in snapshots:   # don't overwrite if already captured
                snapshots[final_label] = (mapping.copy(), env.core_temps.copy(), task_types.copy())

        # ── Console log ───────────────────────────────────────────────────────
        if step % eval_interval == 0:
            elapsed = time.time() - t0
            print(
                f"Step {step:4d} [{mode_str:<8}] | "
                f"MaxTemp:{max_temp:5.1f}°C | "
                f"Lat:{hop_cost:6.0f} | "
                f"Rew:{reward:+6.2f} | "
                f"SCSR:{scsr:.2f} | "
                f"LB:{np.std(cluster_loads):.1f} | "
                f"ε:{agent.epsilon:.3f} | "
                f"{elapsed:.1f}s"
            )

    elapsed = time.time() - t0
    print(f"\nSimulation complete in {elapsed:.1f}s")

    # ── Save results ──────────────────────────────────────────────────────────
    os.makedirs("results", exist_ok=True)
    np.save("results/hq_map_phase2_coarse_Q.npy", agent.coarse_Q)
    np.save("results/hq_map_phase2_fine_Q.npy",   agent.fine_Q)
    with open("results/hq_map_phase2_history.json", "w") as f:
        json.dump({k: [float(v) for v in vals] for k, vals in history.items()}, f, indent=2)
    with open("results/config.json", "w") as f:
        json.dump(cfg, f, indent=2)
    print("Results saved to results/")

    # ── Plots ─────────────────────────────────────────────────────────────────
    if plots:
        plot_phase2_results(history, N, total_steps)
        for mode_label, (m, t, tt) in snapshots.items():
            plot_noc_mapping(m, t, N, mode_label, tt)

    return history, snapshots


# ─────────────────────────────────────────────────────────────────────────────
# Comparison run (5 methods)
# ─────────────────────────────────────────────────────────────────────────────

def run_comparison(cfg: dict, plots: bool = True) -> None:
    """
    Full 5-method comparison matching run_comparison.m.
    """
    N             = cfg["N"]
    num_tasks     = cfg["num_tasks"]
    num_clusters  = cfg["num_clusters"]
    num_cores     = N * N
    num_cpc       = num_cores // num_clusters
    total_steps   = cfg["total_steps"]

    print("=" * 70)
    print("  HQ-Map Phase 2 — Full Comparison (5 methods)")
    print("=" * 70)
    print(f"  {N}×{N} NoC | {num_tasks} tasks | {num_clusters} clusters | {total_steps} steps\n")

    # Per-method result storage
    all_results = []

    for m_idx, method_name in enumerate(METHOD_NAMES):
        print(f"[{m_idx+1}/{len(METHOD_NAMES)}] Running: {method_name}")

        # Fresh environment + agents per method
        env = VehicleNoCEnv(
            N=N,
            num_tasks=num_tasks,
            num_clusters=num_clusters,
            ambient_temp=cfg["ambient_temp"],
            max_safe_temp=cfg["max_safe_temp"],
            heat_dissipation=cfg["heat_dissipation"],
        )

        # Create only the agent needed for this method (not all three)
        if m_idx == 0:
            hq_agent = HQMapAgent(num_clusters=num_clusters, num_cpc=num_cpc, **_rl_kwargs(cfg))
        elif m_idx == 1:
            flat_agent = FlatQAgent(num_cores=num_cores, **_rl_kwargs(cfg))
        elif m_idx == 2:
            qt_agent = QThermalAgent(num_cores=num_cores, **_rl_kwargs(cfg))

        result = {k: [] for k in ["temps", "latency", "rewards", "load_balance", "scsr", "hotspot_count", "modes"]}

        task_clusters = None
        comm_matrix   = None
        task_types    = None

        for step in range(1, total_steps + 1):
            mode = 1 if step <= cfg["city_end"] else (2 if step <= cfg["highway_end"] else 3)

            # Workload + cluster on transitions
            if step == 1 or step == cfg["city_end"] + 1 or step == cfg["highway_end"] + 1:
                comm_matrix, task_types = get_vehicle_workload(mode, num_tasks)
                task_clusters, _        = cluster_tasks(comm_matrix, num_clusters, task_types)
                env.set_workload(comm_matrix, task_types)

            # Run method
            if m_idx == 0:   # HQ-Map
                mapping, reward, hop_cost = hq_agent.run_episode(
                    env, comm_matrix, task_clusters, task_types)
            elif m_idx == 1: # Flat Q
                mapping, reward, hop_cost = flat_agent.run_episode(
                    env, comm_matrix, task_types)
            elif m_idx == 2: # Q-Thermal
                mapping, reward, hop_cost = qt_agent.run_episode(
                    env, comm_matrix, task_types)
            elif m_idx == 3: # Greedy NN
                mapping, reward, hop_cost = run_greedy_nn(
                    comm_matrix, task_types, env.core_temps.copy(), env)
            else:            # Round-Robin
                mapping, reward, hop_cost = run_round_robin(
                    comm_matrix, task_types, env.core_temps.copy(), env)

            env.update_temps(mapping, task_types)

            scsr = env.compute_scsr(mapping, comm_matrix, task_types)
            cluster_loads = np.array([
                np.sum((mapping >= c * num_cpc + 1) & (mapping <= (c + 1) * num_cpc))
                for c in range(num_clusters)
            ], dtype=float)

            result["temps"].append(float(np.max(env.core_temps)))
            result["latency"].append(float(hop_cost))
            result["rewards"].append(float(reward))
            result["load_balance"].append(float(np.std(cluster_loads)))
            result["scsr"].append(float(scsr))
            result["hotspot_count"].append(int(np.sum(env.core_temps > 75)))
            result["modes"].append(mode)

        all_results.append(result)
        # Summary
        avg_r = float(np.mean(result["rewards"]))
        avg_s = float(np.mean(result["scsr"])) * 100
        print(f"  → AvgReward:{avg_r:+.3f}  SCSR:{avg_s:.1f}%")

    print()

    # Table
    print_results_table(all_results, METHOD_NAMES)

    if plots:
        plot_comparison(all_results, METHOD_NAMES, total_steps)
        plot_results_table(all_results, METHOD_NAMES)

    # Save raw data
    os.makedirs("results", exist_ok=True)
    with open("results/comparison_results.json", "w") as f:
        json.dump({
            "methods": METHOD_NAMES,
            "results": [{k: [float(v) for v in vals]
                         for k, vals in r.items()} for r in all_results]
        }, f, indent=2)
    print("Comparison results saved to results/comparison_results.json")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _rl_kwargs(cfg):
    return dict(
        alpha         = cfg["alpha"],
        gamma         = cfg["gamma"],
        epsilon       = cfg["epsilon"],
        epsilon_decay = cfg["epsilon_decay"],
        epsilon_min   = cfg["epsilon_min"],
    )


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="HQ-Map Phase 2 — Smart Vehicle SoC RL")
    p.add_argument("--mode",      choices=["simulate", "comparison"], default="simulate",
                   help="Run mode: 'simulate' (HQ-Map only) or 'comparison' (all 5 methods)")
    p.add_argument("--steps",     type=int,   default=None,  help="Override total_steps")
    p.add_argument("--N",         type=int,   default=None,  help="Mesh size (N×N)")
    p.add_argument("--seed",      type=int,   default=None,  help="NumPy random seed")
    p.add_argument("--no_plots",  action="store_true",       help="Disable all matplotlib output")
    p.add_argument("--alpha",     type=float, default=None)
    p.add_argument("--gamma",     type=float, default=None)
    p.add_argument("--epsilon",   type=float, default=None)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.seed is not None:
        np.random.seed(args.seed)
        print(f"Random seed: {args.seed}")

    cfg = DEFAULT_CONFIG.copy()
    if args.steps   is not None: cfg["total_steps"] = args.steps
    if args.N       is not None: cfg["N"] = args.N
    if args.alpha   is not None: cfg["alpha"]   = args.alpha
    if args.gamma   is not None: cfg["gamma"]   = args.gamma
    if args.epsilon is not None: cfg["epsilon"] = args.epsilon

    plots = not args.no_plots

    if args.mode == "comparison":
        run_comparison(cfg, plots=plots)
    else:
        run_hqmap_simulation(cfg, plots=plots)
