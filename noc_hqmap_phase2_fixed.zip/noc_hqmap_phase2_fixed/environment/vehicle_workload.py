"""
Vehicle Workload Generator for HQ-Map Phase 2.

Generates task communication graphs (DAGs) for three automotive driving modes:
  - City    : balanced ADAS + Navigation
  - Highway : full three-pipeline sensor fusion (Camera + Lidar + Radar)
  - Parked  : infotainment focus

Task types follow ISO 26262 ASIL classification:
  1 = Critical / Safety  (ASIL-D: hard latency + proximity constraints)
  2 = Best-Effort        (soft latency)
  3 = Background         (OS daemons, health monitor)
"""

import numpy as np
from enum import IntEnum
from typing import Tuple


class DrivingMode(IntEnum):
    CITY    = 1   # Steps   1–300
    HIGHWAY = 2   # Steps 301–700
    PARKED  = 3   # Steps 701–1000


class TaskType(IntEnum):
    CRITICAL   = 1   # ISO 26262 ASIL-D
    BEST_EFFORT = 2
    BACKGROUND = 3


def get_vehicle_workload(
    mode: int,
    num_tasks: int = 32
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Generate a DAG workload for the given driving mode.

    Parameters
    ----------
    mode       : int  1=City, 2=Highway, 3=Parked
    num_tasks  : int  must be 32

    Returns
    -------
    comm_matrix : (num_tasks, num_tasks) float32 — directed bandwidth weights
    task_types  : (num_tasks,) int8       — 1=Critical, 2=BestEffort, 3=Background
    """
    assert num_tasks == 32, "Phase 2 workloads are designed for exactly 32 tasks."

    comm_matrix = np.zeros((num_tasks, num_tasks), dtype=np.float32)
    task_types  = np.zeros(num_tasks, dtype=np.int8)

    # ── Background chain (tasks 19–31, 0-indexed) always present ─────────────
    task_types[19:32] = TaskType.BACKGROUND
    for i in range(19, 31):
        comm_matrix[i, i + 1] = 5.0

    # ── Mode-specific workload ─────────────────────────────────────────────────
    if mode == DrivingMode.CITY:
        # Balanced mix: safety ADAS pipeline + nav best-effort
        task_types[0:8] = TaskType.CRITICAL
        critical_edges = [
            (0, 1, 40), (1, 2, 40), (2, 3, 40),
            (3, 4, 20), (4, 5, 15), (5, 6, 15), (6, 7, 10)
        ]
        for i, j, w in critical_edges:
            comm_matrix[i, j] = w

        task_types[8:12] = TaskType.BEST_EFFORT
        comm_matrix[8, 9]  = 30
        comm_matrix[9, 10] = 30
        comm_matrix[10,11] = 20

        task_types[12:19] = TaskType.BEST_EFFORT
        comm_matrix[12,13] = 20
        comm_matrix[13,14] = 15

    elif mode == DrivingMode.HIGHWAY:
        # Three-pipeline sensor fusion: Camera + Lidar + Radar → Fusion → Safety
        task_types[0:15] = TaskType.CRITICAL

        # Camera pipeline (tasks 0–3)
        comm_matrix[0, 1] = 100; comm_matrix[1, 2] = 90; comm_matrix[2, 3] = 80
        # Lidar pipeline (tasks 4–7)
        comm_matrix[4, 5] = 100; comm_matrix[5, 6] = 90; comm_matrix[6, 7] = 80
        # Radar pipeline (tasks 8–11)
        comm_matrix[8, 9] = 80;  comm_matrix[9,10] = 75; comm_matrix[10,11] = 70
        # Fusion node (task 12)
        comm_matrix[3, 12] = 60; comm_matrix[7, 12] = 60; comm_matrix[11,12] = 60
        # Safety voting chain (tasks 13–14)
        comm_matrix[12,13] = 40; comm_matrix[13,14] = 35

        # Best-effort nav (tasks 15–18)
        task_types[15:19] = TaskType.BEST_EFFORT
        comm_matrix[15,16] = 20

    elif mode == DrivingMode.PARKED:
        # Infotainment focus — lighter safety footprint
        task_types[0:10] = TaskType.BEST_EFFORT
        comm_matrix[0,1] = 120; comm_matrix[1,2] = 120; comm_matrix[2,3] = 120
        comm_matrix[3,4] = 60;  comm_matrix[4,5] = 60

        task_types[10:14] = TaskType.BEST_EFFORT
        comm_matrix[10,11] = 40; comm_matrix[11,12] = 40

        # Residual safety tasks (OBD + watchdog)
        task_types[14:16] = TaskType.CRITICAL
        comm_matrix[14,15] = 10

        # tasks 16–18 classified as background (fixed from Octave version)
        task_types[16:19] = TaskType.BACKGROUND
    else:
        raise ValueError(f"Unknown driving mode: {mode}. Use 1=City, 2=Highway, 3=Parked.")

    return comm_matrix, task_types


def mode_name(mode: int) -> str:
    return {1: "City", 2: "Highway", 3: "Parked"}.get(mode, "Unknown")
