"""
HQ-Map Phase 2 — NoC Environment (Gymnasium-compatible).

Extends Phase 1's NoCEnvironment with:
  - Automotive driving modes (City / Highway / Parked)
  - ISO 26262 safety constraints in reward (ASIL-D proximity)
  - Safety Constraint Satisfaction Rate (SCSR) metric
  - Thermal dynamics with mode-dependent heat-by-type
  - Dynamic re-clustering on mode transitions
"""

import numpy as np
from typing import Tuple, Dict, Optional, List

try:
    import gymnasium as gym
    from gymnasium import spaces
    _GYM_BASE = gym.Env
except ImportError:
    # gymnasium is optional — fall back to a plain base class
    class spaces:  # type: ignore
        class Discrete:
            def __init__(self, n): self.n = n
    class _GymEnvStub:
        def reset(self, *, seed=None, options=None): pass
        def step(self, action): pass
    _GYM_BASE = _GymEnvStub

from .vehicle_workload import get_vehicle_workload, mode_name


# ── Thermal constants ──────────────────────────────────────────────────────────
AMBIENT_TEMP      = 45.0
MAX_SAFE_TEMP     = 85.0
HEAT_DISSIPATION  = 0.25
HEAT_BY_TYPE      = {1: 6.0, 2: 3.0, 3: 1.5}   # Critical > BestEffort > Background


class VehicleNoCEnv(_GYM_BASE):  # type: ignore
    """
    Network-on-Chip Task Mapping Environment for Smart Vehicle SoC.

    Action space  : assign next task to a specific core (within active cluster)
    Observation   : encoded state vector (thermal + load + task type proportions)
    Reward        : -(w_hop*hop_norm + w_thermal*thermal_penalty + w_safety*safety_penalty)
                    + completion_bonus (matches Octave exactly)
    """

    metadata = {"render_modes": []}

    def __init__(
        self,
        N: int = 8,
        num_tasks: int = 32,
        num_clusters: int = 4,
        ambient_temp: float = AMBIENT_TEMP,
        max_safe_temp: float = MAX_SAFE_TEMP,
        heat_dissipation: float = HEAT_DISSIPATION,
        seed: Optional[int] = None,
    ):
        try:
            super().__init__()
        except TypeError:
            pass

        self.N                   = N
        self.num_tasks           = num_tasks
        self.num_clusters        = num_clusters
        self.num_cores           = N * N
        self.num_cpc             = self.num_cores // num_clusters  # cores per cluster
        self.ambient_temp        = ambient_temp
        self.max_safe_temp       = max_safe_temp
        self.heat_dissipation    = heat_dissipation

        # Observation: 20-state discrete index (compatible with Q-table agent)
        self.observation_space = spaces.Discrete(20)
        # Action: core index 0..num_cores-1
        self.action_space = spaces.Discrete(self.num_cores)

        # Internal state
        self.core_temps    = np.ones(self.num_cores) * ambient_temp
        self.mapping       = np.zeros(num_tasks, dtype=int)   # 0 = unplaced
        self.comm_matrix   = None
        self.task_types    = None
        self.driving_mode  = 1
        self.step_count    = 0

        if seed is not None:
            np.random.seed(seed)

    # ── Gymnasium API ──────────────────────────────────────────────────────────

    def reset(
        self,
        *,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ) -> Tuple[int, Dict]:
        try:
            super().reset(seed=seed)
        except TypeError:
            pass
        self.mapping    = np.zeros(self.num_tasks, dtype=int)
        self.core_temps = np.ones(self.num_cores) * self.ambient_temp  # FIX: clear thermal state
        self.step_count = 0
        obs = self._encode_state()
        return obs, {}

    def step(self, action: int) -> Tuple[int, float, bool, bool, Dict]:
        raise NotImplementedError(
            "VehicleNoCEnv.step() is not used in Phase 2. "
            "The HQMapAgent runs full episode placement via run_episode()."
        )

    # ── State encoding ─────────────────────────────────────────────────────────

    def _encode_state(self) -> int:
        """
        Encode (load_balance, thermal) → discrete index in [1..20].

        Load level  (1-5): std-dev of per-cluster task counts
        Thermal level (1-4): normalised mean of cluster peak temperatures
        Combined    : (thermal_level-1)*5 + load_level  →  1..20
        """
        cluster_loads     = np.zeros(self.num_clusters)
        cluster_max_temps = np.zeros(self.num_clusters)

        for c in range(self.num_clusters):
            s = c * self.num_cpc + 1          # core IDs are 1-indexed
            e = (c + 1) * self.num_cpc
            cluster_loads[c]     = np.sum((self.mapping >= s) & (self.mapping <= e))
            cluster_max_temps[c] = np.max(self.core_temps[c * self.num_cpc:(c + 1) * self.num_cpc])

        load_std    = np.std(cluster_loads)
        load_level  = int(np.clip(np.floor(load_std) + 1, 1, 5))

        avg_peak_norm  = (np.mean(cluster_max_temps) - self.ambient_temp) / (
            self.max_safe_temp - self.ambient_temp
        )
        avg_peak_norm  = float(np.clip(avg_peak_norm, 0.0, 1.0))
        thermal_level  = int(np.clip(np.floor(avg_peak_norm * 4) + 1, 1, 4))

        state_idx = (thermal_level - 1) * 5 + load_level
        return int(np.clip(state_idx, 1, 20))

    # ── Reward ─────────────────────────────────────────────────────────────────

    def compute_reward(
        self,
        mapping: np.ndarray,
        comm_matrix: np.ndarray,
        task_types: np.ndarray,
        core_temps: np.ndarray,
    ) -> Tuple[float, float]:
        """
        Multi-objective reward (matches compute_reward_p2.m exactly).
        Vectorised implementation — ~10× faster than the original Python loops.

        Returns
        -------
        reward   : float  (higher = better)
        hop_cost : float  (raw weighted hop count)
        """
        N         = self.N
        num_tasks = len(mapping)

        # ── Pre-compute grid coordinates for all tasks ─────────────────────────
        valid   = mapping > 0                              # (T,) bool
        cores   = mapping - 1                             # 0-indexed
        xs      = np.where(valid, cores % N,  0).astype(np.float32)
        ys      = np.where(valid, cores // N, 0).astype(np.float32)

        # ── Hop cost (fully vectorised) ────────────────────────────────────────
        # dx[i,j] = |x_i - x_j|,  dy[i,j] = |y_i - y_j|
        dx       = np.abs(xs[:, None] - xs[None, :])      # (T, T)
        dy       = np.abs(ys[:, None] - ys[None, :])
        hops     = dx + dy                                 # Manhattan distance matrix
        valid2d  = valid[:, None] & valid[None, :]         # both tasks placed
        hop_cost = float(np.sum(hops * comm_matrix * valid2d))

        total_bw  = float(np.sum(comm_matrix))
        hop_norm  = hop_cost / (2 * (N - 1) * total_bw) if total_bw > 0 else 0.0

        # ── Thermal penalty ────────────────────────────────────────────────────
        active_cores = mapping[valid] - 1
        cur_max = float(np.max(core_temps[active_cores])) if len(active_cores) > 0 \
                  else self.ambient_temp

        if cur_max > self.max_safe_temp:
            thermal_penalty = 2.0 + (cur_max - self.max_safe_temp) ** 2 / 100.0
        elif cur_max > self.max_safe_temp - 10:
            thermal_penalty = (cur_max - (self.max_safe_temp - 10)) / 10.0
        else:
            thermal_penalty = 0.0

        # ── Safety penalty (ASIL-D proximity, vectorised) ─────────────────────
        critical_mask = (task_types == 1)                  # (T,) bool
        # Pairs where task i is critical and there is outgoing bandwidth
        crit_comm    = comm_matrix * critical_mask[:, None]  # zero non-critical rows
        crit_pairs   = (crit_comm > 0) & valid2d             # (T, T)

        total_pairs  = int(np.sum(crit_pairs))
        violations   = int(np.sum(crit_pairs & (hops > 3)))
        safety_penalty = violations / max(1, total_pairs)

        # ── Combined reward ────────────────────────────────────────────────────
        reward = -(0.5 * hop_norm) - (1.0 * thermal_penalty) - (2.0 * safety_penalty)
        if np.all(mapping > 0):
            reward += 2.0

        return float(reward), float(hop_cost)

    # ── SCSR metric ────────────────────────────────────────────────────────────

    def compute_scsr(
        self,
        mapping: np.ndarray,
        comm_matrix: np.ndarray,
        task_types: np.ndarray,
    ) -> float:
        """
        Safety Constraint Satisfaction Rate (novel metric for automotive NoC).

        Fraction of critical-task communicating pairs placed within 3 hops.
        Threshold = ISO 26262 ASIL-D 2-cycle latency budget.
        Returns 1.0 when no critical communicating pairs exist.
        Vectorised implementation.
        """
        N     = self.N
        valid = mapping > 0

        cores = mapping - 1
        xs    = np.where(valid, cores % N,  0).astype(np.float32)
        ys    = np.where(valid, cores // N, 0).astype(np.float32)

        dx       = np.abs(xs[:, None] - xs[None, :])
        dy       = np.abs(ys[:, None] - ys[None, :])
        hops     = dx + dy
        valid2d  = valid[:, None] & valid[None, :]

        critical_mask = (task_types == 1)
        crit_pairs    = (comm_matrix > 0) & critical_mask[:, None] & valid2d

        total     = int(np.sum(crit_pairs))
        satisfied = int(np.sum(crit_pairs & (hops <= 3)))

        return 1.0 if total == 0 else satisfied / total

    # ── Thermal dynamics ───────────────────────────────────────────────────────

    def update_temps(self, mapping: np.ndarray, task_types: np.ndarray) -> None:
        """Apply heat dissipation then add load heat from current mapping."""
        # Dissipate
        self.core_temps = self.core_temps - (self.core_temps - self.ambient_temp) * self.heat_dissipation

        # Add heat from assigned tasks
        for t in range(len(mapping)):
            c = mapping[t]
            if c > 0:
                tt = int(task_types[t])
                if tt not in HEAT_BY_TYPE:
                    tt = 3
                self.core_temps[c - 1] += HEAT_BY_TYPE[tt]

        self.core_temps = np.maximum(self.core_temps, self.ambient_temp)

    def set_workload(self, comm_matrix: np.ndarray, task_types: np.ndarray) -> None:
        self.comm_matrix = comm_matrix
        self.task_types  = task_types
        self.mapping     = np.zeros(self.num_tasks, dtype=int)
