"""
HQ-Map Phase 2 — Hierarchical Q-Learning Agent.

Implements the two-level tabular TD(0) Q-learning from Phase 2, faithfully
ported from run_online_episode.m with all fixes:

  - Coarse Q-table : [20 states × num_clusters]  — zone selection
  - Fine Q-table   : [20 states × num_cpc]        — core selection within zone

Both tables use TD(0) Bellman updates with the full episode reward
(single-reward episodic formulation, same as Octave).

Also provides FlatQAgent, QThermalAgent for comparison runs.
"""

import numpy as np
from typing import List, Tuple, Optional

try:
    from ..environment.noc_env_p2 import VehicleNoCEnv
except ImportError:
    from environment.noc_env_p2 import VehicleNoCEnv


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _manhattan(c1: int, c2: int, N: int) -> int:
    x1, y1 = (c1 - 1) % N, (c1 - 1) // N
    x2, y2 = (c2 - 1) % N, (c2 - 1) // N
    return abs(x1 - x2) + abs(y1 - y2)


# ─── HQ-Map Agent (Phase 2 Q-table version) ───────────────────────────────────

class HQMapAgent:
    """
    Hierarchical Q-learning agent for automotive NoC mapping.

    Coarse level: picks the NoC zone for each task cluster.
    Fine level  : picks the core within the zone for each individual task.

    Both levels use ε-greedy exploration with TD(0) updates.
    """

    def __init__(
        self,
        num_clusters: int = 4,
        num_cpc: int = 16,          # cores per cluster
        num_states: int = 20,
        alpha: float = 0.1,
        gamma: float = 0.9,
        epsilon: float = 0.5,
        epsilon_decay: float = 0.9935,
        epsilon_min: float = 0.05,
    ):
        self.num_clusters = num_clusters
        self.num_cpc      = num_cpc
        self.alpha        = alpha
        self.gamma        = gamma
        self.epsilon      = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min  = epsilon_min

        # Q-tables (1-indexed states → 0-based in Python, so we keep size+1)
        self.coarse_Q = np.zeros((num_states + 1, num_clusters))  # rows 1..20 used
        self.fine_Q   = np.zeros((num_states + 1, num_cpc))

    # ── Episode ────────────────────────────────────────────────────────────────

    def run_episode(
        self,
        env: VehicleNoCEnv,
        comm_matrix: np.ndarray,
        task_clusters: List[np.ndarray],
        task_types: np.ndarray,
    ) -> Tuple[np.ndarray, float, float]:
        """
        One step of hierarchical TD Q-learning (ports run_online_episode.m).

        Returns
        -------
        mapping      : (num_tasks,) int  — 1-indexed core assignments
        total_reward : float
        hop_cost     : float
        """
        num_tasks = comm_matrix.shape[0]
        num_cores = env.num_cores
        num_cpc   = env.num_cpc
        N         = env.N

        mapping       = np.zeros(num_tasks, dtype=int)
        coarse_hist   = []   # (s, a, s_next)
        fine_hist     = []   # (s, a, s_next)

        # ── Hierarchical placement ─────────────────────────────────────────────
        for tc in range(self.num_clusters):
            task_list = task_clusters[tc]
            if len(task_list) == 0:
                continue

            # ── Coarse: choose NoC zone ────────────────────────────────────────
            env.mapping = mapping.copy()
            s_coarse = env._encode_state()

            if np.random.rand() < self.epsilon:
                noc_zone = np.random.randint(0, self.num_clusters)
            else:
                noc_zone = int(np.argmax(self.coarse_Q[s_coarse]))

            core_start = noc_zone * num_cpc + 1        # 1-indexed
            core_end   = (noc_zone + 1) * num_cpc      # inclusive
            avail      = list(range(core_start, core_end + 1))

            # ── Fine: place each task within chosen zone ───────────────────────
            for task_id in task_list:
                local_used = int(np.sum((mapping >= core_start) & (mapping <= core_end)))
                s_fine     = (local_used % 20) + 1    # 1-indexed

                n_avail = len(avail)
                if np.random.rand() < self.epsilon:
                    local_action = np.random.randint(0, n_avail)
                else:
                    q_row = self.fine_Q[s_fine, :min(self.num_cpc, n_avail)]
                    local_action = int(np.argmax(q_row))
                    local_action = min(local_action, n_avail - 1)

                chosen_core = avail[local_action]

                # ── Collision handling ─────────────────────────────────────────
                if chosen_core in mapping:
                    free_local = [c for c in avail if c not in mapping]
                    if free_local:
                        chosen_core  = free_local[0]
                        local_action = avail.index(chosen_core)
                    else:
                        global_free = [c for c in range(1, num_cores + 1) if c not in mapping]
                        if global_free:
                            chosen_core  = global_free[np.random.randint(len(global_free))]
                            local_action = 0

                mapping[task_id] = chosen_core

                s_fine_next = ((local_used + 1) % 20) + 1
                fine_hist.append((s_fine, local_action, s_fine_next))

            # Coarse next-state after full cluster is placed
            env.mapping = mapping.copy()
            s_coarse_next = env._encode_state()
            coarse_hist.append((s_coarse, noc_zone, s_coarse_next))

        # ── Reward ─────────────────────────────────────────────────────────────
        total_reward, hop_cost = env.compute_reward(
            mapping, comm_matrix, task_types, env.core_temps
        )

        # ── TD(0) Q-table updates ──────────────────────────────────────────────
        for s, a, sn in coarse_hist:
            td_target = total_reward + self.gamma * np.max(self.coarse_Q[sn])
            self.coarse_Q[s, a] += self.alpha * (td_target - self.coarse_Q[s, a])

        for s, a, sn in fine_hist:
            a = min(a, self.num_cpc - 1)
            td_target = total_reward + self.gamma * np.max(self.fine_Q[sn])
            self.fine_Q[s, a] += self.alpha * (td_target - self.fine_Q[s, a])

        # ── Epsilon decay ──────────────────────────────────────────────────────
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)

        return mapping, total_reward, hop_cost


# ─── Flat Q-Learning Baseline (FLEA-style) ─────────────────────────────────────

class FlatQAgent:
    """
    Flat (non-hierarchical) Q-learning baseline.
    Single Q-table: [20 states × num_cores].
    No zone decomposition, no spectral clustering.
    Isolates the contribution of hierarchical structure.
    """

    def __init__(
        self,
        num_cores: int = 64,
        num_states: int = 20,
        alpha: float = 0.1,
        gamma: float = 0.9,
        epsilon: float = 0.5,
        epsilon_decay: float = 0.9935,
        epsilon_min: float = 0.05,
    ):
        self.num_cores     = num_cores
        self.alpha         = alpha
        self.gamma         = gamma
        self.epsilon       = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min   = epsilon_min

        self.Q = np.zeros((num_states + 1, num_cores))  # rows 1..20 used

    def run_episode(
        self,
        env: VehicleNoCEnv,
        comm_matrix: np.ndarray,
        task_types: np.ndarray,
    ) -> Tuple[np.ndarray, float, float]:
        num_tasks = comm_matrix.shape[0]
        num_cores = env.num_cores
        mapping   = np.zeros(num_tasks, dtype=int)
        history   = []

        for task_id in range(num_tasks):
            env.mapping = mapping.copy()
            s = env._encode_state()

            if np.random.rand() < self.epsilon:
                action = np.random.randint(0, num_cores)
            else:
                q_row = self.Q[s].copy()
                occupied = mapping[mapping > 0] - 1  # 0-indexed
                q_row[occupied] = -np.inf
                action = int(np.argmax(q_row))

            # Collision fallback
            if (action + 1) in mapping:
                free = [c for c in range(num_cores) if (c + 1) not in mapping]
                if free:
                    action = free[np.random.randint(len(free))]

            mapping[task_id] = action + 1  # store 1-indexed

            env.mapping = mapping.copy()
            s_next = env._encode_state()
            history.append((s, action, s_next))

        reward, hop_cost = env.compute_reward(
            mapping, comm_matrix, task_types, env.core_temps
        )

        for s, a, sn in history:
            a = min(a, num_cores - 1)
            td = reward + self.gamma * np.max(self.Q[sn])
            self.Q[s, a] += self.alpha * (td - self.Q[s, a])

        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return mapping, reward, hop_cost


# ─── Q-Thermal Baseline ────────────────────────────────────────────────────────

class QThermalAgent:
    """
    Q-learning with thermal state only (4 states × num_cores).
    Models the spirit of Q-Thermal [Ebrahimi 2020] and TTQR [Liu 2022].
    No load-balance dimension, no hierarchy.
    """

    def __init__(
        self,
        num_cores: int = 64,
        alpha: float = 0.1,
        gamma: float = 0.9,
        epsilon: float = 0.5,
        epsilon_decay: float = 0.9935,
        epsilon_min: float = 0.05,
        ambient_temp: float = 45.0,
        max_safe_temp: float = 85.0,
    ):
        self.num_cores     = num_cores
        self.alpha         = alpha
        self.gamma         = gamma
        self.epsilon       = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min   = epsilon_min
        self.ambient_temp  = ambient_temp
        self.max_safe_temp = max_safe_temp

        self.Q = np.zeros((5, num_cores))  # rows 1..4 used

    def _thermal_state(self, core_temps: np.ndarray) -> int:
        avg  = float(np.mean(core_temps))
        span = self.max_safe_temp - self.ambient_temp   # FIX: was hardcoded 40.0
        norm = max(0.0, min(1.0, (avg - self.ambient_temp) / span))
        return int(np.clip(np.floor(norm * 4) + 1, 1, 4))

    def run_episode(
        self,
        env: VehicleNoCEnv,
        comm_matrix: np.ndarray,
        task_types: np.ndarray,
    ) -> Tuple[np.ndarray, float, float]:
        num_tasks = comm_matrix.shape[0]
        num_cores = env.num_cores
        mapping   = np.zeros(num_tasks, dtype=int)
        history   = []

        for task_id in range(num_tasks):
            s = self._thermal_state(env.core_temps)

            if np.random.rand() < self.epsilon:
                action = np.random.randint(0, num_cores)
            else:
                q_row    = self.Q[s].copy()
                occupied = mapping[mapping > 0] - 1
                q_row[occupied] = -np.inf
                action = int(np.argmax(q_row))

            if (action + 1) in mapping:
                free = [c for c in range(num_cores) if (c + 1) not in mapping]
                if free:
                    action = free[np.random.randint(len(free))]

            mapping[task_id] = action + 1

            s_next = self._thermal_state(env.core_temps)
            history.append((s, action, s_next))

        reward, hop_cost = env.compute_reward(
            mapping, comm_matrix, task_types, env.core_temps
        )

        for s, a, sn in history:
            a  = min(a, num_cores - 1)
            td = reward + self.gamma * np.max(self.Q[sn])
            self.Q[s, a] += self.alpha * (td - self.Q[s, a])

        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return mapping, reward, hop_cost


# ─── Greedy Nearest-Neighbour Baseline ────────────────────────────────────────

def run_greedy_nn(
    comm_matrix: np.ndarray,
    task_types: np.ndarray,
    core_temps: np.ndarray,
    env: VehicleNoCEnv,
) -> Tuple[np.ndarray, float, float]:
    """
    Greedy nearest-neighbour task mapper (standard NoC literature baseline).

    Sort tasks by total communication weight (heaviest first).
    First task → coolest free core.
    Each subsequent task → free core minimising weighted hop distance
    to already-placed communicating partners (+ small thermal tiebreak).
    """
    N         = env.N
    num_tasks = comm_matrix.shape[0]
    num_cores = env.num_cores
    mapping   = np.zeros(num_tasks, dtype=int)

    comm_weight = comm_matrix.sum(axis=1) + comm_matrix.sum(axis=0)
    task_order  = np.argsort(-comm_weight)

    for idx, task_id in enumerate(task_order):
        occupied = set(mapping[mapping > 0])
        free     = [c for c in range(1, num_cores + 1) if c not in occupied]
        if not free:
            break

        if idx == 0:
            # First task: place on coolest core
            best = free[int(np.argmin(core_temps[[c - 1 for c in free]]))]
        else:
            best      = free[0]
            best_cost = float('inf')
            for c in free:
                cx, cy = (c - 1) % N, (c - 1) // N
                cost   = 0.0
                for t2 in range(num_tasks):
                    if mapping[t2] > 0 and comm_matrix[task_id, t2] > 0:
                        c2    = mapping[t2]
                        cx2, cy2 = (c2 - 1) % N, (c2 - 1) // N
                        cost += (abs(cx - cx2) + abs(cy - cy2)) * comm_matrix[task_id, t2]
                cost += 0.1 * core_temps[c - 1]
                if cost < best_cost:
                    best_cost = cost
                    best      = c

        mapping[task_id] = best

    reward, hop_cost = env.compute_reward(
        mapping, comm_matrix, task_types, core_temps
    )
    return mapping, reward, hop_cost


# ─── Round-Robin Baseline ─────────────────────────────────────────────────────

def run_round_robin(
    comm_matrix: np.ndarray,
    task_types: np.ndarray,
    core_temps: np.ndarray,
    env: VehicleNoCEnv,
) -> Tuple[np.ndarray, float, float]:
    """
    Round-robin task mapper (naive lower-bound baseline).
    Random permutation prevents coincidental ordering advantages.
    """
    num_tasks    = comm_matrix.shape[0]
    num_clusters = env.num_clusters
    num_cpc      = env.num_cpc

    mapping  = np.zeros(num_tasks, dtype=int)
    slot     = np.zeros(num_clusters, dtype=int)
    order    = np.random.permutation(num_tasks)

    for idx, t in enumerate(order):
        cluster_id = idx % num_clusters
        core       = cluster_id * num_cpc + slot[cluster_id] + 1
        mapping[t] = core
        slot[cluster_id] += 1

    reward, hop_cost = env.compute_reward(
        mapping, comm_matrix, task_types, core_temps
    )
    return mapping, reward, hop_cost
