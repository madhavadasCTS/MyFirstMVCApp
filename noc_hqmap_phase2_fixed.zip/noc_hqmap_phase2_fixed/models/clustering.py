"""
Spectral Task Clustering for Phase 2.

Faithfully ports cluster_tasks.m with:
  - Normalised Laplacian eigenvectors
  - Critical-task co-location bias (5× edge weight for type-1 pairs)
  - k-means on row-normalised embedding
  - BFS fallback when eigenvector decomposition fails
  - Cluster balance enforcement (prefer moving non-critical tasks)
"""

import numpy as np
from sklearn.cluster import KMeans
from typing import List, Tuple, Optional
import warnings


def cluster_tasks(
    comm_matrix: np.ndarray,
    num_clusters: int,
    task_types: Optional[np.ndarray] = None,
    random_state: int = 42,
) -> Tuple[List[np.ndarray], np.ndarray]:
    """
    Spectral graph partitioning with automotive safety bias.

    Parameters
    ----------
    comm_matrix  : (T, T) float — directed communication bandwidth
    num_clusters : int           — number of NoC zones
    task_types   : (T,) int8    — 1=Critical, 2=BestEffort, 3=Background
    random_state : int           — for k-means reproducibility

    Returns
    -------
    task_clusters    : list of T arrays, each containing task indices for that cluster
    task_to_cluster  : (T,) int — cluster assignment, 0-indexed
    """
    num_tasks = comm_matrix.shape[0]

    if task_types is None:
        task_types = np.full(num_tasks, 2, dtype=np.int8)

    # ── Symmetrize + critical-task co-location bias ───────────────────────────
    W = comm_matrix + comm_matrix.T
    for i in range(num_tasks):
        for j in range(num_tasks):
            if task_types[i] == 1 and task_types[j] == 1:
                W[i, j] *= 5.0

    # ── Spectral clustering on normalised Laplacian ───────────────────────────
    task_to_cluster = None
    try:
        d = np.maximum(W.sum(axis=1), 1e-10)
        D_inv_sqrt = np.diag(1.0 / np.sqrt(d))
        L_norm     = np.eye(num_tasks) - D_inv_sqrt @ W @ D_inv_sqrt

        # Suppress numpy/scipy divide warnings during eigen
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            eigenvalues, V = np.linalg.eigh(L_norm)

        # Take the k smallest eigenvectors (sorted ascending by default from eigh)
        embedding = V[:, :num_clusters].copy()

        # Row-normalise
        row_norms = np.maximum(np.linalg.norm(embedding, axis=1, keepdims=True), 1e-10)
        embedding = embedding / row_norms

        # k-means on spectral embedding
        km = KMeans(n_clusters=num_clusters, random_state=random_state, n_init=10)
        task_to_cluster = km.fit_predict(embedding)  # 0-indexed

    except Exception as e:
        warnings.warn(f"Spectral clustering failed ({e}), using BFS fallback.")
        task_to_cluster = _bfs_partition(W, num_tasks, num_clusters)

    # ── Balance clusters (prefer moving non-critical tasks) ───────────────────
    target = num_tasks // num_clusters
    task_to_cluster = _balance_clusters(task_to_cluster, task_types, num_clusters, target)

    # ── Ensure no empty cluster ────────────────────────────────────────────────
    task_to_cluster = _fill_empty_clusters(task_to_cluster, num_clusters)

    # ── Build output ──────────────────────────────────────────────────────────
    task_clusters = [
        np.where(task_to_cluster == c)[0]
        for c in range(num_clusters)
    ]

    return task_clusters, task_to_cluster


# ── Internal helpers ──────────────────────────────────────────────────────────

def _balance_clusters(
    labels: np.ndarray,
    task_types: np.ndarray,
    num_clusters: int,
    target: int,
) -> np.ndarray:
    labels = labels.copy()
    for c in range(num_clusters):
        for _ in range(50):
            if np.sum(labels == c) >= target:
                break
            counts   = np.bincount(labels, minlength=num_clusters)
            big_c    = int(np.argmax(counts))
            if counts[big_c] <= target + 1:
                break
            cands = np.where(labels == big_c)[0]
            # Prefer moving non-critical tasks
            nc = cands[task_types[cands] != 1]
            if len(nc) > 0:
                labels[nc[-1]] = c
            else:
                labels[cands[-1]] = c
    return labels


def _fill_empty_clusters(labels: np.ndarray, num_clusters: int) -> np.ndarray:
    labels = labels.copy()
    for c in range(num_clusters):
        if np.sum(labels == c) == 0:
            counts = np.bincount(labels, minlength=num_clusters)
            big_c  = int(np.argmax(counts))
            cands  = np.where(labels == big_c)[0]
            labels[cands[-1]] = c
    return labels


def _bfs_partition(W: np.ndarray, num_tasks: int, k: int) -> np.ndarray:
    """BFS fallback partition."""
    labels    = np.full(num_tasks, -1, dtype=int)  # -1 = unassigned sentinel
    visited   = np.zeros(num_tasks, dtype=bool)
    cluster   = 0
    target_sz = int(np.ceil(num_tasks / k))
    seeds     = np.argsort(-W.sum(axis=1))

    for seed in seeds:
        if visited[seed]:
            continue
        if cluster >= k:
            break
        queue = [seed]
        count = 0
        while queue and count < target_sz:
            node = queue.pop(0)
            if visited[node]:
                continue
            visited[node]  = True
            labels[node]   = cluster
            count         += 1
            nbrs = np.argsort(-W[node])
            for nb in nbrs:
                if W[node, nb] > 0 and not visited[nb]:
                    queue.append(nb)
        cluster += 1

    # Assign any truly unvisited tasks (labels still -1) — use visited flag, not label value
    unvisited = np.where(~visited)[0]
    for idx, t in enumerate(unvisited):
        labels[t] = idx % k

    return labels
