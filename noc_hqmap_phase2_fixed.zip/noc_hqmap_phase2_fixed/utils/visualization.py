"""
HQ-Map Phase 2 — Visualization.

Paper-ready figures, all matching Octave plot_*.m output:
  - plot_phase2_results : 5-panel HQ-Map performance with driving mode overlay
  - plot_noc_mapping    : 2-D NoC grid coloured by task type
  - plot_comparison     : 6-panel multi-method comparison
  - plot_results_table  : console + PNG paper-ready results table
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import Normalize
from matplotlib import cm
from typing import Dict, List, Optional

# ── Style ──────────────────────────────────────────────────────────────────────
METHOD_COLORS = [
    "#1a99d4",   # HQ-Map (ours)   — blue
    "#e86910",   # Flat Q          — orange
    "#22b84a",   # Q-Thermal       — green
    "#a030c0",   # Greedy NN       — purple
    "#888888",   # Round-Robin     — gray
]
METHOD_LSTYLES  = ["-", "--", "-.", ":", "-"]
METHOD_LWIDTHS  = [2.5, 1.8, 1.8, 1.5, 1.2]
SMOOTHING_WIN   = 20

MODE_COLORS = {1: "#3a86ff", 2: "#ff006e", 3: "#8338ec"}
MODE_ALPHA   = 0.08


def _smooth(x, w: int = SMOOTHING_WIN) -> np.ndarray:
    """Moving-average smooth with edge-reflection padding to avoid boundary artifacts."""
    x   = np.asarray(x, dtype=float)
    pad = w // 2
    # Reflect-pad both ends so the moving average doesn't blend with zeros
    xp  = np.pad(x, pad, mode="edge")
    return np.convolve(xp, np.ones(w) / w, mode="valid")[: len(x)]


def _add_mode_spans(ax, total_steps: int = 1000) -> None:
    """Shade background by driving mode and add vertical transition lines."""
    ax.axvspan(1,   300, alpha=MODE_ALPHA, color=MODE_COLORS[1], lw=0)
    ax.axvspan(301, 700, alpha=MODE_ALPHA, color=MODE_COLORS[2], lw=0)
    ax.axvspan(701, total_steps, alpha=MODE_ALPHA, color=MODE_COLORS[3], lw=0)
    for b in [300, 700]:
        ax.axvline(b, color="#aaaaaa", linewidth=0.8, linestyle=":")


# ── 1. Phase 2 performance plot ────────────────────────────────────────────────

def plot_phase2_results(
    history: Dict,
    N: int = 8,
    total_steps: int = 1000,
    save_path: str = "results/phase2_performance_plot.png",
) -> None:
    """
    5-panel HQ-Map training plot (temperature, latency, reward,
    load balance, driving mode) with mode-shaded background.
    """
    steps = np.arange(1, len(history["rewards"]) + 1)
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)

    fig, axes = plt.subplots(5, 1, figsize=(12, 14), sharex=True)
    fig.subplots_adjust(hspace=0.35, top=0.94)
    fig.suptitle("HQ-Map Phase 2 — Smart Vehicle SoC Performance", fontsize=13, fontweight="bold")

    # 1. Temperature
    ax = axes[0]
    ax.plot(steps, history["temps"], color="#cc3333", lw=0.7, alpha=0.5, label="Raw")
    ax.plot(steps, _smooth(history["temps"]), color="#cc3333", lw=2.0, label="Smoothed")
    ax.axhline(85, color="black",   lw=1.5, ls="--", label="Hard limit (85°C)")
    ax.axhline(75, color="#e6a000", lw=1.0, ls="--", label="Warning (75°C)")
    ax.set_ylabel("Max Temp (°C)")
    ax.set_title("Thermal Stability")
    ax.legend(fontsize=7, loc="upper right", ncol=2)
    ax.set_ylim(40, max(95, float(np.max(history["temps"])) + 5))
    ax.grid(True, alpha=0.3)
    _add_mode_spans(ax, total_steps)

    # 2. Latency
    ax = axes[1]
    ax.plot(steps, history["latency"], color="#999999", lw=0.6, alpha=0.5, label="Raw")
    ax.plot(steps, _smooth(history["latency"]), color="#2255cc", lw=1.8, label="Smoothed")
    ax.set_ylabel("Comm cost")
    ax.set_title("Communication Latency (weighted hop count)")
    ax.legend(fontsize=7, loc="upper right")
    ax.grid(True, alpha=0.3)
    _add_mode_spans(ax, total_steps)

    # 3. Reward
    ax = axes[2]
    ax.plot(steps, history["rewards"], color="#bbbbbb", lw=0.6, alpha=0.5, label="Raw")
    ax.plot(steps, _smooth(history["rewards"]), color="#1a9e50", lw=1.8, label="Smoothed")
    ax.axhline(0, color="#888888", lw=0.8, ls=":")
    ax.set_ylabel("Reward")
    ax.set_title("Episode Reward (higher = better)")
    ax.legend(fontsize=7, loc="lower right")
    ax.grid(True, alpha=0.3)
    _add_mode_spans(ax, total_steps)

    # 4. Load Balance
    ax = axes[3]
    ax.plot(steps, history["load_balance"], color="#7030b0", lw=1.0, alpha=0.6, label="Raw")
    ax.plot(steps, _smooth(history["load_balance"]), color="#9050d0", lw=1.8, label="Smoothed")
    ax.set_ylabel("Load Std-Dev")
    ax.set_title("Cluster Load Balance (lower = better)")
    ax.legend(fontsize=7, loc="upper right")
    ax.grid(True, alpha=0.3)
    _add_mode_spans(ax, total_steps)

    # 5. Driving mode
    ax = axes[4]
    ax.plot(steps, history["modes"], color="black", lw=2.0)
    ax.set_yticks([1, 2, 3])
    ax.set_yticklabels(["City", "Highway", "Parked"])
    ax.set_ylim(0.5, 3.5)
    ax.set_ylabel("Mode")
    ax.set_xlabel("Simulation Step")
    ax.set_title("Driving Context")
    ax.grid(True, alpha=0.3)
    _add_mode_spans(ax, total_steps)

    # Mode legend strip
    patches = [
        mpatches.Patch(color=MODE_COLORS[1], alpha=0.5, label="City (1–300)"),
        mpatches.Patch(color=MODE_COLORS[2], alpha=0.5, label="Highway (301–700)"),
        mpatches.Patch(color=MODE_COLORS[3], alpha=0.5, label="Parked (701–1000)"),
    ]
    fig.legend(handles=patches, loc="lower center", ncol=3, fontsize=8,
               bbox_to_anchor=(0.5, 0.01))

    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {save_path}")


# ── 2. NoC mapping grid ────────────────────────────────────────────────────────

def plot_noc_mapping(
    mapping: np.ndarray,
    core_temps: np.ndarray,
    N: int,
    mode_label: str,
    task_types: Optional[np.ndarray] = None,
    save_path: Optional[str] = None,
) -> None:
    """
    2-D NoC grid: background = core temperature heatmap,
    markers = task type (Critical=★, BestEffort=●, Background=▪).
    Label color adapts to background brightness for readability.
    """
    if save_path is None:
        save_path = f"results/noc_mapping_{mode_label.lower()}.png"
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 7))
    fig.suptitle(f"NoC Task Mapping — {mode_label} Mode", fontsize=13, fontweight="bold")

    # Temperature heatmap
    VMIN, VMAX = 45.0, 90.0
    temp_grid = core_temps.reshape(N, N)
    im = ax.imshow(temp_grid, origin="lower", cmap="hot_r",
                   vmin=VMIN, vmax=VMAX, aspect="equal")
    plt.colorbar(im, ax=ax, label="Core Temperature (°C)", fraction=0.04)

    # Task markers
    type_markers = {1: "*", 2: "o", 3: "s"}
    type_colors  = {1: "#ff2222", 2: "#2266ff", 3: "#33cc55"}
    type_labels  = {1: "Critical (ASIL-D)", 2: "Best-Effort", 3: "Background"}
    type_sizes   = {1: 140, 2: 60, 3: 40}

    plotted = {1: False, 2: False, 3: False}
    for task_id, core in enumerate(mapping):
        if core <= 0:
            continue
        cx, cy = (core - 1) % N, (core - 1) // N
        tt = int(task_types[task_id]) if task_types is not None else 2
        if tt not in type_markers:
            tt = 3
        label = type_labels[tt] if not plotted[tt] else None
        ax.scatter(cx, cy,
                   marker=type_markers[tt],
                   color=type_colors[tt],
                   s=type_sizes[tt],
                   zorder=3,
                   label=label,
                   edgecolors="white" if tt == 1 else "none",
                   linewidths=0.6)
        # FIX: adaptive label color — dark text on bright (hot) cores, white on dark (cool) cores
        norm_temp = (core_temps[core - 1] - VMIN) / (VMAX - VMIN)
        txt_color = "black" if norm_temp > 0.55 else "white"
        ax.text(cx + 0.22, cy + 0.22, str(task_id),
                fontsize=5.5, color=txt_color, zorder=4)
        plotted[tt] = True

    ax.set_xticks(range(N))
    ax.set_yticks(range(N))
    ax.set_xlabel("Core column")
    ax.set_ylabel("Core row")
    ax.legend(fontsize=8, loc="upper right", framealpha=0.8)
    ax.grid(True, color="gray", alpha=0.2, linewidth=0.5)

    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {save_path}")


# ── 3. Multi-method comparison ─────────────────────────────────────────────────

def plot_comparison(
    R: List[Dict],
    methods: List[str],
    total_steps: int = 1000,
    save_path: str = "results/comparison_results.png",
) -> None:
    """
    6-panel comparison: temp, latency, reward, load balance, SCSR, hotspots.
    """
    steps = np.arange(1, total_steps + 1)
    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)

    fig, axes = plt.subplots(3, 2, figsize=(14, 12))
    fig.subplots_adjust(hspace=0.4, wspace=0.3, top=0.93)
    fig.suptitle("HQ-Map Phase 2 — Comparative Evaluation", fontsize=13, fontweight="bold")

    panels = [
        ("temps",        axes[0, 0], "(a) Thermal Performance",       "Max Temp (°C)",        True),
        ("latency",      axes[0, 1], "(b) Communication Latency",      "Weighted Hop Cost",    False),
        ("rewards",      axes[1, 0], "(c) Episode Reward",             "Reward",               False),
        ("load_balance", axes[1, 1], "(d) Cluster Load Balance",       "Load Std-Dev",         False),
        ("scsr",         axes[2, 0], "(e) Safety Constraint (SCSR)",   "SCSR (fraction)",      False),
        ("hotspot_count",axes[2, 1], "(f) Hotspot Count (>75°C cores)","Core Count",           False),
    ]

    for key, ax, title, ylabel, add_thresholds in panels:
        for m_idx, (method_data, method_name) in enumerate(zip(R, methods)):
            series = np.asarray(method_data.get(key, [0] * total_steps), dtype=float)
            if len(series) < total_steps:
                series = np.pad(series, (0, total_steps - len(series)), constant_values=series[-1] if len(series) > 0 else 0)
            ax.plot(
                steps,
                _smooth(series, 25),
                color=METHOD_COLORS[m_idx % len(METHOD_COLORS)],
                lw=METHOD_LWIDTHS[m_idx % len(METHOD_LWIDTHS)],
                ls=METHOD_LSTYLES[m_idx % len(METHOD_LSTYLES)],
                label=method_name,
            )

        if add_thresholds:
            ax.axhline(85, color="black",   lw=1.5, ls="--", label="Limit 85°C")
            ax.axhline(75, color="#e6a000", lw=1.0, ls="--", label="Warn 75°C")
            ax.set_ylim(42, 105)

        ax.set_title(title, fontsize=10)
        ax.set_ylabel(ylabel, fontsize=9)
        ax.set_xlabel("Step", fontsize=8)
        ax.legend(fontsize=6.5, loc="best")
        ax.grid(True, alpha=0.3)
        _add_mode_spans(ax, total_steps)

    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {save_path}")


# ── 4. Results table ───────────────────────────────────────────────────────────

def print_results_table(
    R: List[Dict],
    methods: List[str],
) -> None:
    """
    Print a paper-ready comparison table to stdout.
    Matches TABLE I format from Octave plot_results_table.m.
    """
    mode_ranges = {
        "City":    slice(0, 300),
        "Highway": slice(300, 700),
        "Parked":  slice(700, 1000),
        "Overall": slice(0, 1000),
    }

    # Compute stats
    stats = []
    for m_idx, (mdata, mname) in enumerate(zip(R, methods)):
        row = {"name": mname}
        for phase, sl in mode_ranges.items():
            row[phase] = {
                "reward":    float(np.mean(np.asarray(mdata["rewards"])[sl])),
                "max_temp":  float(np.max(np.asarray(mdata["temps"])[sl])),
                "violations":int(np.sum(np.asarray(mdata["temps"])[sl] > 85)),
                "latency":   float(np.mean(np.asarray(mdata["latency"])[sl])),
                "scsr":      float(np.mean(np.asarray(mdata["scsr"])[sl])) * 100,
                "lb":        float(np.mean(np.asarray(mdata["load_balance"])[sl])),
            }
        stats.append(row)

    rr_r = stats[-1]["Overall"]["reward"]

    w = 100
    print(f"\n+{'-'*w}+")
    print(f"| TABLE I: HQ-Map vs Prior Art — Overall Performance (1000 Steps){' '*35}|")
    print(f"+{'-'*w}+")
    hdr = f"| {'Method':<26} | {'Reward':>8} | {'MaxTemp':>8} | {'Viol.':>6} | {'Latency':>8} | {'SCSR%':>6} | {'LBstd':>6} | {'vs RR%':>8} |"
    print(hdr)
    print(f"+{'-'*w}+")
    for s in stats:
        o    = s["Overall"]
        impr = (o["reward"] - rr_r) / max(abs(rr_r), 0.001) * 100
        mark = ">>" if s["name"] == methods[0] else "  "
        print(f"| {mark} {s['name']:<24} | {o['reward']:+8.3f} | {o['max_temp']:7.1f}°C | "
              f"{o['violations']:6d} | {o['latency']:8.0f} | {o['scsr']:5.1f}% | "
              f"{o['lb']:6.2f} | {impr:+7.1f}% |")
    print(f"+{'-'*w}+\n")

    # Per-mode SCSR
    print(f"  Per-Mode SCSR (Safety Constraint Satisfaction Rate):")
    print(f"  {'Method':<28}  {'City':>8}  {'Highway':>9}  {'Parked':>8}")
    print(f"  {'-'*58}")
    for s in stats:
        print(f"  {s['name']:<28}  {s['City']['scsr']:7.1f}%   "
              f"{s['Highway']['scsr']:7.1f}%   {s['Parked']['scsr']:7.1f}%")
    print()


def plot_results_table(
    R: List[Dict],
    methods: List[str],
    save_path: str = "results/comparison_table.png",
) -> None:
    """
    Render results table as a PNG (paper-ready).
    """
    mode_ranges = {
        "City": slice(0, 300),
        "Highway": slice(300, 700),
        "Parked": slice(700, 1000),
        "Overall": slice(0, 1000),
    }

    os.makedirs(os.path.dirname(save_path) or ".", exist_ok=True)
    stats = []
    for mdata, mname in zip(R, methods):
        o = {}
        for phase, sl in mode_ranges.items():
            o[phase] = {
                "reward":   float(np.mean(np.asarray(mdata["rewards"])[sl])),
                "max_temp": float(np.max(np.asarray(mdata["temps"])[sl])),
                "scsr":     float(np.mean(np.asarray(mdata["scsr"])[sl])) * 100,
                "latency":  float(np.mean(np.asarray(mdata["latency"])[sl])),
            }
        stats.append({"name": mname, **o})

    col_labels = ["Method", "Reward", "MaxTemp(°C)", "SCSR(%)", "Latency"]
    rows       = []
    for s in stats:
        o = s["Overall"]
        rows.append([s["name"], f"{o['reward']:+.3f}", f"{o['max_temp']:.1f}",
                     f"{o['scsr']:.1f}", f"{o['latency']:.0f}"])

    fig, ax = plt.subplots(figsize=(10, 2.2 + 0.45 * len(rows)))
    ax.axis("off")
    tbl = ax.table(
        cellText=rows,
        colLabels=col_labels,
        cellLoc="center",
        loc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(10)
    tbl.scale(1.2, 1.5)

    # Highlight HQ-Map row
    for j in range(len(col_labels)):
        tbl[1, j].set_facecolor("#d4e8f7")
        tbl[1, j].set_text_props(fontweight="bold")

    ax.set_title("HQ-Map Phase 2 — Results Summary", fontsize=11, fontweight="bold", pad=8)
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {save_path}")
