# HQ-Map Phase 2 — Smart Vehicle SoC Task Mapping

**HQ-Map Phase 2** extends Phase 1's GNN + Hierarchical Q-Learning framework to
automotive **Smart Vehicle SoC** scenarios, adding driving-mode-aware workloads,
ISO 26262 safety constraints, and a novel **Safety Constraint Satisfaction Rate
(SCSR)** metric.

---

## What's New in Phase 2

| Feature | Phase 1 | Phase 2 |
|---------|---------|---------|
| Application domain | Generic NoC | Smart Vehicle SoC |
| Workload | Static random DAG | Dynamic: City / Highway / Parked |
| Safety constraints | None | ISO 26262 ASIL-D proximity (3-hop) |
| Reward signal | Latency + Energy + Thermal + Fault | Latency + Thermal + **Safety** |
| Novel metric | — | **SCSR** (Safety Constraint Satisfaction Rate) |
| Baselines | 3 | 5 (+ Flat Q / Q-Thermal style) |

---

## Project Structure

```
noc_hqmap_phase2/
├── main_p2.py                  # Entry point
├── requirements.txt
├── environment/
│   ├── vehicle_workload.py     # City / Highway / Parked DAG generators
│   └── noc_env_p2.py           # Gymnasium-compatible env, reward, SCSR, thermal
├── models/
│   ├── clustering.py           # Spectral clustering w/ critical-task bias
│   └── hq_agent_p2.py          # HQMapAgent, FlatQAgent, QThermalAgent,
│                               #   run_greedy_nn, run_round_robin
└── utils/
    └── visualization.py        # All plots (5-panel, NoC grid, comparison, table)
```

---

## Installation

```bash
pip install -r requirements.txt
```

No PyTorch or PyG required — Phase 2 uses tabular Q-learning (intentionally,
to isolate the Phase 2 contribution: automotive workloads + safety constraints).

To use Phase 1's GNN encoder as state features, see **Phase 1 Integration** below.

---

## Quick Start

### Standard simulation (HQ-Map only, 1000 steps)
```bash
cd noc_hqmap_phase2
python main_p2.py
```

### Full 5-method comparison
```bash
python main_p2.py --mode comparison
```

### Custom parameters
```bash
python main_p2.py --steps 2000 --seed 42
```

### Headless (no plots, e.g. for CI)
```bash
python main_p2.py --no_plots
```

---

## Outputs

All outputs are written to `results/`:

| File | Description |
|------|-------------|
| `phase2_performance_plot.png` | 5-panel HQ-Map training curves |
| `noc_mapping_city.png` | NoC grid (task placement) — City mode |
| `noc_mapping_highway.png` | NoC grid — Highway mode |
| `noc_mapping_parked.png` | NoC grid — Parked mode |
| `comparison_results.png` | 6-panel multi-method comparison |
| `comparison_table.png` | Paper-ready results table |
| `hq_map_phase2_coarse_Q.npy` | Trained coarse Q-table |
| `hq_map_phase2_fine_Q.npy` | Trained fine Q-table |
| `hq_map_phase2_history.json` | Full training history |
| `comparison_results.json` | All method results (raw) |
| `config.json` | Experiment configuration |

---

## Driving Modes

| Mode | Steps | Workload | Critical Tasks |
|------|-------|----------|----------------|
| City | 1–300 | Balanced ADAS + Navigation | 8 (safety pipeline) |
| Highway | 301–700 | Three-pipeline sensor fusion | 15 (Camera + Lidar + Radar) |
| Parked | 701–1000 | Infotainment | 2 (OBD + watchdog) |

The agent re-clusters tasks at each mode transition (steps 301 and 701).

---

## SCSR Metric

**Safety Constraint Satisfaction Rate** — fraction of ASIL-D task pairs placed
within 3 Manhattan hops of each other.

- SCSR = 1.0: all critical pairs satisfy the proximity constraint (ideal)
- SCSR = 0.0: no critical pairs satisfy it (worst case)
- Threshold = 3 hops: 2-cycle latency budget per ISO 26262 ASIL-D

This metric is not present in Q-Thermal, TTQR, or FLEA baselines.

---

## Reward Function

```
R = -(0.5 × hop_norm) − (1.0 × thermal_penalty) − (2.0 × safety_penalty)
  + 2.0 (completion bonus if all tasks placed)
```

Priority: **Safety (2.0) > Thermal (1.0) > Latency (0.5)**
This reflects automotive priority ordering for safety-critical SoCs.

---

## Baselines

| Method | Description |
|--------|-------------|
| **HQ-Map (Ours)** | Hierarchical TD Q-learning, spectral clustering with safety bias |
| Flat Q (FLEA-style) | Single Q-table, no zone hierarchy [Weber et al. 2025] |
| Q-Thermal style | Thermal-state-only Q-learning [Ebrahimi et al. 2020, Liu et al. 2022] |
| Greedy NN | Nearest-neighbour heuristic (standard NoC baseline) |
| Round-Robin | Naive lower bound |

---

## Phase 1 Integration

Phase 2 is designed to be compatible with Phase 1. To use Phase 1's GNN
encoder as task embeddings for clustering (replacing spectral clustering):

```python
# In main_p2.py, after generating workload:
from noc_gnn_hq.models.gnn_encoder import GNNEncoder
gnn = GNNEncoder(...)
gnn.load_state_dict(torch.load("noc_gnn_hq/results/best_gnn.pth"))
embeddings = gnn.encode(comm_matrix_as_pyg_graph)
# Then pass embeddings to cluster_tasks() as pre-computed features
```

Full integration guide coming in Phase 3.
